
package notafiscal;

import java.util.Scanner;


public interface Interface {
    public Scanner leia = new Scanner(System.in);
    public void entrar();
    public void imprimir();   
}
