package notafiscal;

import java.util.Scanner;

import java.util.InputMismatchException;

public class Menu {

    public void menuPrincipal() {

        Scanner leia = new Scanner(System.in);
        int opcao;
        subMenu submenu = new subMenu();
        faker faker = new faker();

        do {
            System.out.println("\n----- MENU NF-e -----");
            System.out.println("1. Incluir NF-e.");
            System.out.println("2. Inclurir NF-e pelo Faker");
            System.out.println("3. Alterar NF-e pelo Número.");
            System.out.println("4. Excluir NF-e pelo Número.");
            System.out.println("5. Consultar NF-e.");
            System.out.println("6. Listagem de NF-e por Número.");
            System.out.println("7. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();

            switch (opcao) {
                case 1 -> {
                    NotaFiscal notafiscal = new NotaFiscal();
                    notafiscal.entrar();
                    submenu.listaNotaFiscal.add(notafiscal);
                    System.out.println("NF-e Adicionada!");
                }

                case 2 -> {
                    submenu.listaNotaFiscal = faker.fakerNotaFiscal(submenu.listaNotaFiscal);
                    System.out.println("Notas adicionadas com sucesso!");
                    break;
                }

                case 3 -> {
                    System.out.println("Digite a posição da NF-e na lista: ");
                    int posicao = leia.nextInt();
                    if (posicao >= 0 && posicao < submenu.listaNotaFiscal.size()) {
                        submenu.n = submenu.listaNotaFiscal.get(posicao);
                        submenu.menuAlterar();
                    }
                }

                case 4 -> {
                    System.out.println("Digite a posição Da NF-e na lista : ");
                    try {
                        int posicao = leia.nextInt();
                        if (posicao >= 0 && posicao < submenu.listaNotaFiscal.size()) {
                            NotaFiscal n = submenu.listaNotaFiscal.get(posicao);
                            submenu.listaNotaFiscal.remove(n);
                            System.out.println("NF-e Excluída!");
                        } else {
                            System.out.println("Posição inválida.");
                        }
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Digite um número válido. Tente novamente.");
                        leia.nextLine();
                    }
                }

                case 5 -> {
                    submenu.menuConsultar();
                }

                case 6 -> {
                    System.out.print("Digite a posição da NF-e na lista: ");

                    int posicao = leia.nextInt();
                    if (posicao >= 0 && posicao < submenu.listaNotaFiscal.size()) {
                        NotaFiscal nf = submenu.listaNotaFiscal.get(posicao);
                        nf.imprimir();
                    } else {
                        System.out.println("Posição inválida.");
                    }
                    break;

                }

                default ->
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 7);

    }

    public static void main(String[] args) {
        Menu menuPrincipal = new Menu();
        menuPrincipal.menuPrincipal();
    }

}
