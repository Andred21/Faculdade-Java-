package notafiscal;

public class NotaFiscal implements Interface {

    private origem origem;
    private destinatario destinatario;
    private fatura fatura;
    private calcImposto calcImposto;
    private transportador transportador;
    private dadosProdutos dadosProdutos;
    private calcIssqn calcIssqn;
    private String dadosAdicionais;

    public NotaFiscal() {

    }

    public NotaFiscal(origem origem, destinatario destinatario, fatura fatura, calcImposto calcImposto, transportador transportador, dadosProdutos dadosProdutos, calcIssqn calcIssqn, String dadosAdicionais) {
        this.origem = origem;
        this.destinatario = destinatario;
        this.fatura = fatura;
        this.calcImposto = calcImposto;
        this.transportador = transportador;
        this.dadosProdutos = dadosProdutos;
        this.calcIssqn = calcIssqn;
        this.dadosAdicionais = dadosAdicionais;
    }

    public origem getOrigem() {
        return origem;
    }

    public void setOrigem(origem origem) {
        this.origem = origem;
    }

    public destinatario getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(destinatario destinatario) {
        this.destinatario = destinatario;
    }

    public fatura getFatura() {
        return fatura;
    }

    public void setFatura(fatura fatura) {
        this.fatura = fatura;
    }

    public calcImposto getCalcImposto() {
        return calcImposto;
    }

    public void setCalcImposto(calcImposto calcImposto) {
        this.calcImposto = calcImposto;
    }

    public transportador getTransportador() {
        return transportador;
    }

    public void setTransportador(transportador transportador) {
        this.transportador = transportador;
    }

    public dadosProdutos getDadosProdutos() {
        return dadosProdutos;
    }

    public void setDadosProdutos(dadosProdutos dadosProdutos) {
        this.dadosProdutos = dadosProdutos;
    }

    public calcIssqn getCalcIssqn() {
        return calcIssqn;
    }

    public void setCalcIssqn(calcIssqn calcIssqn) {
        this.calcIssqn = calcIssqn;
    }

    public String getDadosAdicionais() {
        return dadosAdicionais;
    }

    public void setDadosAdicionais(String dadosAdicionais) {
        this.dadosAdicionais = dadosAdicionais;
    }

    @Override

    public void entrar() {

        origem = new origem();
        origem.entrar();

        System.out.println("Destinatário/Remetente ------------------");
        destinatario = new destinatario();
        destinatario.entrar();

        System.out.println("Fatura ----------------");
        fatura = new fatura();
        fatura.entrar();

        System.out.println("Cálculo do Imposto ---------------------");
        calcImposto = new calcImposto();
        calcImposto.entrar();

        System.out.println("Transportador/Volumes Transportados --------------------------");
        transportador = new transportador();
        transportador.entrar();

        System.out.println("Dados Dos Produtos/Serviço --------------------------");
        dadosProdutos = new dadosProdutos();
        dadosProdutos.entrar();

        System.out.println("Cálculo do Issqn -----------------------");
        calcIssqn = new calcIssqn();
        calcIssqn.entrar();

        System.out.println("Dados adicionais ----------------------------");
        this.setDadosAdicionais(leia.next());

    }

    @Override

    public void imprimir() {

        origem.imprimir();

        System.out.println("Destinatário/Remetente: ");
        destinatario.imprimir();

        System.out.println("Fatura: ");
        fatura.imprimir();

        System.out.println("Cálculo do Imposto: ");
        calcImposto.imprimir();

        System.out.println("Transportador/Volumes Transportados: ");
        transportador.imprimir();

        System.out.println("Dados Dos Produtos: ");
        dadosProdutos.imprimir();

        System.out.println("Cálculo do Issnq: ");
        calcIssqn.imprimir();

        System.out.println("Dados Adicionais: " + this.getDadosAdicionais());

    }

}
