
package notafiscal;


public class calcImposto extends imposto {
    private Double valorFrete;
    private Double valorSeguro;
    private Double desconto;
    private Double depesasAce;
    private Double valorTotalNota;
    
    
    public calcImposto(){        
    }

  

    public calcImposto(Double valorFrete, Double valorSeguro, Double desconto, Double depesasAce, Double baseCalcIcms, Double valorIcms, Double baseCalcIcmssubs, Double valorIcmsSubs, Double valorIpi, Double valorTotalImp) {
        super(baseCalcIcms, valorIcms, baseCalcIcmssubs, valorIcmsSubs, valorIpi, valorTotalImp);
        this.valorFrete = valorFrete;
        this.valorSeguro = valorSeguro;
        this.desconto = desconto;
        this.depesasAce = depesasAce;
    }

    public Double getValorFrete() {
        return valorFrete;
    }

    public void setValorFrete(Double valorFrete) {
        this.valorFrete = valorFrete;
    }

    public Double getValorSeguro() {
        return valorSeguro;
    }

    public void setValorSeguro(Double valorSeguro) {
        this.valorSeguro = valorSeguro;
    }

    public Double getDesconto() {
        return desconto;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }

    public Double getDepesasAce() {
        return depesasAce;
    }

    public void setDepesasAce(Double depesasAce) {
        this.depesasAce = depesasAce;
    }

    public Double getValorTotalNota() {
        return valorTotalNota;
    }

    public void setValorTotalNota(Double valorTotalNota) {
        this.valorTotalNota = valorTotalNota;
    }

    @Override 
    
    public void entrar(){
        super.entrar();
        
        System.out.print("Valor do Frete:");
        this.setValorFrete(leia.nextDouble());
        System.out.print("Valor do Seguro:");
        this.setValorSeguro(leia.nextDouble());
        System.out.print("Desconto:");
        this.setDesconto(leia.nextDouble());
        System.out.print("Outras Desespesas Acessórias:");
        this.setDepesasAce(leia.nextDouble());
        System.out.print("Valor Total da Nota:");
        this.setValorTotalNota(leia.nextDouble());
    }
    
    @Override
    
    public void imprimir(){
        super.imprimir();
        
        System.out.println("Valor do Frete: " + this.getValorFrete());
        System.out.print("Valor do Seguro: " + this.getValorSeguro());
        System.out.print("Desconto: " + this.getDesconto());
        System.out.print("Outras Depesas Acessórias: " + this.getDepesasAce());
        System.out.print("Valor Total da Nota: " + this.getValorTotalNota());
        
    }
}
