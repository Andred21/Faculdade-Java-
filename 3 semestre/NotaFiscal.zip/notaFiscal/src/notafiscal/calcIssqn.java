package notafiscal;

public class calcIssqn implements Interface {

    private String incricaoMunicipal;
    private Double valorTotalServicos;
    private Double baseCalcIssqn;
    private Double valorIssqn;

    public calcIssqn() {
    }

    public calcIssqn(String incricaoMunicipal, Double valorTotalServicos, Double baseCalcIssqn, Double valorIssqn) {
        this.incricaoMunicipal = incricaoMunicipal;
        this.valorTotalServicos = valorTotalServicos;
        this.baseCalcIssqn = baseCalcIssqn;
        this.valorIssqn = valorIssqn;
    }

    public String getIncricaoMunicipal() {
        return incricaoMunicipal;
    }

    public void setIncricaoMunicipal(String incricaoMunicipal) {
        this.incricaoMunicipal = incricaoMunicipal;
    }

    public Double getValorTotalServicos() {
        return valorTotalServicos;
    }

    public void setValorTotalServicos(Double valorTotalServicos) {
        this.valorTotalServicos = valorTotalServicos;
    }

    public Double getBaseCalcIssqn() {
        return baseCalcIssqn;
    }

    public void setBaseCalcIssqn(Double baseCalcIssqn) {
        this.baseCalcIssqn = baseCalcIssqn;
    }

    public Double getValorIssqn() {
        return valorIssqn;
    }

    public void setValorIssqn(Double valorIssqn) {
        this.valorIssqn = valorIssqn;
    }

    @Override

    public void entrar() {

        System.out.print("Incrição Municipal:");
        this.setIncricaoMunicipal(leia.next());

        System.out.print("Valor Total dos Serviços:");

        this.setValorTotalServicos(leia.nextDouble());
        System.out.print("Base de Cálculo do Issqn:");
        this.setBaseCalcIssqn(leia.nextDouble());

        System.out.print("Valor do Issqn:");
        this.setValorIssqn(leia.nextDouble());

    }

    @Override

    public void imprimir() {
        
        System.out.println("Inscrição Municipal: " + this.getIncricaoMunicipal());
        
        System.out.println("Valor Total dos Serviços: " + this.getValorTotalServicos());
        
        System.out.println("Base de Cálculo do Issqn: " + this.getBaseCalcIssqn());
        
        System.out.println("Valor do Issqn: " + this.getValorIssqn());

    }

}
