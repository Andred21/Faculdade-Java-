package notafiscal;

public class dadosProdutos extends imposto {

    private int ncm;
    private int cst;
    private int cfop;
    private Double valorPis;
    private Double valorConfins;
    private Double aliguotas;
    private produto produto;
    private int quant;

    public dadosProdutos() {
    }

    public dadosProdutos(int ncm, int cst, int cfop, Double valorPis, Double valorConfins, Double aliguotas, produto produto) {
        this.ncm = ncm;
        this.cst = cst;
        this.cfop = cfop;
        this.valorPis = valorPis;
        this.valorConfins = valorConfins;
        this.aliguotas = aliguotas;
        this.produto = produto;

    }

    public int getQuant() {
        return quant;
    }

    public void setQuant(int quant) {
        this.quant = quant;
    }

    public int getNcm() {
        return ncm;
    }

    public void setNcm(int ncm) {
        this.ncm = ncm;
    }

    public int getCst() {
        return cst;
    }

    public void setCst(int cst) {
        this.cst = cst;
    }

    public int getCfop() {
        return cfop;
    }

    public void setCfop(int cfop) {
        this.cfop = cfop;
    }

    public Double getValorPis() {
        return valorPis;
    }

    public void setValorPis(Double valorPis) {
        this.valorPis = valorPis;
    }

    public Double getValorConfins() {
        return valorConfins;
    }

    public void setValorConfins(Double valorConfins) {
        this.valorConfins = valorConfins;
    }

    public Double getAliguotas() {
        return aliguotas;
    }

    public void setAliguotas(Double aliguotas) {
        this.aliguotas = aliguotas;
    }

    public produto getProduto() {
        return produto;
    }

    public void setProduto(produto produto) {
        this.produto = produto;
    }

    @Override

    public void entrar() {
        System.out.print("Digite quantidade dos produtos:");
        this.setQuant(leia.nextInt());
        for (int i = 0; i <= getQuant(); i++) {
            super.entrar();

            System.out.print("NCM " + i + ":");
            this.setNcm(leia.nextInt());

            System.out.print("CST " + i + ":");
            this.setCst(leia.nextInt());

            System.out.print("CFOP " + i + ":");
            this.setCfop(leia.nextInt());

            System.out.print("Valor pis " + i + ":");
            this.setValorPis(leia.nextDouble());

            System.out.print("Valor Confins " + i + ":");
            this.setValorConfins(leia.nextDouble());

            System.out.print("Alíguotas " + i + ":");
            this.setAliguotas(leia.nextDouble());

            System.out.println("Produtos " + i + ":");
            produto = new produto();
            produto.entrar();

        }
    }

    @Override

    public void imprimir() {
        System.out.println("Produtos: ");

        for (int i = 0; i <= getQuant(); i++) {
            System.out.println("Produto " + i + ":");
            produto.imprimir();
            System.out.println("NCM: " + i + ":" + this.getNcm());
            System.out.println("CST: " + i + ":" + this.getCst());
            System.out.println("CFOP: " + i + ":" + this.getCfop());
            System.out.println("Valor Pis: " + i + ":" + this.getValorPis());
            System.out.println("Valor Confins: " + i + ":" + this.getValorConfins());
            System.out.println("Alíguotas: " + i + ":" + this.getAliguotas());
        }

    }

}
