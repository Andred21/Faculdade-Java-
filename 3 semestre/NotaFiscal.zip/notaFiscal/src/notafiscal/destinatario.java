package notafiscal;

public class destinatario extends pessoa {

    private String dataEmissao;
    private String dataSaidaEntrada;
    private String horaSaida;
    private telefone telefone;

    public destinatario() {
    }

    public destinatario(String dataEmissao, String dataSaidaEntrada, String horaSaida, telefone telefone) {
        this.dataEmissao = dataEmissao;
        this.dataSaidaEntrada = dataSaidaEntrada;
        this.horaSaida = horaSaida;
        this.telefone = telefone;
    }

    public destinatario(String dataEmissao, String dataSaidaEntrada, String horaSaida, telefone telefone, String razaoSocial, String cnpjCpf, String incricaoEstadual, notafiscal.endereco endereco) {
        super(razaoSocial, cnpjCpf, incricaoEstadual, endereco);
        this.dataEmissao = dataEmissao;
        this.dataSaidaEntrada = dataSaidaEntrada;
        this.horaSaida = horaSaida;
        this.telefone = telefone;
    }

    public telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(telefone telefone) {
        this.telefone = telefone;
    }

    public String getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(String dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public String getDataSaidaEntrada() {
        return dataSaidaEntrada;
    }

    public void setDataSaidaEntrada(String dataSaidaEntrada) {
        this.dataSaidaEntrada = dataSaidaEntrada;
    }

    public String getHoraSaida() {
        return horaSaida;
    }

    public void setHoraSaida(String horaSaida) {
        this.horaSaida = horaSaida;
    }

    @Override

    public void entrar() {
        super.entrar();
        System.out.print("Data Emissão:");
        this.setDataEmissao(leia.next());
        System.out.print("Data de Saída ou entrada:");
        this.setDataSaidaEntrada(leia.next());
        System.out.print("Hora Saida:");
        this.setHoraSaida(leia.next());
        System.out.print("Telefone:");
        telefone.entrar();
    }

    @Override

    public void imprimir() {
        super.imprimir();
        
        System.out.println("Data Emissão: " + this.getDataEmissao());
        System.out.println("Data Sáida/Entrada: " + this.getDataSaidaEntrada());
        System.out.println("Hora Saída: " + this.getHoraSaida());
        System.out.println("Telefone:");
        telefone.imprimir();
    }
}
