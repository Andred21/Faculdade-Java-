
package notafiscal;

public class endereco implements Interface{
    private String logradouro;
    private int numero;
    private String Bairro;
    private int cep;
    private String cidade;
    private String uf;

    
    public endereco(){
    }

    public endereco(String logradouro, int numero, String Bairro, int cep, String cidade, String uf) {
        this.logradouro = logradouro;
        this.numero = numero;
        this.Bairro = Bairro;
        this.cep = cep;
        this.cidade = cidade;
        this.uf = uf;
    }
    
    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return Bairro;
    }

    public void setBairro(String Bairro) {
        this.Bairro = Bairro;
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }
    
    
    @Override
    
    public void entrar(){
        System.out.print("Logradouro:");
        this.setLogradouro(leia.next());
        
        System.out.print("Número:");
        this.setNumero(leia.nextInt());
        
        System.out.print("Bairro:");
        this.setBairro(leia.next());
        
        System.out.print("Cep:");
        this.setCep(leia.nextInt());
        
        System.out.print("Cidade:");
        this.setCidade(leia.next());
        
        System.out.print("UF:");
        this.setUf(leia.next());
    }
    
    @Override 
    
    public void imprimir(){
        
        System.out.println("Logradouro: " + this.getLogradouro());
        System.out.println("Número: " + this.getNumero());
        System.out.println("Bairro: " + this.getBairro());
        System.out.println("Cep: " + this.getCep());
        System.out.println("Cidade: " + this.getCidade());
        System.out.println("UF: " + this.getUf());
    }
    
    
}
