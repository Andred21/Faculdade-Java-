/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package notafiscal;

import java.util.ArrayList;

/**
 *
 * @author GC Info Gamer
 */
public class faker {

    int quant = 20;

    public NotaFiscal fakerNotaFiscal(int i) {
        NotaFiscal nf = new NotaFiscal();
        
        endereco e = new endereco("Rua x" + i, 1 + i,"Centro" + i,122321 + i,"Bauru" + i,"SP" + i);
        telefone t = new telefone(i + 0, 14141420 + i);
        produto pr = new produto(5.00, 3, "maça" + i, "fazendinha amiga" + i, i, 0.300, 0.300,15.00 + i);
        pr.calcular();
        origem o = new origem(e, t, "Mercado do zé" + i, "1233312234" + i, "" + i, "232223322", "11111111-22222-3333-4444");
        destinatario d = new destinatario("12/10/12" + i, "13/10/12" + i,"10:32" + i, t , "Distribuidora" + i, "123312233" + i, "12232341234" + i, e);
        fatura f = new fatura( 3, 1500.00, "12/10/23");
        calcImposto ca = new calcImposto(10.00, 5.00, 2.00, 8.00, 900.00, 910.00, 900.00, 600.00, 0.5, 89.00);
        transportador ta = new transportador("0-Emitente" + i, 123456, "ABC0789" + i,pr , "Transportadora Ltda" + i, "12342222" , "111313212133", e);
        dadosProdutos dp = new dadosProdutos(121312121, 00, 5000, 0.3, 0.5, 0.4, pr);
        calcIssqn ci = new calcIssqn("", null, null, null);
        
        
        nf.setOrigem(o);
        nf.setDestinatario(d);
        nf.setFatura(f);
        nf.setCalcImposto(ca);
        nf.setTransportador(ta);
        nf.setDadosProdutos(dp);
        nf.setCalcIssqn(ci);
        nf.setDadosAdicionais("");
        return nf;

    }

    public ArrayList<NotaFiscal> fakerNotaFiscal(ArrayList<NotaFiscal> listaNotaFiscal) {
        for (int i = 1; i <= quant; i++) {
            listaNotaFiscal.add(fakerNotaFiscal(i));
        }
        return listaNotaFiscal;

    }
}
