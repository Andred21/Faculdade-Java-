package notafiscal;

public class fatura implements Interface {

    private Double total;
    private int parcelas;
    private Double valorTotal;
    private String dataVencimento;

    public fatura() {
    }

    public fatura( int parcelas, Double valorTotal, String dataVencimento) {
      
        this.parcelas = parcelas;
        this.valorTotal = valorTotal;
        this.dataVencimento = dataVencimento;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public int getParcelas() {
        return parcelas;
    }

    public void setParcelas(int parcelas) {
        this.parcelas = parcelas;
    }

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getDataVencimento() {
        return dataVencimento;
    }

    public void setDataVencimento(String dataVencimento) {
        this.dataVencimento = dataVencimento;
    }

    public Double calcular() {
        return total = (valorTotal / parcelas);

    }

    @Override

    public void entrar() {
        System.out.print("Número de Parcelas:");
        parcelas = leia.nextInt();
        setParcelas(parcelas);

        System.out.print("Valor Total:");
        this.setValorTotal(leia.nextDouble());

        if (this.getParcelas() == 1) {
            System.out.println("Data de Vencimento Única: ");
            dataVencimento = leia.next();
            setDataVencimento(dataVencimento);
        } else {
            System.out.println("Valor de cada parcela: " + this.calcular());
            System.out.println("Digite a data de vencimento de cada parcela (DD/MM/AAAA):");
            for (int i = 1; i <= getParcelas(); i++) {
                System.out.print("Parcela " + i + ": ");
                dataVencimento = leia.next();
                setDataVencimento(dataVencimento);
            }

        }
    }

    @Override

    public void imprimir() {

        System.out.println("Parcelas: " + this.getParcelas());
        System.out.println("Data de vencimento das parcelas:");
        if (getParcelas() == 1) {
            System.out.println(this.getDataVencimento());
        } else {
            for (int i = 1; i <= getParcelas(); i++) {
                System.out.println("Parcela " + i + ": " + this.getDataVencimento());
            }
        }
        
        System.out.println("Valor das parcelar: " + this.calcular());

    }

}
