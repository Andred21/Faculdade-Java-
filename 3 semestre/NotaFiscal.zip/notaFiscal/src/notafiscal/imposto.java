package notafiscal;

public abstract class imposto implements Interface {

    private Double baseCalcIcms;
    private Double valorIcms;
    private Double baseCalcIcmssubs;
    private Double valorIcmsSubs;
    private Double valorIpi;
    private Double valorTotalImp;
    private produto produto;
   
    
    public imposto(){       
    }

    public imposto(Double baseCalcIcms, Double valorIcms, Double baseCalcIcmssubs, Double valorIcmsSubs, Double valorIpi, Double valorTotalImp) {
        this.baseCalcIcms = baseCalcIcms;
        this.valorIcms = valorIcms;
        this.baseCalcIcmssubs = baseCalcIcmssubs;
        this.valorIcmsSubs = valorIcmsSubs;
        this.valorIpi = valorIpi;
        
        this.valorTotalImp = valorTotalImp;
    }

    public produto getProduto() {
        return produto;
    }

    public void setProduto(produto produto) {
        this.produto = produto;
    }

    public Double getBaseCalcIcms() {
        return baseCalcIcms;
    }

    public void setBaseCalcIcms(Double baseCalcIcms) {
        this.baseCalcIcms = baseCalcIcms;
    }

    public Double getValorIcms() {
        return valorIcms;
    }

    public void setValorIcms(Double valorIcms) {
        this.valorIcms = valorIcms;
    }

    public Double getBaseCalcIcmssubs() {
        return baseCalcIcmssubs;
    }

    public void setBaseCalcIcmssubs(Double baseCalcIcmssubs) {
        this.baseCalcIcmssubs = baseCalcIcmssubs;
    }

    public Double getValorIcmsSubs() {
        return valorIcmsSubs;
    }

    public void setValorIcmsSubs(Double valorIcmsSubs) {
        this.valorIcmsSubs = valorIcmsSubs;
    }

    public Double getValorIpi() {
        return valorIpi;
    }

    public void setValorIpi(Double valorIpi) {
        this.valorIpi = valorIpi;
    }


    public Double getValorTotalImp() {
        return valorTotalImp;
    }

    public void setValorTotalImp(Double valorTotalImp) {
        this.valorTotalImp = valorTotalImp;
    }
    
    
    @Override
    
    public void entrar(){
        System.out.print("Base de Cálculo Icms:");
        this.setBaseCalcIcms(leia.nextDouble());
        System.out.print("Valor do Icms:");
        this.setValorIcms(leia.nextDouble());
        System.out.print("Base de Calc de Icms Substituição:");
        this.setBaseCalcIcmssubs(leia.nextDouble());
        System.out.print("Valor do Icms Substituição:");
        this.setValorIcmsSubs(leia.nextDouble());
        System.out.print("Valor do Ipi:");
        this.setValorIpi(leia.nextDouble());
        System.out.print("Valor Total de Impostos:");
        this.setValorTotalImp(leia.nextDouble());
        
        
    }
    @Override
    public void imprimir(){
        System.out.println("Base de Cálculo Icms: " + this.getBaseCalcIcms());
        System.out.println("Valor dp Icms: " + this.getValorIcms());
        System.out.println("Base de Calc de Icms Substituição:" + this.getBaseCalcIcmssubs());
        System.out.println("Valor do Icms Substituição: " + this.getValorIcmsSubs());
        System.out.println("Valor do Ipi: " + this.getValorIpi());
        System.out.println("Valor Total de Impostos" + this.getValorTotalImp());      
        System.out.println("Valor Total dos Produtos: " );
        
        
    }

}
