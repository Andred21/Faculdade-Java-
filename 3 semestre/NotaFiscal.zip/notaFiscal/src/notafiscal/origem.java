package notafiscal;

public class origem implements Interface {

    private endereco endereco;
    private telefone telefone;
    private String origem;
    private String incricaoEsta;
    private String incricaoEstatribu;
    private String cnpj;
    private String protocoloUso;

    public origem() {
    }

    public origem(endereco endereco, telefone telefone, String origem, String incricaoEsta, String incricaoEstatribu, String cnpj, String protocoloUso) {
        this.endereco = endereco;
        this.telefone = telefone;
        this.origem = origem;
        this.incricaoEsta = incricaoEsta;
        this.incricaoEstatribu = incricaoEstatribu;
        this.cnpj = cnpj;
        this.protocoloUso = protocoloUso;
    }

    public endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(endereco endereco) {
        this.endereco = endereco;
    }

    public telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(telefone telefone) {
        this.telefone = telefone;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getIncricaoEsta() {
        return incricaoEsta;
    }

    public void setIncricaoEsta(String incricaoEsta) {
        this.incricaoEsta = incricaoEsta;
    }

    public String getIncricaoEstatribu() {
        return incricaoEstatribu;
    }

    public void setIncricaoEstatribu(String incricaoEstatribu) {
        this.incricaoEstatribu = incricaoEstatribu;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getProtocoloUso() {
        return protocoloUso;
    }

    public void setProtocoloUso(String protocoloUso) {
        this.protocoloUso = protocoloUso;
    }

    @Override

    public void entrar() {

        endereco = new endereco();
        endereco.entrar();

        telefone = new telefone();
        telefone.entrar();

        System.out.print("Natureza da Operação:");
        this.setOrigem(leia.next());

        System.out.print("Inscrição Estadual:");
        this.setIncricaoEsta(leia.next());

        System.out.print("Inscrição Estadual Sub tributária:");
        this.setIncricaoEstatribu(leia.next());

        System.out.print("Cnpj:");
        this.setCnpj(leia.next());

        System.out.print("Protocolo de autorização de uso:");
        this.setProtocoloUso(leia.next());

    }

    @Override

    public void imprimir() {
        
        System.out.println("Endereço:");
        endereco.imprimir();
        
        System.out.println("Telefone:");
        telefone.imprimir();
        
        System.out.println("Natureza da Operação: " + this.getOrigem());
        System.out.println("Incrição Estadual: " + this.getIncricaoEsta());
        System.out.println("Inscrição Estadual Sub tributária: " + this.getIncricaoEstatribu());
        System.out.println("Cnpj: " + this.getCnpj());
        System.out.println("Protocolo de autorização de uso: " + this.getProtocoloUso());

    }

}
