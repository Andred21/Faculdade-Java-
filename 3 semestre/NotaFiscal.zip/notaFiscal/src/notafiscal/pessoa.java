package notafiscal;

public abstract class pessoa implements Interface {

    private String razaoSocial;
    private String cnpjCpf;
    private String incricaoEstadual;
    private endereco endereco;
   

    public pessoa() {
    }

    public pessoa(String razaoSocial, String cnpjCpf, String incricaoEstadual, endereco endereco) {
        this.razaoSocial = razaoSocial;
        this.cnpjCpf = cnpjCpf;
        this.incricaoEstadual = incricaoEstadual;
        this.endereco = endereco;
    
    }
    
    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getCnpjCpf() {
        return cnpjCpf;
    }

    public void setCnpjCpf(String cnpjCpf) {
        this.cnpjCpf = cnpjCpf;
    }

    public String getIncricaoEstadual() {
        return incricaoEstadual;
    }

    public void setIncricaoEstadual(String incricaoEstadual) {
        this.incricaoEstadual = incricaoEstadual;
    }

    public endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(endereco endereco) {
        this.endereco = endereco;
    }

  

    @Override

    public void entrar() {
        System.out.print("Razão Social: ");
        this.setRazaoSocial(leia.next());

        System.out.print("Cnpj ou cpf: ");
        this.setCnpjCpf(leia.next());

        System.out.print("Inscrição Estadual:");
        this.setIncricaoEstadual(leia.next());

        endereco = new endereco();
        endereco.entrar();

      

    }

    @Override

    public void imprimir() {
        System.out.println("Razão Social: " + this.getRazaoSocial());
        System.out.println("Cnpj/Cpf: " + this.getCnpjCpf());
        System.out.println("Inscrição Estadual: " + this.getIncricaoEstadual());

        System.out.println("Endereço: ");
        endereco.imprimir();

       

    }

}
