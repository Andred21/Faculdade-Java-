package notafiscal;

public class produto  implements Interface {

    private Double precoUnitario;
    private int quantidade;
    private String tipo;
    private String marca;
    private int idProduto;
    private Double pesoBruto;
    private Double pesoLiquido;
    private Double valorTotal;
    
    public produto() {
    }

    public produto(Double preçoUnitario, int quantidade, String tipo, String marca, int idProduto, Double pesoBruto, Double pesoLiquido,Double valorTotal) {
        this.precoUnitario = preçoUnitario;
        this.quantidade = quantidade;
        this.tipo = tipo;
        this.marca = marca;
        this.idProduto = idProduto;
        this.pesoBruto = pesoBruto;
        this.pesoLiquido = pesoLiquido;
        this.valorTotal = valorTotal;
       
    }
    

    public Double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(Double valorTotal) {
        this.valorTotal = valorTotal;
    }


    public Double getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(Double precoUnitario) {
        this.precoUnitario = precoUnitario;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public Double getPesoBruto() {
        return pesoBruto;
    }

    public void setPesoBruto(Double pesoBruto) {
        this.pesoBruto = pesoBruto;
    }

    public Double getPesoLiquido() {
        return pesoLiquido;
    }

    public void setPesoLiquido(Double pesoLiquido) {
        this.pesoLiquido = pesoLiquido;
    }

    
    public  Double calcular(){
       return valorTotal = (getQuantidade() * getPrecoUnitario());
    }
    
    @Override

        
    public void entrar() {
        System.out.print("Preço Unitário:");
        this.setPrecoUnitario(leia.nextDouble());
        System.out.print("Quantidade:");
        this.setQuantidade(leia.nextInt());
        System.out.print("Espécie:");
        this.setTipo(leia.next());
        System.out.print("Marca:");
        this.setMarca(leia.next());
        System.out.print("Numeração:");
        this.setIdProduto(leia.nextInt());
        System.out.print("Peso Bruto:");
        this.setPesoBruto(leia.nextDouble());
        System.out.print("Peso Líquido:");
        this.setPesoLiquido(leia.nextDouble());

    }

    @Override

    public void imprimir() {
        System.out.println("Quantidade" + this.getQuantidade());
        System.out.println("Espécie" + this.getTipo());
        System.out.println("Marca" + this.getMarca());
        System.out.println("Numeração" + this.getIdProduto());
        System.out.println("Peso Bruto" + this.getPesoBruto());
        System.out.println("Peso Liquído" + this.getPesoLiquido());
        System.out.println("Valor Total: " + this.getValorTotal());

    }

}
