package notafiscal;

import java.util.ArrayList;

import java.util.Scanner;

public class subMenu {

    Scanner leia = new Scanner(System.in);
    int opcao;
    protected ArrayList<NotaFiscal> listaNotaFiscal = new ArrayList<>();
    public NotaFiscal n = new NotaFiscal();

    public void menuAlterar() {

       
            do {
                System.out.println("1. Alterar Destinatário/Remetente.");
                System.out.println("2. Alterar Fatura.");
                System.out.println("3. Alterar Cálculo de Imposto.");
                System.out.println("4. Alterar Transportadora.");
                System.out.println("0. Voltar.");
                System.out.print("Escolha uma opção: ");
                opcao = leia.nextInt();
                
                switch (opcao) {
                    case 1 -> {
                        destinatario d = new destinatario();
                        d.entrar();
                        n.setDestinatario(d);
                        System.out.println("Destinatário/Remetente da NF-e"  + "alterado!");
                    }
                    case 2 -> {
                        fatura f = new fatura();
                        f.entrar();
                        n.setFatura(f);
                        System.out.println("Fatura da NF-E" +  "alterada!");

                    }
                    case 3 -> {
                        calcImposto c = new calcImposto();
                        c.entrar();
                        n.setCalcImposto(c);
                        System.out.println("Cálculo Do Imposto da NF-e" +  "alterado!");
                    }

                    case 4 -> {
                        transportador t = new transportador();
                        t.entrar();
                        n.setTransportador(t);
                        System.out.println("Transportador/Volumes Transportados da NF-e" + "alterada");
                    }

                    case 0 ->
                        System.out.println("Voltando...");

                    default -> {
                        System.out.println("Opção inválida!");
                    }
                }
            } while (opcao != 0);

        }
    

    public void menuConsultar() {
        do {
            System.out.println("1. Consultar pelo número da NF-e.");
            System.out.println("2. Consultar pela razão social do Destinatário.");
            System.out.println("3. Consultar pelo CNPJ/CPF do Destinatário.");
            System.out.println("4. Consultar pelo Valor Total da NF-e.");
            System.out.println("0. Voltar.");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();

            switch (opcao) {

                case 1 -> {
                    System.out.println("Digite a posição Da NF-e na lista : ");
                    
                        int posicao = leia.nextInt();
                        if (posicao >= 0 && posicao < listaNotaFiscal.size()) {
                            NotaFiscal f = listaNotaFiscal.get(posicao);
                            f.imprimir();
                            System.out.println("NF-e Consultada!");
                        } else {
                            System.out.println("Posição inválida.");
                        }
                        break;
                  
                }

                case 2 -> {
                    System.out.println("Digite a Razão Social do Cliente a ser consultada: ");
                    String nomeAlterar = leia.next();
                    boolean encontrado = false;

                    for (NotaFiscal g : listaNotaFiscal) {
                        if (g.getDestinatario().getRazaoSocial().equals(nomeAlterar)) {
                            g.imprimir();
                            System.out.println("NF-e consultada com sucesso!");

                            encontrado = true;
                            break;
                        }

                    }
                    if (!encontrado) {
                        System.out.println("NF-e não encontrada!");

                    }

                }

                case 3 -> {
                    System.out.println("Digite o CNPJ/CPF do Cliente:");
                    String nomeAlterar = leia.next();
                    boolean encontrado = false;

                    for (NotaFiscal f : listaNotaFiscal) {
                        if (f.getDestinatario().getCnpjCpf().equals(nomeAlterar)) {
                            f.imprimir();
                            System.out.println("NF-e consultada com sucesso!");

                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) {
                        System.out.println("NF-e não encontrada!");
                    }
                }
                case 4 -> {
                    System.out.println("Digite o Valor Total da NF-e:");
                    Double nomeAlterar = leia.nextDouble();
                    boolean encontrado = false;

                    for (NotaFiscal f : listaNotaFiscal) {
                        if (f.getDadosProdutos().getProduto().calcular().equals(nomeAlterar)) {
                            f.imprimir();
                            System.out.println("NF-e consultada com sucesso!");

                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) {
                        System.out.println("NF-e não encontrada!");
                    }
                }
            }

        } while (opcao != 0);
    }
}
