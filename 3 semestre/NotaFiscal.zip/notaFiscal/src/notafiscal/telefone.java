package notafiscal;

public class telefone implements Interface {

    private int ddd;
    private int numero;

    public telefone() {
    }

    public telefone(int ddd, int numero) {
        this.ddd = ddd;
        this.numero = numero;
    }

    public int getDdd() {
        return ddd;
    }

    public void setDdd(int ddd) {
        this.ddd = ddd;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    @Override
    
    public void entrar(){
        System.out.print("Ddd:");
        this.setDdd(leia.nextInt());
        
        System.out.print("Número:");
        this.setNumero(leia.nextInt());
                
    }
    
    @Override 
    
    public void imprimir(){
         System.out.println("Número: " + this.getDdd()+ this.getNumero());
        
    }
    
}
