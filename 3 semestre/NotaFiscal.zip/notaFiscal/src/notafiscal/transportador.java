    package notafiscal;

public class transportador extends pessoa {

    private String frete;
    private int codAntt;
    private String placaVeiculo;
    private produto produto;
    

    public transportador() {
    }

    public transportador(String frete, int codAntt, String placaVeiculo, produto produto) {
        this.frete = frete;
        this.codAntt = codAntt;
        this.placaVeiculo = placaVeiculo;
        this.produto = produto;
    }

    public transportador(String frete, int codAntt, String placaVeiculo, produto produto, String razaoSocial, String cnpjCpf, String incricaoEstadual, notafiscal.endereco endereco) {
        super(razaoSocial, cnpjCpf, incricaoEstadual, endereco);
        this.frete = frete;
        this.codAntt = codAntt;
        this.placaVeiculo = placaVeiculo;
        this.produto = produto;
    }

    public produto getProduto() {
        return produto;
    }

    public void setProduto(produto produto) {
        this.produto = produto;
    }

   

    public String getFrete() {
        return frete;
    }

    public void setFrete(String frete) {
        this.frete = frete;
    }

    public int getCodAntt() {
        return codAntt;
    }

    public void setCodAntt(int codAntt) {
        this.codAntt = codAntt;
    }

    public String getPlacaVeiculo() {
        return placaVeiculo;
    }

    public void setPlacaVeiculo(String placaVeiculo) {
        this.placaVeiculo = placaVeiculo;
    }

    @Override

    public void entrar() {
        super.entrar();

        System.out.print("Frete por conta:");
        this.setFrete(leia.next());
        
        System.out.print("Código ANTT:");
        this.setCodAntt(leia.nextInt());
        
        System.out.print("Placa do Veículo");
        this.setPlacaVeiculo(leia.next());
        
        produto = new produto();
        produto.entrar();
                
    }

    @Override

    public void imprimir() {
        super.imprimir();
        
        System.out.println("Frete por conta: " + this.getFrete());
        System.out.println("Código ANTT: " + this.getCodAntt());
        System.out.println("Placa do Veículo: " + this.getPlacaVeiculo());
        
        System.out.println("Produto: ");
        produto.imprimir();
        
    }

}
