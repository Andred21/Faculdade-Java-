package sistemafinanceiro;

public class Endereco implements InterfaceCadastro {

    private String logradouro;
    private String numeroend;
    private String complemento;
    private String bairro;
    private String cidade;
    private String estado;
    private int cep;

    public Endereco() {
    }
    
    public Endereco(String logradouro, String numeroend, String complemento, String bairro, String cidade, String estado, int cep){
        this.logradouro = logradouro;
        this.numeroend = numeroend;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumeroend() {
        return numeroend;
    }

    public void setNumeroend(String numero) {
        this.numeroend = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getCep() {
        return cep;
    }

    public void setCep(int cep) {
        this.cep = cep;
    }

    @Override

    public void entrar() {
        System.out.println("Digite o Logradouro:");
        this.setLogradouro(leia.next());

        System.out.println("Digite o Número:");
        this.setNumeroend(leia.next());

        System.out.println("Digite o Complemento:");
        this.setComplemento(leia.next());

        System.out.println(" Digite o Bairro:");
        this.setBairro(leia.next());

        System.out.println("Digite o Cidade:");
        this.setCidade(leia.next());
        
        System.out.println("Digite o Estado:");
        this.setEstado(leia.next());

        System.out.println("Digite o Cep:");
        this.setCep(leia.nextInt());

    }

    @Override
    public void imprimir(){
        System.out.println("\nLogradouro: " + this.getLogradouro());
        System.out.println("Número: " + this.getNumeroend());
        System.out.println("Complemento: " + this.getComplemento());
        System.out.println("Bairro: " + this.getBairro());
        System.out.println("Cidade: " + this.getCidade());
        System.out.println("Estado: " + this.getEstado());
        System.out.println("Cep: " + this.getCep());
        
        

    }
}
