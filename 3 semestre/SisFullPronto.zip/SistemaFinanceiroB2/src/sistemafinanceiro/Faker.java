 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemafinanceiro;

import java.util.ArrayList;

/**
 *
 * @author UNIP
 */
public class Faker {

    int qtdeFaker = 20;

    public Cliente fakerCliente(int i) {
        Cliente cliente = new Cliente();
        Endereco endereco = new Endereco("Rua x" + i, "21" + i, "hospital" + i, "centro" + i, "Bauru" + i, "SP" + i, 1234312 + i);
        Telefone telefone = new Telefone(14 + i, 998109171 + i);
        cliente.setId(0 + i);
        cliente.setNome("Jv" + i);
        cliente.setIdade(19);
        cliente.setEndereco(endereco);
        cliente.setTelefone(telefone);
        cliente.setEmail("jvsilva@hotma.com" + i);
        cliente.setCnpj("123456789" + i);
        cliente.setIncricaoEstadual("12344773" + i);
        cliente.setContato("14998109171" + i);
        cliente.setLimitecredito(1500.00);
        cliente.setEnderecoconbranca(endereco);

        return cliente;
    }

    public ArrayList<Cliente> fakerClientes(ArrayList<Cliente> listaClientes) {
        for (int i = 1; i <= qtdeFaker; i++) {
            listaClientes.add(fakerCliente(i));
        }

        return listaClientes;
    }

    public Funcionario fakerFuncionario(int i) {
        Funcionario funcionario = new Funcionario();
        Endereco endereco = new Endereco("Rua y" + i, "19" + i, "padaria" + i, "estoril" + i, "Botucatu" + i, "SP" + i, 1234312 + i);
        Telefone telefone = new Telefone(11 + i, 998791890 + i);
        funcionario.setId(i);
        funcionario.setNome("Jv" + i);
        funcionario.setIdade(19 + i);
        funcionario.setEndereco(endereco);
        funcionario.setTelefone(telefone);
        funcionario.setEmail("jvsilva@hotma.com" + i);
        funcionario.setCpf("123456789" + i);
        funcionario.setRg("4723843724" + i);
        funcionario.setEmissor("ssp" + i);
        funcionario.setDataadmissao("12/12/12" + i);
        funcionario.setDatademissao("" + i);
        funcionario.setCtps("2121212" + i);
        funcionario.setSalario(1200.00 + i);

        return funcionario;

    }

    public ArrayList<Funcionario> fakerFuncionarios(ArrayList<Funcionario> listaFuncionarios) {
        for (int i = 1; i <= qtdeFaker; i++) {
            listaFuncionarios.add(fakerFuncionario(i));
        }
        return listaFuncionarios;

    }

    public Fornecedor fakerFornecedor(int i) {
        Fornecedor fornecedor = new Fornecedor();
        Endereco endereco = new Endereco("Rua x" + i, "21" + i, "hospital" + i, "centro" + i, "Bauru" + i, "SP" + i, 1234312 + i);
        Telefone telefone = new Telefone(14 + i, 998109171 + i);
        fornecedor.setId(i);
        fornecedor.setNome("Jv" + i);
        fornecedor.setIdade(19 + i);
        fornecedor.setEndereco(endereco);
        fornecedor.setTelefone(telefone);
        fornecedor.setEmail("jvsilva@hotmail.com" + i);
        fornecedor.setCnpj("123456789" + i);
        fornecedor.setIncricaoEstadual("12344773" + i);
        fornecedor.setContato("14998109171" + i);
        fornecedor.setLimiteCompra(1500.00 + i);
        fornecedor.setDatacompra("11/11/11" + i);
        fornecedor.setSite("www.com");

        return fornecedor;
    }

    public ArrayList<Fornecedor> fakerFornecedores(ArrayList<Fornecedor> listaFornecedores) {
        for (int i = 1; i <= qtdeFaker; i++) {
            listaFornecedores.add(fakerFornecedor(i));
        }
        return listaFornecedores;
    }

    public Receber fakerReceber(int i) {

        Receber receber = new Receber();
        Cliente cliente = fakerCliente(i);

        receber.setIdfin(i);
        receber.setNumeroFin("" + i);
        receber.setEmissao("10/01/10" + i);
        receber.setVencimento("10/09/09" + i);
        receber.setPagamento("11/12/09" + i);
        receber.setValor(300.00 );
        receber.setJuros(0.0 );
        receber.setMulta(0.0 );
        receber.setDesconto(0.0 );
        receber.calcular();
        receber.setCliente(cliente);
        receber.setNotafiscal("1234337ae" + i);

        return receber;
    }

    public ArrayList<Receber> fakerReceberes(ArrayList<Receber> listaReceber) {
        for (int i = 1; i <= qtdeFaker; i++) {
            listaReceber.add(fakerReceber(i));
        }
        return listaReceber;
    }
    
    public Pagar fakerPagar(int i) {
        
       
            Pagar pagar = new Pagar();
            Fornecedor fornecedor = fakerFornecedor(i);
            pagar.setIdfin(i);
            pagar.setNumeroFin("" + i);
            pagar.setEmissao("10/01/10" + i);
            pagar.setVencimento("10/09/09" + i);
            pagar.setPagamento("11/12/09" + i);
            pagar.setValor(100.00 );
            pagar.setJuros(0.0 );
            pagar.setMulta(0.0 );
            pagar.setDesconto(0.0 );
            pagar.calcular();
            pagar.setFornecedor(fornecedor);
            pagar.setBoleto("1234337ae" + i);

           return pagar;

    }
    
    public ArrayList<Pagar> fakerPagares(ArrayList<Pagar> listaPagar){
        for (int i = 1; i <= qtdeFaker; i++){
            listaPagar.add(fakerPagar(i));
        }
        return listaPagar;
    }

    
    

}
