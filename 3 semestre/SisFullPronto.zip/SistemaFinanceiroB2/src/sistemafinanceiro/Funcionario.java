package sistemafinanceiro;

public class Funcionario extends PessoaFisica {

    private String dataAdimissao;
    private String dataDemissao;
    private String ctps;
    private Double salario;

    public Funcionario() {
    }

    public Funcionario(String dataAdimissao, String dataDemissao, String ctps, Double salario) {
        this.dataAdimissao = dataAdimissao;
        this.dataDemissao = dataDemissao;
        this.ctps = ctps;
        this.salario = salario;
    }

    public String getDataadmissao() {
        return dataAdimissao;
    }

    public void setDataadmissao(String dataAdimissao) {
        this.dataAdimissao = dataAdimissao;
    }

    public String getDatademissao() {
        return dataDemissao;
    }

    public void setDatademissao(String dataDemissao) {
        this.dataDemissao = dataDemissao;
    }

    public String getCtps() {
        return ctps;
    }

    public void setCtps(String ctps) {
        this.ctps = ctps;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    @Override

    public void entrar() {
        super.entrar();
        System.out.println("Digite a data de admissão:");
        this.setDataadmissao(leia.next());

        System.out.println("Digite a data de demissão:");
        this.setDatademissao(leia.next());

        System.out.println("Digite o Ctps:");
        this.setCtps(leia.next());

        System.out.println("Digite o salário:");
        this.setSalario(leia.nextDouble());

    }

    @Override

    public void imprimir() {
        super.imprimir();
        System.out.println("Data de Admissão:" + this.getDataadmissao());
        System.out.println("Data de demissão:" + this.getDatademissao());
        System.out.println("Ctps:" + this.getCtps());
        System.out.println("Salário:" + this.getSalario());

    }

}
