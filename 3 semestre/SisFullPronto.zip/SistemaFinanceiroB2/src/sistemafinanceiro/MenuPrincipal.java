package sistemafinanceiro;

import java.util.Scanner;

public class MenuPrincipal {

    public void menu() {
        Scanner leia = new Scanner(System.in);
        int opcao;
        SubMenu subMenu = new SubMenu();

        do {
            System.out.println("\n----- MENU PRINCIPAL -----");
            System.out.println("1. Cliente (" + subMenu.listaClientes.size() + ")");
            System.out.println("2. Funcionário  (" + subMenu.listaFuncionarios.size() + ")");
            System.out.println("3. Fornecedor (" + subMenu.listaFornecedores.size() + ")");
            System.out.println("4. Contas a receber (" + subMenu.listaReceber.size() + ")");
            System.out.println("5. Contas a pagar (" + subMenu.listaPagar.size() +")" );
            System.out.println("6. Fluxo de caixa");
            System.out.println("7. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();

            switch (opcao) {
                case 1 ->
                    subMenu.menuCliente();
                case 2 ->
                    subMenu.menuFuncionario();
                case 3 ->
                    subMenu.menuFornecedor();
                case 4 ->
                    subMenu.menuReceber();
                case 5 ->
                    subMenu.menuPagar();
                case 6 ->
                    subMenu.menuFluxoCaixa();
                case 7 ->
                    System.out.println("Saindo...");
                default ->
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 7);
    }

    public static void main(String[] args) {
        MenuPrincipal menuPrincipal = new MenuPrincipal();
        menuPrincipal.menu();
    }
}
