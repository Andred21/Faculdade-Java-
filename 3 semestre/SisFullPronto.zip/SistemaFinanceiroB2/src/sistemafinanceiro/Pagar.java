package sistemafinanceiro;

public class Pagar extends Financeiro {

    protected Fornecedor fornecedor;
    private String boleto;

    public Pagar() {
    }

    public Pagar(Fornecedor fornecedor, String boleto) {
        this.fornecedor = fornecedor;
        this.boleto = boleto;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public String getBoleto() {
        return boleto;
    }

    public void setBoleto(String boleto) {
        this.boleto = boleto;
    }

    @Override

    public void entrar() {
        super.entrar();

        fornecedor =  new Fornecedor();
        fornecedor.entrar();

        System.out.println("Digite o boleto:");
        this.setBoleto(leia.next());

    }

    @Override

    public void imprimir() {
        super.imprimir();

        System.out.println("Fornecedor:");
        fornecedor.imprimir();

        System.out.println("Boleto:" + this.getBoleto());

    }

}
