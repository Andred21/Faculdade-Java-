package sistemafinanceiro;

public abstract class Pessoa implements InterfaceCadastro {

    private int id;
    private String nome;
    private int idade;
    private Endereco endereco;
    private Telefone telefone;
    private String email;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;

    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public Telefone getTelefone() {
        return telefone;
    }

    public void setTelefone(Telefone telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override

    public void entrar() {

        System.out.print("Digite o id.........: ");
        this.setId(leia.nextInt());

        System.out.print("Digite o nome.......: ");
        this.setNome(leia.next());

        System.out.print("Digite a idade......: ");
        this.setIdade(leia.nextInt());

        telefone = new Telefone();
        telefone.entrar();

        endereco = new Endereco();
        endereco.entrar();

        System.out.print("Digite o email......: ");
        this.setEmail(leia.next());
    }

    @Override

    public void imprimir() {
        System.out.println("Id............: " + this.getId());
        System.out.println("Nome..........: " + this.getNome());
        System.out.println("Idade.........: " + this.getIdade());

        System.out.println("Telefone:");
        telefone.imprimir();

        System.out.println("Endereço:");
        endereco.imprimir();

        System.out.println("Email" + this.getEmail());
    }

}
