package sistemafinanceiro;

public abstract class PessoaFisica extends Pessoa {

    private String cpf;
    private String rg;
    private String emissor;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEmissor() {
        return emissor;
    }

    public void setEmissor(String emissor) {
        this.emissor = emissor;
    }

    @Override

    public void entrar() {
        super.entrar();

        System.out.println("Digite o cpf:");
        this.setCpf(leia.next());

        System.out.println("Digite o rg:");
        this.setRg(leia.next());

        System.out.println("Digite o Orgão Emissor:");
        this.setEmissor(leia.next());

    }

    @Override

    public void imprimir() {
        super.imprimir();
        System.out.print("Cpf:" + this.getCpf());
        System.out.println("Rg:" + this.getRg());
        System.out.println("Orgão emissor:" + this.getEmissor());

    }

}
