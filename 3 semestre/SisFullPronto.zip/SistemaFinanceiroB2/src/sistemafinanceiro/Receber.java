package sistemafinanceiro;

public class Receber extends Financeiro {
    
    protected Cliente cliente;
    private String notaFiscal;

    public Receber() {
    }

    public Receber(Cliente cliente, String notaFiscal) {
        this.cliente = cliente;
        this.notaFiscal = notaFiscal;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getNotafiscal() {
        return notaFiscal;
    }

    public void setNotafiscal(String notaFiscal) {
        this.notaFiscal = notaFiscal;
    }

    @Override

    public void entrar() {
        super.entrar();

        cliente = new Cliente();
        cliente.entrar();

        System.out.println("Nota fiscal: ");
        this.setNotafiscal(leia.next());

    }

    @Override

    public void imprimir() {
        super.imprimir();

        System.out.println("Cliente:");
        cliente.imprimir();

        System.out.println("Nota Fiscal:" + this.getNotafiscal());

    }

}
