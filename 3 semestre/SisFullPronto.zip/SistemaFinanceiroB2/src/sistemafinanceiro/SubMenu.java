package sistemafinanceiro;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;

public class SubMenu {

    private final Scanner leia = new Scanner(System.in);
    protected ArrayList<Cliente> listaClientes = new ArrayList<>();
    protected ArrayList<Funcionario> listaFuncionarios = new ArrayList<>();
    protected ArrayList<Fornecedor> listaFornecedores = new ArrayList<>();
    protected ArrayList<Receber> listaReceber = new ArrayList<>();
    protected ArrayList<Pagar> listaPagar = new ArrayList<>();
    protected Faker faker = new Faker();

    int opcao;

    public void menuCliente() {
        do {
            System.out.println("\n----- MENU CLIENTE -----");
            System.out.println("1. Incluir pelo Faker");
            System.out.println("2. Incluir Manualmente");
            System.out.println("3. Alterar pelo ID");
            System.out.println("4. Consultar pela posição na Lista");
            System.out.println("5. Consultar pelo CNPJ");
            System.out.println("6. Consultar pelo Nome");
            System.out.println("7. Excluir pelo ID");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");

            opcao = leia.nextInt();
            switch (opcao) {
                case 1 -> {
                    listaClientes = faker.fakerClientes(listaClientes);
                    System.out.println("Clientes incluídos");
                    break;
                }

                case 2 -> {
                    Cliente cliente = new Cliente();
                    cliente.entrar();
                    listaClientes.add(cliente);
                    System.out.println("Cliente incluído!");
                }
                case 3 -> {
                    System.out.print("Digite o id a ser alterado: ");
                    int idAlterar = leia.nextInt();
                    boolean encontradoAlterar = false;
                    for (Cliente c : listaClientes) {
                        if (c.getId() == idAlterar) {
                            c.entrar();
                            System.out.println("Cliente alterado com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Cliente não encontrado!");
                    }

                    break;
                }
                case 4 -> {
                    System.out.print("Digite a posição do Cliente na lista: ");
                    try {
                        int posicao = leia.nextInt();
                        if (posicao >= 0 && posicao < listaClientes.size()) {
                            Cliente c = listaClientes.get(posicao);
                            c.imprimir();
                        } else {
                            System.out.println("Posição inválida.");
                        }
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Digite um número válido. Tente novamente.");
                        leia.nextLine();
                    }
                }

                case 5 -> {
                    System.out.print("Digite o Cnpj do Cliente: ");
                    String cnpjAlterar = leia.next();
                    boolean encontradoAlterar2 = false;
                    for (Cliente c : listaClientes) {
                        if (c.getCnpj().equals(cnpjAlterar)) {
                            c.imprimir();
                            System.out.println("Cliente consultado com sucesso!");

                            encontradoAlterar2 = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar2) {
                        System.out.println("Cliente não encontrado!");
                    }

                    break;

                }
                case 6 -> {
                    System.out.print("Digite o nome a ser consultado: ");
                    String nomeAlterar = leia.next();
                    boolean encontradoAlterar3 = false;
                    for (Cliente c : listaClientes) {
                        if (c.getNome().equals(nomeAlterar)) {
                            c.imprimir();
                            System.out.println("Cliente consultado com sucesso!");

                            encontradoAlterar3 = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar3) {
                        System.out.println("Cliente não encontrado!");
                    }

                    break;
                }

                case 7 -> {
                    System.out.print("ID do Cliente que vai ser excluído: ");
                    int idExcluir = leia.nextInt();
                    boolean encontrado = false;
                    for (Cliente c : listaClientes) {
                        if (c.getId() == idExcluir) {
                            listaClientes.remove(c);
                            System.out.println("Cliente excluído com sucesso!");

                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) {
                        System.out.println("Cliente não encontrado!");
                    }
                    break;
                }

                case 0 ->

                    System.out.println("Voltando...");
                default ->
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);

    }

    public void menuFuncionario() {
        do {
            System.out.println("\n----- MENU FUNCIONÁRIO -----");
            System.out.println("1. Incluir pelo Faker");
            System.out.println("2. Incluir Manualmente");
            System.out.println("3. Alterar pelo ID");
            System.out.println("4. Consultar pela posição na Lista");
            System.out.println("5. Consultar pelo ID");
            System.out.println("6. Consultar pelo CPF");
            System.out.println("7. Excluir pelo ID");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();
            switch (opcao) {
                case 1 -> {
                    listaFuncionarios = faker.fakerFuncionarios(listaFuncionarios);
                    System.out.println("Funcionários incluídos");
                    break;
                }

                case 2 -> {
                    Funcionario funcionario = new Funcionario();
                    funcionario.entrar();
                    listaFuncionarios.add(funcionario);
                    System.out.println("Funcionário incluído!");
                    break;
                }

                case 3 -> {
                    System.out.print("Digite o id a ser alterado: ");
                    int idAlterar = leia.nextInt();
                    boolean encontradoAlterar = false;
                    for (Funcionario f : listaFuncionarios) {
                        if (f.getId() == idAlterar) {
                            f.entrar();
                            System.out.println("Funcionário alterado com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Funcionário não encontrado!");
                    }

                    break;
                }
                case 4 -> {
                    System.out.print("Digite a posição do Funcionário na lista: ");
                    try {
                        int posicao = leia.nextInt();
                        if (posicao >= 0 && posicao < listaFuncionarios.size()) {
                            Funcionario f = listaFuncionarios.get(posicao);
                            f.imprimir();
                        } else {
                            System.out.println("Posição inválida.");
                        }
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Digite um número válido. Tente novamente.");
                        leia.nextLine();
                    }
                }

                case 5 -> {
                    System.out.print("Digite o id do Funcionário: ");
                    int idConsultar = leia.nextInt();
                    boolean encontradoAlterar2 = false;
                    for (Funcionario f : listaFuncionarios) {
                        if (f.getId() == idConsultar) {
                            f.imprimir();
                            System.out.println("Funcionario  consultado com sucesso!");

                            encontradoAlterar2 = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar2) {
                        System.out.println("Funcionário não encontrado!");
                    }

                    break;

                }
                case 6 -> {
                    System.out.print("Digite o Cpf a ser consultado: ");
                    String cpfAlterar = leia.next();
                    boolean encontradoAlterar = false;
                    for (Funcionario f : listaFuncionarios) {
                        if (f.getCpf().equals(cpfAlterar)) {
                            f.imprimir();
                            System.out.println("Funcionário consultado com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Funcionário não encontrado!");
                    }

                    break;
                }

                case 7 -> {
                    System.out.print("ID do Funcionário que vai ser excluído: ");
                    int idExcluir = leia.nextInt();
                    boolean encontrado = false;
                    for (Funcionario fu : listaFuncionarios) {
                        if (fu.getId() == idExcluir) {
                            listaFuncionarios.remove(fu);
                            System.out.println("Funcionário excluido!");

                            encontrado = true;
                            break;
                        }

                    }
                    if (!encontrado) {
                        System.out.println("Funcionário não encontrado!");
                    }
                    break;
                }

                case 0 ->

                    System.out.println("Voltando...");
                default ->
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);

    }

    public void menuFornecedor() {
        do {
            System.out.println("\n----- MENU FORNECEDOR -----");
            System.out.println("1. Incluir pelo Faker");
            System.out.println("2. Incluir Manualmente");
            System.out.println("3. Alterar pelo ID");
            System.out.println("4. Consultar pela posição na Lista");
            System.out.println("5. Consultar pelo ID");
            System.out.println("6. Consultar pelo Cnpj");
            System.out.println("7. Excluir pelo ID");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();
            switch (opcao) {

                case 1 -> {
                    listaFornecedores = faker.fakerFornecedores(listaFornecedores);
                    System.out.println("Fonercedores  incluídos");
                    break;
                }

                case 2 -> {
                    Fornecedor fornecedor = new Fornecedor();
                    fornecedor.entrar();
                    listaFornecedores.add(fornecedor);
                    System.out.println("Fornecedor incluído!");
                    break;
                }
                case 3 -> {
                    System.out.print("Digite o id a ser alterado: ");
                    int idAlterar = leia.nextInt();
                    boolean encontradoAlterar = false;
                    for (Fornecedor fo : listaFornecedores) {
                        if (fo.getId() == idAlterar) {
                            fo.entrar();
                            System.out.println("Fornecedor alterado com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Fornecedor não encontrado!");
                    }

                    break;
                }
                case 4 -> {
                    System.out.print("Digite a posição do Fornecedor na lista: ");
                    try {
                        int posicao = leia.nextInt();
                        if (posicao >= 0 && posicao < listaFornecedores.size()) {
                            Fornecedor fo = listaFornecedores.get(posicao);
                            fo.imprimir();
                        } else {
                            System.out.println("Posição inválida.");
                        }
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Digite um número válido. Tente novamente.");
                        leia.nextLine();
                    }
                }

                case 5 -> {
                    System.out.print("Digite o id do Fornecedor: ");
                    int idConsultar = leia.nextInt();
                    boolean encontradoAlterar2 = false;
                    for (Fornecedor fo : listaFornecedores) {
                        if (fo.getId() == idConsultar) {
                            fo.imprimir();
                            System.out.println("Fornecedor consultado com sucesso!");

                            encontradoAlterar2 = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar2) {
                        System.out.println("Fornecedor não encontrado!");
                    }

                    break;

                }

                case 6 -> {
                    System.out.print("Digite o Cnpj do Fornecedor: ");
                    String cnpjAlterar = leia.next();
                    boolean encontradoAlterar2 = false;
                    for (Fornecedor fo : listaFornecedores) {
                        if (fo.getCnpj().equals(cnpjAlterar)) {
                            fo.imprimir();
                            System.out.println("Fornecedor consultado com sucesso!");

                            encontradoAlterar2 = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar2) {
                        System.out.println("Fornecedor não encontrado!");
                    }

                    break;

                }

                case 7 -> {
                    System.out.print("ID do Fornecedor que vai ser excluído: ");
                    int idExcluir = leia.nextInt();
                    boolean encontrado = false;
                    for (Fornecedor f : listaFornecedores) {
                        if (f.getId() == idExcluir) {
                            listaFornecedores.remove(f);
                            System.out.println("Fornecedor excluído com sucesso!");

                            encontrado = true;
                            break;
                        }
                    }
                    if (!encontrado) {
                        System.out.println("Fornecedor não encontrado!");
                    }
                    break;
                }

                case 0 ->

                    System.out.println("Voltando...");
                default ->
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 0);

    }

    public void menuReceber() {
        do {
            System.out.println("\n----- CONTAS A RECEBER  -----");
            System.out.println("1. Incluir pelo Faker");
            System.out.println("2. Incluir manualmente");
            System.out.println("3. Alterar pelo Número");
            System.out.println("4. Consultar pelo nome do Cliente ");
            System.out.println("5. Consultar pelo Número ");
            System.out.println("6. Consultar pelo Valor ");
            System.out.println("7. Consultar pelo Nota Fiscal ");
            System.out.println("8. Excluir pelo Id");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();

            switch (opcao) {

                case 1 -> {
                    listaReceber = faker.fakerReceberes(listaReceber);
                    System.out.println("Contas a Receber incluídas!!");
                    break;
                }

                case 2 -> {
                    Receber receber = new Receber();
                    receber.entrar();
                    listaReceber.add(receber);
                    System.out.println("Conta a receber incluída! ");
                    break;

                }
                case 3 -> {
                    System.out.print("Digite o número da Conta a receber para ser alterada: ");
                    String numAlterar = leia.next();
                    boolean encontradoAlterar = false;
                    for (Receber r : listaReceber) {
                        if (r.getNumeroFin().equals(numAlterar)) {
                            r.entrar();
                            System.out.println("Conta a receber alterada com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }

                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrado!");
                    }

                    break;
                }

                case 4 -> {
                    System.out.print("Digite o nome do Cliente para a Conta a receber ser consultada: ");
                    String nomeAlterar = leia.next();
                    boolean encontradoAlterar = false;
                    for (Receber r : listaReceber) {
                        if (r.cliente.getNome().equals(nomeAlterar)) {
                            r.imprimir();
                            System.out.println("Conta consultada com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrada!");
                    }

                    break;
                }

                case 5 -> {
                    System.out.print("Digite o número da Conta a receber a ser consultada: ");
                    String numAlterar3 = leia.next();
                    boolean encontradoAlterar = false;
                    for (Receber r : listaReceber) {
                        if (r.getNumeroFin().equals(numAlterar3)) {
                            r.imprimir();
                            System.out.println("Conta a receber consultada com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }

                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrado!");
                    }

                    break;
                }

                case 6 -> {
                    System.out.print("Digite o valor da Conta a receber a ser consultada: ");
                    Double valorAlterar = leia.nextDouble();
                    boolean encontradoAlterar3 = false;
                    for (Receber r : listaReceber) {
                        if (r.getValor().equals(valorAlterar)) {
                            r.imprimir();
                            System.out.println("Conta consultada com sucesso!");

                            encontradoAlterar3 = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar3) {
                        System.out.println("Conta não encontrada!");
                    }

                    break;
                }

                case 7 -> {
                    System.out.print("Digite a Nota Fiscal para a conta ser consultada: ");
                    String notaAlterar = leia.next();
                    boolean encontradoAlterar3 = false;
                    for (Receber r : listaReceber) {
                        if (r.getNotafiscal().equals(notaAlterar)) {
                            r.imprimir();
                            System.out.println("Conta consultada com sucesso!");

                            encontradoAlterar3 = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar3) {
                        System.out.println("Conta não encontrada!");
                    }

                    break;
                }

                case 8 -> {
                    System.out.print("ID da Conta a receber que vai ser excluída: ");
                    int idExcluir = leia.nextInt();
                    boolean encontrado = false;
                    for (Receber r : listaReceber) {
                        if (r.getIdfin() == idExcluir) {
                            listaReceber.remove(r);
                            System.out.println("Conta a receber excluída com sucesso!");

                            encontrado = true;
                            break;
                        }
                    }
                    if(!encontrado){
                        System.out.println("Conta a receber não encontrada!");
                    }
                    break;
                }

                case 0 ->
                    System.out.println("Voltando...");
                default ->
                    System.out.println("Opção inválida!");

            }

        } while (opcao != 0);

    }

    public void menuPagar() {
        do {
            System.out.println("\n----- CONTAS A PAGAR  -----");
            System.out.println("1. Incluir pelo Faker");
            System.out.println("2. Incluir Manualmente");
            System.out.println("3. Alterar pelo número");
            System.out.println("4. Consultar pelo Cnpj do Fornecedor");
            System.out.println("5. Consultar pelo Número");
            System.out.println("6. Consultar pelo Valor");
            System.out.println("7. Consultar pelo boleto");
            System.out.println("8. Excluir pelo Id");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();

            switch (opcao) {

                case 1 -> {
                    listaPagar = faker.fakerPagares(listaPagar);
                    System.out.println("Contas a pagar incluídas!!");
                    break;

                }

                case 2 -> {
                    Pagar pagar = new Pagar();
                    pagar.entrar();
                    listaPagar.add(pagar);
                    System.out.println("Conta a pagar incluída!");
                    break;
                }
                case 3 -> {
                    System.out.print("Digite o número da Conta a pagar para ser alterada: ");
                    int numAlterar = leia.nextInt();
                    boolean encontradoAlterar = false;
                    for (Pagar p : listaPagar) {
                        if (p.getNumeroFin().equals(numAlterar)) {
                            p.entrar();
                            System.out.println("Conta a pagar alterada com sucesso!");
                            encontradoAlterar = true;
                            break;
                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrado!");
                    }
                    break;
                }
                case 4 -> {
                    System.out.print("Digite o Cnpj do Fornecedor para a Conta a pagar ser consultada: ");
                    String cnpjAlterar = leia.next();
                    boolean encontradoAlterar = false;
                    for (Pagar p : listaPagar) {
                        if (p.fornecedor.getCnpj().equals(cnpjAlterar)) {
                            p.imprimir();
                            System.out.println("Conta consultada com sucesso!");
                            encontradoAlterar = true;
                            break;
                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrada!");
                    }
                    break;
                }

                case 5 -> {
                    System.out.print("Digite o número da Conta a pagar a ser consultada: ");
                    String numAlterar = leia.next();
                    boolean encontradoAlterar = false;
                    for (Pagar p : listaPagar) {
                        if (p.getNumeroFin().equals(numAlterar)) {
                            p.imprimir();
                            System.out.println("Conta a pagar consultada com sucesso!");

                            encontradoAlterar = true;
                            break;
                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrado!");
                    }
                    break;
                }

                case 6 -> {
                    System.out.print("Digite o valor da Conta a pagar a ser consultada: ");
                    Double valorAlterar = leia.nextDouble();
                    boolean encontradoAlterar = false;
                    for (Pagar p : listaPagar) {
                        if (p.getValor().equals(valorAlterar)) {
                            p.imprimir();
                            System.out.println("Conta consultada com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrada!");
                    }

                    break;
                }

                case 7 -> {
                    System.out.print("Digite o Boleto da Conta a pagar a ser consultado: ");
                    String valorAlterar = leia.next();
                    boolean encontradoAlterar = false;
                    for (Pagar p : listaPagar) {
                        if (p.getBoleto().equals(valorAlterar)) {
                            p.imprimir();
                            System.out.println("Conta consultada com sucesso!");

                            encontradoAlterar = true;
                            break;

                        }
                    }
                    if (!encontradoAlterar) {
                        System.out.println("Conta não encontrada!");
                    }

                    break;
                }

                case 8 -> {
                    System.out.print("ID da Conta a pagar que vai ser excluída: ");
                    int idExcluir = leia.nextInt();
                    boolean encontrado = false;
                    for (Pagar p : listaPagar) {
                        if (p.getIdfin() == idExcluir) {
                            listaPagar.remove(p);
                            System.out.println("Conta a pagar excluída com sucesso!");
                            
                            encontrado = true;
                            break;
                        }
                        }
                        if(!encontrado){
                            System.out.println("Conta a pagar não encontrada!");
                        }
                        
                        break;
                    }
                
                case 0 ->
                    System.out.println("Voltando...");
                default ->
                    System.out.println("Opção inválida!");

            }

        } while (opcao != 0);

    }

    public void menuFluxoCaixa() {
        int total = 0;
        double saldo = 0;
        if (listaPagar.size() > listaReceber.size()) {
            total += listaPagar.size();
        } else {
            total += listaReceber.size();
        }
        if (total != 0) {
            for (int i = 0; i < total; i++) {

                double pagarTotal = 0;
                double receberTotal = 0;
                String pagarVencimento = "";
                String receberVencimento = "";

                if (i < listaPagar.size()) {
                    pagarTotal = listaPagar.get(i).calcular();
                    pagarVencimento = listaPagar.get(i).getVencimento();
                }
                if (i < listaReceber.size()) {
                    receberTotal = listaReceber.get(i).calcular();
                    receberVencimento = listaReceber.get(i).getVencimento();
                }

                saldo += (receberTotal - pagarTotal);

                System.out.println("Vencimento Pagar -- Vencimento Receber -- Crédito --- Débito --- Saldo");
                System.out.println(pagarVencimento + " -------- " + receberVencimento + " ------- " + receberTotal + " ---------- " + pagarTotal + " ---------- " + saldo);
            }

        } else {
            System.out.print("Sem fluxo de caixa!!!!!");
        }
    }
}
