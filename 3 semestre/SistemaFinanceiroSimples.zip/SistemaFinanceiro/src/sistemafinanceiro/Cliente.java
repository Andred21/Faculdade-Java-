package sistemafinanceiro;

public class Cliente extends PessoaJuridica {

    private Double limiteCredito;
    private Endereco enderecoCobranca;

    public Cliente() {
    }

    public Cliente(Double limiteCredito, Endereco enderecoCobranca) {
        this.limiteCredito = limiteCredito;
        this.enderecoCobranca = enderecoCobranca;
    }

    public Double getLimitecredito() {
        return limiteCredito;
    }

    public void setLimitecredito(Double limiteCredito) {
        this.limiteCredito = limiteCredito;
    }

    public Endereco getEnderecocobranca() {
        return enderecoCobranca;
    }

    public void setEnderecoconbranca(Endereco enderecoCobranca) {
        this.enderecoCobranca = enderecoCobranca;
    }

    @Override

    public void entrar(){
        super.entrar();

        System.out.println("Digite o limite de crédito: ");
        this.setLimitecredito(leia.nextDouble());
        
        enderecoCobranca =  getEndereco();
   

    }

    @Override

    public void imprimir() {
        super.imprimir();

        System.out.print("Limite de crédito:" + this.getLimitecredito());
        System.out.print("\nEndereco da cobrança: ");
        enderecoCobranca.imprimir();

    }

}
