package sistemafinanceiro;

public abstract class Financeiro implements InterfaceCadastro {

    private int Idfin;
    private int numeroFin;
    private String emissao;
    private String vencimento;
    private String pagamento;
    private Double valor;
    private Double juros;
    private Double multa;
    private Double desconto;
    private Double total;
   

    public int getIdfin() {
        return Idfin;
    }

    public void setIdfin(int Idfin) {
        this.Idfin = Idfin;
    }

    public int getNumeroFin() {
        return numeroFin;
    }

    public void setNumeroFin(int numeroFin) {
        this.numeroFin = numeroFin;
    }

    public String getEmissao() {
        return emissao;
    }

    public void setEmissao(String emissao) {
        this.emissao = emissao;
    }

    public String getVencimento() {
        return vencimento;
    }

    public void setVencimento(String vencimento) {
        this.vencimento = vencimento;
    }

    public String getPagamento() {
        return pagamento;
    }

    public void setPagamento(String pagamento) {
        this.pagamento = pagamento;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Double getJuros() {
        return juros;
    }

    public void setJuros(Double juros) {
        this.juros = juros;
    }

    public Double getMulta() {
        return multa;
    }

    public void setMulta(Double multa) {
        this.multa = multa;
    }

    public Double getDesconto() {
        return desconto;
    }

    public void setDesconto(Double desconto) {
        this.desconto = desconto;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Double calcular() {
       return total = (valor + juros) - desconto;
    }

    @Override

    public void entrar() {
        System.out.print("Digite seu id:");
        this.setIdfin(leia.nextInt());

        System.out.println("Digite o número:");
        this.setNumeroFin(leia.nextInt());

        System.out.println("Digite a data de Emissão:");
        this.setEmissao(leia.next());

        System.out.println("Digite a data de Vencimento:");
        this.setVencimento(leia.next());

        System.out.println("Digite a data de Pagamento:");
        this.setPagamento(leia.next());

        System.out.println("Digite o valor:");
        this.setValor(leia.nextDouble());

        System.out.println("Digite o juros:");
        this.setJuros(leia.nextDouble());

        System.out.println("Digite o Multa:");
        this.setMulta(leia.nextDouble());

        System.out.println("Digite o desconto:");
        this.setDesconto(leia.nextDouble());
    }

    @Override

    public void imprimir() {
        System.out.println("id:" + this.getIdfin());
        
        System.out.println("Número:" + this.getNumeroFin());
        
        System.out.println("Emissão:" + this.getEmissao());
        
        System.out.println("Vencimento:" + this.getVencimento());
        
        System.out.println("Pagamento:" + this.getPagamento());
        
        System.out.println("Valor:" + this.getValor());
        
        System.out.println("Juros:" + this.getJuros());
        
        System.out.println("Multa:" + this.getMulta());
        
        System.out.println("Desconto:" + this.getDesconto());
        
        System.out.println("Total:" + this.calcular());
        
        

    }
}
