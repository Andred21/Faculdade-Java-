package sistemafinanceiro;

public class Fornecedor extends PessoaJuridica {

    private Double limiteCompra;
    private String dataCompra;
    private String site;

    public Fornecedor() {
    }

    public Fornecedor(Double limiteCompra, String dataCompra, String site) {
        this.limiteCompra = limiteCompra;
        this.dataCompra = dataCompra;
        this.site = site;
    }

    public Double getLimiteCompra() {
        return limiteCompra;
    }

    public void setLimiteCompra(Double limiteCompra) {
        this.limiteCompra = limiteCompra;
    }

    public String getDatacompra() {
        return dataCompra;
    }

    public void setDatacompra(String dataCompra) {
        this.dataCompra = dataCompra;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    @Override

    public void entrar() {
        super.entrar();
        System.out.println("Digite o limite de compra:");
        this.setLimiteCompra(leia.nextDouble());

        System.out.println("Digite a data da compra:");
        this.setDatacompra(leia.next());

        System.out.println("Digite o site: ");
        this.setSite(leia.next());

    }

    @Override

    public void imprimir() {
        super.imprimir();
        System.out.println("Limite de compra:" + this.getLimiteCompra());
        System.out.println("Data da compra:" + this.getDatacompra());
        System.out.println("Site:" + this.getSite());

    }
}
