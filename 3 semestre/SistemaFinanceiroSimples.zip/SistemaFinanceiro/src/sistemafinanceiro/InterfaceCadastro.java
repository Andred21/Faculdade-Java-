
package sistemafinanceiro;

import java.util.Scanner;


  public interface InterfaceCadastro {
   void entrar();
   void imprimir();
   public Scanner leia = new Scanner(System.in);
   
   
   
     
}