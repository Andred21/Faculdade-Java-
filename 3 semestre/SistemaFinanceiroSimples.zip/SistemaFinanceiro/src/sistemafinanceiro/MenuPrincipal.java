package sistemafinanceiro;

import java.util.Scanner;
import static sistemafinanceiro.MenuPrincipal.subMenu.menuCliente;
import static sistemafinanceiro.MenuPrincipal.subMenu.menuContasPagar;
import static sistemafinanceiro.MenuPrincipal.subMenu.menuContasReceber;
import static sistemafinanceiro.MenuPrincipal.subMenu.menuFluxoCaixa;
import static sistemafinanceiro.MenuPrincipal.subMenu.menuFornecedor;
import static sistemafinanceiro.MenuPrincipal.subMenu.menuFuncionario;

public class MenuPrincipal {

    private static Cliente cliente = null;
    private static Fornecedor fornecedor = null;
    private static Funcionario funcionario = null;
    private static Receber receber = null;
    private static Pagar pagar = null;

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n----- MENU PRINCIPAL -----");
            System.out.println("1. Cliente");
            System.out.println("2. Funcionário ");
            System.out.println("3. Fornecedor");
            System.out.println("4. Contas a receber");
            System.out.println("5. Contas a pagar");
            System.out.println("6. Fluxo de caixa");
            System.out.println("7. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = leia.nextInt();

            switch (opcao) {
                case 1 ->
                    menuCliente();
                case 2 ->
                    menuFuncionario();
                case 3 ->
                    menuFornecedor();
                case 4 ->
                    menuContasReceber();
                case 5 ->
                    menuContasPagar();
                case 6 ->
                    menuFluxoCaixa();
                case 7 ->
                    System.out.println("Saindo...");
                default ->
                    System.out.println("Opção inválida!");

            }

        } while (opcao != 7);

    }

    public class subMenu {

        public static void menuCliente() {
            Scanner leia = new Scanner(System.in);
            int opcao;

            do {
                System.out.println("\n----- MENU CLIENTE -----");
                System.out.println("1. Incluir");
                System.out.println("2. Alterar");
                System.out.println("3. Consultar");
                System.out.println("4. Excluir");
                System.out.println("0. Voltar");
                System.out.print("Escolha uma opção: ");
                opcao = leia.nextInt();
                switch (opcao) {
                    case 1 -> {
                        cliente = new Cliente();
                        cliente.entrar();
                        System.out.println("Cliente incluído!");

                    }
                    case 2 -> {
                        if (cliente != null) {
                            cliente.entrar();
                            System.out.println("Cliente alterado!");
                            cliente.imprimir();
                        } else {
                            System.out.println("Cliente não encontrado!");
                        }
                    }
                    case 3 -> {
                        if (cliente != null) {
                            System.out.println("Cliente consultado!");
                            cliente.imprimir();
                        } else {
                            System.out.println("Cliente não encontrado!");
                        }
                    }
                    case 4 -> {
                        if (cliente != null) {
                            cliente = null;
                            System.out.println("Cliente excluído!");
                        } else {
                            System.out.println("Cliente não encontrado!");
                        }
                    }
                    case 0 ->

                        System.out.println("Voltando...");
                    default ->
                        System.out.println("Opção inválida!");
                }

            } while (opcao != 0);

        }

        public static void menuFuncionario() {
            Scanner leia = new Scanner(System.in);
            int opcao;
            do {
                System.out.println("\n----- MENU FUNCINÁRIO  -----");
                System.out.println("1. Incluir");
                System.out.println("2. Alterar");
                System.out.println("3. Consultar");
                System.out.println("4. Excluir");
                System.out.println("0. Voltar");
                System.out.print("Escolha uma opção: ");
                opcao = leia.nextInt();

                switch (opcao) {
                    case 1 -> {
                        funcionario = new Funcionario();
                        funcionario.entrar();
                        System.out.println("Funcionário incluído!");

                    }
                    case 2 -> {
                        if (funcionario != null) {
                            funcionario.entrar();
                            System.out.println("Funcionário alterado!");
                            funcionario.imprimir();
                        } else {
                            System.out.println("Funcionário não encontrado!");
                        }
                    }
                    case 3 -> {
                        if (funcionario != null) {
                            System.out.println("Funcionário consultado!");
                            funcionario.imprimir();
                        } else {
                            System.out.println("Funcionário não encontrado!");
                        }
                    }
                    case 4 -> {
                        if (funcionario != null) {
                            funcionario = null;
                            System.out.println("Funcionário excluído!");
                        } else {
                            System.out.println("Funcionário não encontrado!");
                        }
                    }
                    case 0 ->
                        System.out.println("Voltando...");
                    default ->
                        System.out.println("Opção inválida!");

                }

            } while (opcao != 0);

        }

        public static void menuFornecedor() {
            Scanner leia = new Scanner(System.in);
            int opcao;

            do {
                System.out.println("\n----- MENU FORNECEDOR  -----");
                System.out.println("1. Incluir");
                System.out.println("2. Alterar");
                System.out.println("3. Consultar");
                System.out.println("4. Excluir");
                System.out.println("0. Voltar");
                System.out.print("Escolha uma opção: ");
                opcao = leia.nextInt();

                switch (opcao) {
                    case 1 -> {
                        fornecedor = new Fornecedor();
                        fornecedor.entrar();
                        System.out.println("Fornecedor incluído!");

                    }
                    case 2 -> {
                        if (fornecedor != null) {
                            fornecedor.entrar();
                            System.out.println("Fornecedor alterado!");
                            fornecedor.imprimir();
                        } else {
                            System.out.println("Fornecedor não encontrado!");
                        }
                    }
                    case 3 -> {
                        if (fornecedor != null) {
                            System.out.println("Fornecedor consultado!");
                            fornecedor.imprimir();
                        } else {
                            System.out.println("Fornecedor não encontrado!");
                        }
                    }
                    case 4 -> {
                        if (fornecedor != null) {
                            fornecedor = null;
                            System.out.println("Fonecedor excluído!");
                        } else {
                            System.out.println("Fornecedor não encontrado!");
                        }
                    }
                    case 0 ->
                        System.out.println("Voltando...");
                    default ->
                        System.out.println("Opção inválida!");

                }

            } while (opcao != 0);

        }

        public static void menuContasReceber() {
            Scanner leia = new Scanner(System.in);
            int opcao;

            do {
                System.out.println("\n----- CONTAS A RECEBER  -----");
                System.out.println("1. Incluir");
                System.out.println("2. Alterar");
                System.out.println("3. Consultar");
                System.out.println("4. Excluir");
                System.out.println("0. Voltar");
                System.out.print("Escolha uma opção: ");
                opcao = leia.nextInt();

                switch (opcao) {
                    case 1 -> {
                        receber = new Receber();
                        receber.entrar();
                        System.out.println("Conta a receber incluída! ");

                    }
                    case 2 -> {
                        if (receber != null) {
                            receber.entrar();
                            System.out.println("Conta  a receber alterada! ");
                            receber.imprimir();
                        } else {
                            System.out.println("Conta a receber não encontrada!");
                        }
                    }
                    case 3 -> {
                        if (receber != null) {
                            System.out.println("Conta a receber consultada! ");
                            receber.imprimir();
                        } else {
                            System.out.println("Contas a receber não encontrada!");
                        }
                    }
                    case 4 -> {
                        if (receber != null) {
                            receber = null;
                            System.out.println("Conta a receber excluída!");
                        } else {
                            System.out.println("Conta a receber não encontrada!");
                        }
                    }
                    case 0 ->
                        System.out.println("Voltando...");
                    default ->
                        System.out.println("Opção inválida!");

                }

            } while (opcao != 0);

        }

        public static void menuContasPagar() {
            Scanner leia = new Scanner(System.in);
            int opcao;

            do {
                System.out.println("\n----- CONTAS A PAGAR  -----");
                System.out.println("1. Incluir");
                System.out.println("2. Alterar");
                System.out.println("3. Consultar");
                System.out.println("4. Excluir");
                System.out.println("0. Voltar");
                System.out.print("Escolha uma opção: ");
                opcao = leia.nextInt();

                switch (opcao) {
                    case 1 -> {
                        pagar = new Pagar();
                        pagar.entrar();
                        System.out.println("Conta a pagar incluída!");

                    }
                    case 2 -> {
                        if (pagar != null) {
                            pagar.entrar();
                            System.out.println("Conta a pagar alterada!");
                            pagar.imprimir();
                        } else {
                            System.out.println("Conta a pagar não encontrada!");
                        }
                    }
                    case 3 -> {
                        if (pagar != null) {
                            System.out.println("  Conta a pagar consultada!");
                            pagar.imprimir();
                        } else {
                            System.out.println("Contas a pagar não encontrada!");
                        }
                    }
                    case 4 -> {
                        if (pagar != null) {
                            pagar = null;
                            System.out.println("Conta a receber excluída!");
                        } else {
                            System.out.println("Contas a pagar não encontrada!");
                        }
                    }
                    case 0 ->
                        System.out.println("Voltando...");
                    default ->
                        System.out.println("Opção inválida!");

                }

            } while (opcao != 0);

        }

        public static void menuFluxoCaixa() {

            if (pagar != null && receber != null) {
                Double total1 = receber.calcular();
                Double total2 = pagar.calcular();
                Double saldo = (total1 - total2);
                String vencimento1 = receber.getVencimento();
                String vencimento2 = pagar.getVencimento();

                System.out.println("Vencimento - Crédito - Débito - Saldo");
                System.out.println(vencimento1 + " -- " + total1 + " -- " + total2 + " -- " + saldo);
                System.out.println(vencimento2 + "<- DataPagamento");
            } else {
                System.out.println("Sem fluxo de caixa!");
            }

        }

    }

}
