package sistemafinanceiro;

public abstract class PessoaJuridica extends Pessoa {

    private String cnpj;
    private String inscricaoEstadual;
    private String contato;

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setIncricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    @Override

    public void entrar() {
        super.entrar();

        System.out.println("Cnpj:");
        this.setCnpj(leia.next());

        System.out.println("Inscrição Estadual:");
        this.setIncricaoEstadual(leia.next());

        System.out.println("Contato:");
        this.setContato(leia.next());

    }

    @Override

    public void imprimir() {
        super.imprimir();

        System.out.println("Cnpj:" + this.getCnpj());

        System.out.println("Inscrição Estadual:" + this.getInscricaoEstadual());

        System.out.println("Contato:" + this.getContato());

    }

}
