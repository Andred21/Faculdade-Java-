package controller;

import dao.CompraDao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ClienteModel;
import model.CompraModel;
import model.FornecedorModel;
import model.ProdutoModel;
import model.UsuarioModel;

public class CompraController {

    private List<CompraModel> listausuarios;

    public ArrayList<CompraModel> consultar(String filtro) throws SQLException {
        listausuarios = new CompraDao().consultar(filtro);
        return (ArrayList<CompraModel>) listausuarios;
    }

    public void excluir(CompraModel compra) throws SQLException {
        CompraDao dao = new CompraDao();
        dao.excluir(compra);
    }
    
       public void excluirProdutos(CompraModel compra) throws SQLException{
        CompraDao dao = new CompraDao();
        dao.excluirProdutos(compra);
    }

    public void adicionar(CompraModel compra) throws SQLException {
        CompraDao dao = new CompraDao();
        dao.adicionar(compra);
    }

    public void alterar(CompraModel compra) throws SQLException {
        CompraDao dao = new CompraDao();
        dao.alterar(compra);
    }
    
   
    
    public List<UsuarioModel> getAllUsuarios() throws SQLException {
        CompraDao dao = new CompraDao();
        return dao.getAllUsuarios();
    }

    public List<FornecedorModel> getAllFornecedores() throws SQLException {
        CompraDao dao = new CompraDao();
        return dao.getAllFornecedores();
    }
    public List<ClienteModel> getAllClientes() throws SQLException {
        CompraDao dao = new CompraDao();
        return dao.getAllClientes();
    }
    
    public List<ProdutoModel> getAllProdutos() throws SQLException{
        CompraDao dao = new CompraDao();
        return dao.getAllProdutos();
    }
    
    public int getUltimo() throws SQLException{
        CompraDao dao = new CompraDao();
       return dao.getUltimoCod();  
    }
    
    

    
    public void gravar(String operacao, CompraModel compra) throws SQLException {
        boolean retorno = true;
        if (operacao.equals("incluir")) {
            adicionar(compra);
        } else if (operacao.equals("alterar")) {
            alterar(compra);
        }
    }
    
}
