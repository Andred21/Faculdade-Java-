package controller;

import dao.CompraProdutoDao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.CompraProdutoModel;
import view.CompraProdutoTableModel;

public class CompraProdutoController {

    private List<CompraProdutoModel> listausuarios;
    private static ArrayList<CompraProdutoModel> cplist = new ArrayList<>();

    public ArrayList<CompraProdutoModel> consultar(String filtro) throws SQLException {
        listausuarios = new CompraProdutoDao().consultar(filtro);
        return (ArrayList<CompraProdutoModel>) listausuarios;
    }

    public void excluir(CompraProdutoModel compraProduto) throws SQLException {
        CompraProdutoDao dao = new CompraProdutoDao();
        dao.excluir(compraProduto);
    }
    
  
    public void adicionar(CompraProdutoModel compraProduto) throws SQLException {
        CompraProdutoDao dao = new CompraProdutoDao();
        dao.adicionar(compraProduto);
    }

    public void alterar(CompraProdutoModel compraProduto) throws SQLException {
        CompraProdutoDao dao = new CompraProdutoDao();
        dao.alterar(compraProduto);
    }

    public void gravar(String operacao, CompraProdutoModel compraProduto) throws SQLException {
        boolean retorno = true;
        if (operacao.equals("incluir")) {
            adicionar(compraProduto);
        } else if (operacao.equals("alterar")) {
            alterar(compraProduto);
        }
    }
    
     public static ArrayList<CompraProdutoModel> getCompraProdutosList() {
        return cplist;
    }

}
