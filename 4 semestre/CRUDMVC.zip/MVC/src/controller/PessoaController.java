package controller;

import dao.PessoaDao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.PessoaModel;

public class PessoaController {
  private List<PessoaModel> listausuarios;

    public ArrayList<PessoaModel> consultar(String filtro) throws SQLException {
        listausuarios = new PessoaDao().consultar(filtro);
        return (ArrayList<PessoaModel>) listausuarios;
    }

    public void excluir(PessoaModel pessoa) throws SQLException {
        PessoaDao dao = new PessoaDao();
        dao.excluir(pessoa);
    }

    public void adicionar(PessoaModel pessoa) throws SQLException {
        PessoaDao dao = new PessoaDao();
        dao.adicionar(pessoa);
    }

    public void alterar(PessoaModel pessoa) throws SQLException {
        PessoaDao dao = new PessoaDao();
        dao.alterar(pessoa);
    }

    public void gravar(String operacao, PessoaModel pessoa) throws SQLException {
        boolean retorno = true;
        if (operacao.equals("incluir")) {
            adicionar(pessoa);
        } else if (operacao.equals("alterar")) {
            alterar(pessoa);
        }
    }
}
