package controller;

import dao.VendaDao;
import dao.VendaProdutoDao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.FormaPagtoModel;
import model.VendaModel;
import model.VendaProdutoModel;

public class VendaController {

    private List<VendaModel> listausuarios;

    public ArrayList<VendaModel> consultar(String filtro) throws SQLException {
        listausuarios = new VendaDao().consultar(filtro);
        return (ArrayList<VendaModel>) listausuarios;
    }

    public void excluir(VendaModel venda) throws SQLException {
        VendaDao dao = new VendaDao();
        dao.excluir(venda);
    }
    
    public void excluirProdutos(VendaModel venda) throws SQLException{
        VendaDao dao = new VendaDao();
        dao.excluirProdutos(venda);
    }
    
    public void excluirForma(VendaModel venda) throws SQLException{
        VendaDao dao = new VendaDao();
        dao.excluirForma(venda);
    }
    
     

    public void adicionar(VendaModel venda) throws SQLException {
        VendaDao dao = new VendaDao();
        dao.adicionar(venda);
    }

    public void alterar(VendaModel venda) throws SQLException {
        VendaDao dao = new VendaDao();
        dao.alterar(venda);
    }

    public int getUltimo() throws SQLException {
        VendaDao dao = new VendaDao();
        return dao.getUltimoCod();
    }

    public void gravar(String operacao, VendaModel venda) throws SQLException {
        boolean retorno = true;
        if (operacao.equals("incluir")) {
            adicionar(venda);
        } else if (operacao.equals("alterar")) {
            alterar(venda);
        }
    }
    
     public List<FormaPagtoModel> getAllFormaPagto() throws SQLException{
        VendaDao dao = new VendaDao();
        return dao.getAllFormaPagto();
    }
}
