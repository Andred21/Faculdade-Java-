
package controller;


import dao.VendaPagtoDao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.VendaPagtoModel;

public class VendaPagtoController {
    private List<VendaPagtoModel> listausuarios;
    private static ArrayList<VendaPagtoModel> vplist = new ArrayList<>();

    public ArrayList<VendaPagtoModel> consultar(String filtro) throws SQLException {
        listausuarios = new VendaPagtoDao().consultar(filtro);
        return (ArrayList<VendaPagtoModel>) listausuarios;
    }

    public void excluir(VendaPagtoModel vendaPagto) throws SQLException {
        VendaPagtoDao dao = new VendaPagtoDao();
        dao.excluir(vendaPagto);
    }

    public void adicionar(VendaPagtoModel vendaPagto) throws SQLException {
        VendaPagtoDao dao = new VendaPagtoDao();
        dao.adicionar(vendaPagto);
    }

    public void alterar(VendaPagtoModel vendaPagto) throws SQLException {
        VendaPagtoDao dao = new VendaPagtoDao();
        dao.alterar(vendaPagto);
    }

    public void gravar(String operacao, VendaPagtoModel vendaPagto) throws SQLException {
        boolean retorno = true;
        if (operacao.equals("incluir")) {
            adicionar(vendaPagto);
        } else if (operacao.equals("alterar")) {
            alterar(vendaPagto);
        }
    }
    public static ArrayList<VendaPagtoModel> getVendaFormaPagtoList() {
        return vplist;
    }
}
