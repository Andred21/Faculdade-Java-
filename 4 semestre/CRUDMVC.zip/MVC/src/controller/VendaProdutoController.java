
package controller;

import dao.VendaProdutoDao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.VendaProdutoModel;

public class VendaProdutoController {
     private List<VendaProdutoModel> listausuarios;
     private static ArrayList<VendaProdutoModel> cplist = new ArrayList<>();

    public ArrayList<VendaProdutoModel> consultar(String filtro) throws SQLException {
        listausuarios = new VendaProdutoDao().consultar(filtro);
        return (ArrayList<VendaProdutoModel>) listausuarios;
    }

    public void excluir(VendaProdutoModel vendaProduto) throws SQLException {
        VendaProdutoDao dao = new VendaProdutoDao();
        dao.excluir(vendaProduto);
    }
    
    
    

    public void adicionar(VendaProdutoModel vendaProduto) throws SQLException {
        VendaProdutoDao dao = new VendaProdutoDao();
        dao.adicionar(vendaProduto);
    }

    public void alterar(VendaProdutoModel vendaProduto) throws SQLException {
        VendaProdutoDao dao = new VendaProdutoDao();
        dao.alterar(vendaProduto);
    }

    public void gravar(String operacao, VendaProdutoModel vendaProduto) throws SQLException {
        boolean retorno = true;
        if (operacao.equals("incluir")) {
            adicionar(vendaProduto);
        } else if (operacao.equals("alterar")) {
            alterar(vendaProduto);
        }
    }
    public static ArrayList<VendaProdutoModel> getVendaProdutosList() {
        return cplist;
    }
}
