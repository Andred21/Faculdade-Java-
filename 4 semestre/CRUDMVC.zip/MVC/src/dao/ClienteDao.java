package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.ClienteModel;
import model.PessoaModel;

public class ClienteDao {

    private Connection conexao = null;
    private PessoaDao pessoa;

    public ClienteDao() throws SQLException {
        this.conexao = Conexao.getConexao();
        pessoa = new PessoaDao();
    }

    public void adicionar(ClienteModel cliente) throws SQLException {

        pessoa.adicionar(cliente.getPessoa());

        String sql = "INSERT INTO CLIENTE (PES_CODIGO, CLI_LIMITECRED) "
                + " VALUES (?, ?)";

        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, pessoa.getUltimoCod());
        stm.setFloat(2, cliente.getCLI_LIMITECRED());

        stm.execute();
        stm.close();
    }

    public void alterar(ClienteModel cliente) throws SQLException {

        String sql = "UPDATE CLIENTE SET CLI_LIMITECRED = ? "
                + "WHERE PES_CODIGO = ? ";

        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setFloat(1, cliente.getCLI_LIMITECRED());
        stm.setInt(2, cliente.getPessoa().getPES_CODIGO());

        stm.executeUpdate();
        stm.close();

        pessoa.alterar(cliente.getPessoa());

    }

    public void excluir(ClienteModel cliente) throws SQLException {

        String sql = "DELETE FROM CLIENTE WHERE CLI_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, cliente.getCLI_CODIGO());
        stm.executeUpdate();
        stm.close();

        pessoa.excluir(cliente.getPessoa());

    }

    public ArrayList<ClienteModel> consultar(String filtro) throws SQLException {
        ArrayList<ClienteModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT C.*, P.* FROM CLIENTE C "
                + "INNER JOIN PESSOA P ON P.PES_CODIGO = C.PES_CODIGO";
        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            ClienteModel objpro = new ClienteModel();
            objpro.setCLI_CODIGO(rs.getInt("CLI_CODIGO"));
            objpro.setCLI_LIMITECRED(rs.getFloat("CLI_LIMITECRED"));

            PessoaModel pessoa1 = new PessoaModel();
            pessoa1.setPES_CODIGO(rs.getInt("PES_CODIGO"));
            pessoa1.setPES_NOME(rs.getString("PES_NOME"));
            pessoa1.setPES_FANTASIA(rs.getString("PES_FANTASIA"));
            pessoa1.setPES_FISICA(rs.getInt("PES_FISICA"));
            pessoa1.setPES_CPFCNPJ(rs.getString("PES_CPFCNPJ"));
            pessoa1.setPES_RGIE(rs.getString("PES_RGIE"));
            pessoa1.setPES_CADASTRO(rs.getDate("PES_CADASTRO"));
            pessoa1.setPES_ENDERECO(rs.getString("PES_ENDERECO"));
            pessoa1.setPES_NUMERO(rs.getString("PES_NUMERO"));
            pessoa1.setPES_COMPLEMENTO(rs.getString("PES_COMPLEMENTO"));
            pessoa1.setPES_BAIRRO(rs.getString("PES_BAIRRO"));
            pessoa1.setPES_CIDADE(rs.getString("PES_CIDADE"));
            pessoa1.setPES_UF(rs.getString("PES_UF"));
            pessoa1.setPES_CEP(rs.getString("PES_CEP"));
            pessoa1.setPES_FONE1(rs.getString("PES_FONE1"));
            pessoa1.setPES_FONE2(rs.getString("PES_FONE2"));
            pessoa1.setPES_CEL(rs.getString("PES_CELULAR"));
            pessoa1.setPES_SITE(rs.getString("PES_SITE"));
            pessoa1.setPES_EMAIL(rs.getString("PES_EMAIL"));
            pessoa1.setPES_ATIVO(rs.getInt("PES_ATIVO"));
            pessoa1.setPES_TIPO(rs.getInt("PES_TIPO"));

            objpro.setPessoa(pessoa1);

            lista.add(objpro);
        }
        rs.close();
        stm.close();
        return lista;
    }

}
