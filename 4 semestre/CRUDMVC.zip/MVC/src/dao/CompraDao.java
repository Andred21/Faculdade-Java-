/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.CompraModel;
import model.FornecedorModel;
import model.UsuarioModel;
import java.sql.Date;
import java.util.List;
import model.ClienteModel;
import model.PessoaModel;
import model.ProdutoModel;

/**
 *
 * @author GC Info Gamer
 */
public class CompraDao {

    private Connection conexao = null;

    public CompraDao() throws SQLException {
        this.conexao = Conexao.getConexao();

    }

    public void adicionar(CompraModel compra) throws SQLException {

        String sql = "INSERT INTO COMPRA (USU_CODIGO, FOR_CODIGO, CPR_EMISSAO, CPR_VALOR, CPR_DESCONTO, CPR_TOTAL, CPR_DTENTRADA, CPR_OBS) "
                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, compra.getUsuario().getUSU_CODIGO());
        stm.setInt(2, compra.getFornecedor().getFOR_CODIGO());
        java.sql.Date dataAtual = new java.sql.Date(new java.util.Date().getTime());
        stm.setDate(3, dataAtual);
        stm.setFloat(4, compra.getCPR_VALOR());
        stm.setFloat(5, compra.getCPR_DESCONTO());
        stm.setFloat(6, compra.getCPR_TOTAL());
        stm.setDate(7, compra.getCPR_DTTENTRADA());
        stm.setString(8, compra.getCPR_OBS());

        stm.execute();
        stm.close();
    }

    public void alterar(CompraModel compra) throws SQLException {

        String sql = "UPDATE COMPRA SET USU_CODIGO = ?, FOR_CODIGO = ?, CPR_VALOR = ?, CPR_DESCONTO = ?, "
                + "CPR_TOTAL = ?, CPR_DTENTRADA = ?, CPR_OBS = ?"
                + " WHERE CPR_CODIGO = ?";

        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setInt(1, compra.getUsuario().getUSU_CODIGO());
        stm.setInt(2, compra.getFornecedor().getFOR_CODIGO());
        stm.setFloat(3, compra.getCPR_VALOR());
        stm.setFloat(4, compra.getCPR_DESCONTO());
        stm.setFloat(5, compra.getCPR_TOTAL());
        stm.setDate(6, compra.getCPR_DTTENTRADA());
        stm.setString(7, compra.getCPR_OBS());
        stm.setInt(8, compra.getCPR_CODIGO());

        stm.execute();
        stm.close();
    }
    
     public void excluirProdutos(CompraModel compra) throws SQLException{
        
        String sql = "DELETE FROM COMPRA_PRODUTO WHERE CPR_CODIGO = ?";
 
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, compra.getCPR_CODIGO());
        stm.execute();
        stm.close();
    }

    public void excluir(CompraModel compra) throws SQLException {

        String sql = "DELETE FROM COMPRA WHERE CPR_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, compra.getCPR_CODIGO());
        stm.execute();
        stm.close();

    }

    public ArrayList<CompraModel> consultar(String filtro) throws SQLException {
        ArrayList<CompraModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT C.*, U.USU_CODIGO, U.USU_LOGIN, F.FOR_CODIGO, P.PES_CPFCNPJ, P.PES_NOME FROM COMPRA AS C "
                + "INNER JOIN USUARIO U ON C.USU_CODIGO = U.USU_CODIGO "
                + "INNER JOIN FORNECEDOR F ON C.FOR_CODIGO = F.FOR_CODIGO "
                + "INNER JOIN PESSOA P ON F.PES_CODIGO = P.PES_CODIGO";

        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            CompraModel compra = new CompraModel();
            compra.setCPR_CODIGO(rs.getInt("CPR_CODIGO"));
            compra.setCPR_EMISSAO(rs.getDate("CPR_EMISSAO"));
            compra.setCPR_VALOR(rs.getFloat("CPR_VALOR"));
            compra.setCPR_DESCONTO(rs.getFloat("CPR_DESCONTO"));
            compra.setCPR_TOTAL(rs.getFloat("CPR_TOTAL"));
            compra.setCPR_DTTENTRADA(rs.getDate("CPR_DTENTRADA"));
            compra.setCPR_OBS(rs.getString("CPR_OBS"));

            UsuarioModel usuario = new UsuarioModel();
            usuario.setUSU_CODIGO(rs.getInt("USU_CODIGO"));
            usuario.setUSU_LOGIN(rs.getString("USU_LOGIN"));

            FornecedorModel fornecedor = new FornecedorModel();
            fornecedor.setFOR_CODIGO(rs.getInt("FOR_CODIGO"));

            PessoaModel pessoa = new PessoaModel();
            pessoa.setPES_CPFCNPJ(rs.getString("PES_CPFCNPJ"));
            pessoa.setPES_NOME(rs.getString("PES_NOME"));

            fornecedor.setPessoa(pessoa);
            compra.setUsuario(usuario);
            compra.setFornecedor(fornecedor);

            lista.add(compra);
        }
        rs.close();
        stm.close();
        return lista;
    }

    

    public List<UsuarioModel> getAllUsuarios() throws SQLException {
        List<UsuarioModel> usuarios = new ArrayList<>();
         PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT USU_CODIGO FROM USUARIO ";

        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        while (rs.next()) {
            UsuarioModel usuario = new UsuarioModel();
            usuario.setUSU_CODIGO(rs.getInt("USU_CODIGO"));

            usuarios.add(usuario);
        }

        return usuarios;
    }

    public List<FornecedorModel> getAllFornecedores() throws SQLException {
        List<FornecedorModel> fornecedores = new ArrayList<>();
        PreparedStatement stm;
        ResultSet rs;
        
        String sql = "SELECT FOR_CODIGO FROM FORNECEDOR";
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
            while (rs.next()) {
                FornecedorModel fornecedor = new FornecedorModel();
                fornecedor.setFOR_CODIGO(rs.getInt("FOR_CODIGO"));
               
               
                fornecedores.add(fornecedor);
            }
        
        return fornecedores;
    }
    
    public List<ClienteModel> getAllClientes() throws SQLException {
        List<ClienteModel> clientes = new ArrayList<>();
        PreparedStatement stm;
        ResultSet rs;
        
        String sql = "SELECT CLI_CODIGO FROM CLIENTE";
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
            while (rs.next()) {
                ClienteModel cliente = new ClienteModel();
                cliente.setCLI_CODIGO(rs.getInt("CLI_CODIGO"));
               
               
                clientes.add(cliente);
            }
        
        return clientes;
    }
    
     public List<ProdutoModel> getAllProdutos() throws SQLException {
        List<ProdutoModel> produtos = new ArrayList<>();
        PreparedStatement stm;
        ResultSet rs;
        
        String sql = "SELECT PRO_CODIGO FROM PRODUTO";
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
            while (rs.next()) {
                ProdutoModel produto = new ProdutoModel();
                produto.setPRO_CODIGO(rs.getInt("PRO_CODIGO"));
               
               
                produtos.add(produto);
            }
        
        return produtos;
    }
     public int getUltimoCod() throws SQLException{
     PreparedStatement stm;
     ResultSet rs;
     int cpr_codigo;
     String sql = "SELECT COALESCE(MAX(CPR_CODIGO), 1) AS ULTIMO FROM COMPRA";
     
     stm = conexao.prepareStatement(sql);
     rs = stm.executeQuery();
     rs.next();
     
     cpr_codigo = rs.getInt("ULTIMO");
     rs.close();
     stm.close();
     return cpr_codigo;
    }
}


