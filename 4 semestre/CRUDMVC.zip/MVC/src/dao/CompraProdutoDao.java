package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.CompraModel;
import model.CompraProdutoModel;
import model.ProdutoModel;

public class CompraProdutoDao {

    private Connection conexao = null;

    public CompraProdutoDao() throws SQLException {
        this.conexao = Conexao.getConexao();

    }

    public void adicionar(CompraProdutoModel compraProduto) throws SQLException {

        String sql = "INSERT INTO COMPRA_PRODUTO (CPR_CODIGO, PRO_CODIGO, CPP_QTDE, CPP_PRECO, CPP_DESCONTO, CPP_TOTAL ) "
                + " VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, compraProduto.getCompra().getCPR_CODIGO());
        stm.setInt(2, compraProduto.getProduto().getPRO_CODIGO());
        stm.setFloat(3, compraProduto.getCPP_QTDE());
        stm.setFloat(4, compraProduto.getCPP_PRECO());
        stm.setFloat(5, compraProduto.getCPP_DESCONTO());
        stm.setFloat(6, compraProduto.getCPP_TOTAL());

        stm.execute();
        stm.close();
    }

    public void alterar(CompraProdutoModel compraProduto) throws SQLException {

        String sql = "UPDATE COMPRA_PRODUTO SET PRO_CODIGO = ?, CPP_QTDE = ?, CPP_PRECO = ?, CPP_DESCONTO = ?, "
                + "CPP_TOTAL = ? "
                + "WHERE CPR_CODIGO = ?";

        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setInt(1, compraProduto.getProduto().getPRO_CODIGO());
        stm.setFloat(2, compraProduto.getCPP_QTDE());
        stm.setFloat(3, compraProduto.getCPP_PRECO());
        stm.setFloat(4, compraProduto.getCPP_DESCONTO());
        stm.setFloat(5, compraProduto.getCPP_TOTAL());
        stm.setInt(6,compraProduto.getCompra().getCPR_CODIGO());

        stm.execute();
        stm.close();
    }

    public void excluir(CompraProdutoModel compraProduto) throws SQLException {

        String sql = "DELETE FROM COMPRA_PRODUTO WHERE CPP_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, compraProduto.getCPP_CODIGO());
        stm.execute();
        stm.close();

    }
    
   

    public ArrayList<CompraProdutoModel> consultar(String filtro) throws SQLException {
        ArrayList<CompraProdutoModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT CP.*, C.CPR_CODIGO, P.PRO_CODIGO, P.PRO_NOME FROM COMPRA_PRODUTO CP "
                + "INNER JOIN COMPRA C ON C.CPR_CODIGO = CP.CPR_CODIGO "
                + "INNER JOIN PRODUTO P ON P.PRO_CODIGO = CP.PRO_CODIGO ";

        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            CompraProdutoModel compraProduto = new CompraProdutoModel();
            compraProduto.setCPP_CODIGO(rs.getInt("CPP_CODIGO"));
            compraProduto.setCPP_QTDE(rs.getFloat("CPP_QTDE"));
            compraProduto.setCPP_PRECO(rs.getFloat("CPP_PRECO"));
            compraProduto.setCPP_DESCONTO(rs.getFloat("CPP_DESCONTO"));
            compraProduto.setCPP_TOTAL(rs.getFloat("CPP_TOTAL"));

            CompraModel compra = new CompraModel();
            compra.setCPR_CODIGO(rs.getInt("CPR_CODIGO"));
            ProdutoModel produto = new ProdutoModel();
            produto.setPRO_CODIGO(rs.getInt("PRO_CODIGO"));
            produto.setPRO_NOME(rs.getString("PRO_NOME"));

            compraProduto.setCompra(compra);
            compraProduto.setProduto(produto);

            lista.add(compraProduto);
        }
        rs.close();
        stm.close();
        return lista;

    }

}

/* public float getValorTotal() throws SQLException {
        PreparedStatement stm;
        ResultSet rs;
        float cpp_total;
        String sql = "SELECT (CPR_QTDE * CPR_PRECO - CPR_DESCONTO) AS TOTAL FROM COMPRA_PRODUTO WHERE CPP_CODIGO = ? ";
                
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        rs.next();

        cpp_total = rs.getFloat("TOTAL");
        rs.close();
        stm.close();
        return cpp_total;
    } */
