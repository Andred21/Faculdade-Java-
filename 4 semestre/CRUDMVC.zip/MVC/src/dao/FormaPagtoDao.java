
package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.FormaPagtoModel;

public class FormaPagtoDao {

    private Connection conexao = null;

    public FormaPagtoDao() throws SQLException {
        this.conexao = Conexao.getConexao();
    }

    public void adicionar(FormaPagtoModel forma) throws SQLException {
        String sql = "INSERT INTO FORMA_PAGTO ( FPG_NOME, FPG_ATIVO)"
                + " VALUES (?, ?)";
        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setString(1, forma.getFPG_NOME());
        stm.setInt(2, forma.getFPG_ATIVO());
        stm.execute();
        stm.close();
    }

    public void alterar(FormaPagtoModel forma) throws SQLException {
        String sql = "UPDATE FORMA_PAGTO SET FPG_NOME = ?, FPG_ATIVO = ? "
                + "WHERE FPG_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setString(1, forma.getFPG_NOME());
        stm.setInt(2, forma.getFPG_ATIVO());
        stm.setInt(3,forma.getFPG_CODIGO());
       
        stm.execute();
        stm.close();
    }

    public void excluir(FormaPagtoModel forma) throws SQLException {
        String sql = "DELETE FROM FORMA_PAGTO WHERE FPG_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, forma.getFPG_CODIGO());
        stm.execute();
        stm.close();
    }

    public ArrayList<FormaPagtoModel> consultar(String condicao) throws SQLException {
        ArrayList<FormaPagtoModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT * FROM FORMA_PAGTO";
        if (!condicao.equals("")) {
            sql += " where " + condicao;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            FormaPagtoModel objusu = new FormaPagtoModel();
            objusu.setFPG_CODIGO(rs.getInt("FPG_CODIGO"));
            objusu.setFPG_NOME(rs.getString("FPG_NOME"));
            objusu.setFPG_ATIVO(rs.getInt("FPG_ATIVO"));
            lista.add(objusu);
        }
        rs.close();
        stm.close();
        return lista;
    }
}

