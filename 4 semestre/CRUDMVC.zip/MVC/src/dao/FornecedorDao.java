package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.FornecedorModel;
import model.PessoaModel;

public class FornecedorDao {

    private Connection conexao = null;
    private PessoaDao pessoa;

    public FornecedorDao() throws SQLException {
        this.conexao = Conexao.getConexao();
        pessoa = new PessoaDao();
    }

    public void adicionar(FornecedorModel fornecedor) throws SQLException {

        pessoa.adicionar(fornecedor.getPessoa());

        String sql = "INSERT INTO FORNECEDOR (PES_CODIGO, FOR_CONTATO) "
                + " VALUES (?, ?)";

        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, pessoa.getUltimoCod());
        stm.setString(2, fornecedor.getFOR_CONTATO());

        stm.execute();
        stm.close();
    }

    public void alterar(FornecedorModel fornecedor) throws SQLException {

        String sql = "UPDATE FORNECEDOR SET FOR_CONTATO = ? "
                + " WHERE PES_CODIGO = ?";

        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setString(1, fornecedor.getFOR_CONTATO());
        stm.setInt(2, fornecedor.getPessoa().getPES_CODIGO());

        stm.executeUpdate();
        stm.close();

        pessoa.alterar(fornecedor.getPessoa());
    }

    public void excluir(FornecedorModel fornecedor) throws SQLException {

        String sql = "DELETE FROM FORNECEDOR WHERE FOR_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, fornecedor.getFOR_CODIGO());
        stm.executeUpdate();
        stm.close();

        pessoa.excluir(fornecedor.getPessoa());

    }

    public ArrayList<FornecedorModel> consultar(String filtro) throws SQLException {
        ArrayList<FornecedorModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT F.*, P.* FROM FORNECEDOR F "
                + "INNER JOIN PESSOA P ON P.PES_CODIGO = F.PES_CODIGO";
        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            FornecedorModel objpro = new FornecedorModel();
            objpro.setFOR_CODIGO(rs.getInt("FOR_CODIGO"));
            objpro.setFOR_CONTATO(rs.getString("FOR_CONTATO"));

            PessoaModel pessoa1 = new PessoaModel();
            pessoa1.setPES_CODIGO(rs.getInt("PES_CODIGO"));
            pessoa1.setPES_NOME(rs.getString("PES_NOME"));
            pessoa1.setPES_FANTASIA(rs.getString("PES_FANTASIA"));
            pessoa1.setPES_FISICA(rs.getInt("PES_FISICA"));
            pessoa1.setPES_CPFCNPJ(rs.getString("PES_CPFCNPJ"));
            pessoa1.setPES_RGIE(rs.getString("PES_RGIE"));
            pessoa1.setPES_CADASTRO(rs.getDate("PES_CADASTRO"));
            pessoa1.setPES_ENDERECO(rs.getString("PES_ENDERECO"));
            pessoa1.setPES_NUMERO(rs.getString("PES_NUMERO"));
            pessoa1.setPES_COMPLEMENTO(rs.getString("PES_COMPLEMENTO"));
            pessoa1.setPES_BAIRRO(rs.getString("PES_BAIRRO"));
            pessoa1.setPES_CIDADE(rs.getString("PES_CIDADE"));
            pessoa1.setPES_UF(rs.getString("PES_UF"));
            pessoa1.setPES_CEP(rs.getString("PES_CEP"));
            pessoa1.setPES_FONE1(rs.getString("PES_FONE1"));
            pessoa1.setPES_FONE2(rs.getString("PES_FONE2"));
            pessoa1.setPES_CEL(rs.getString("PES_CELULAR"));
            pessoa1.setPES_SITE(rs.getString("PES_SITE"));
            pessoa1.setPES_EMAIL(rs.getString("PES_EMAIL"));
            pessoa1.setPES_ATIVO(rs.getInt("PES_TIPO"));

            objpro.setPessoa(pessoa1);

            lista.add(objpro);
        }
        rs.close();
        stm.close();
        return lista;
    }



}
