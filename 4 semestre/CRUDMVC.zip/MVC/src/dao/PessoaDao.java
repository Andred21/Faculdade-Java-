 package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.PessoaModel;

public class PessoaDao {

    private Connection conexao = null;

    public PessoaDao() throws SQLException {
        this.conexao = Conexao.getConexao();
    }

    public void adicionar(PessoaModel pessoa) throws SQLException {
        String sql = "INSERT INTO PESSOA (PES_NOME, PES_FANTASIA, PES_FISICA, PES_CPFCNPJ, PES_RGIE, PES_CADASTRO, PES_ENDERECO, PES_NUMERO, PES_COMPLEMENTO, "
                + "PES_BAIRRO, PES_CIDADE, PES_UF, PES_CEP, PES_FONE1, PES_FONE2, PES_CELULAR, PES_SITE, PES_EMAIL, PES_ATIVO, PES_TIPO)"
                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setString(1, pessoa.getPES_NOME());
        stm.setString(2, pessoa.getPES_FANTASIA());
        stm.setInt(3, pessoa.getPES_FISICA());
        stm.setString(4, pessoa.getPES_CPFCNPJ());
        stm.setString(5, pessoa.getPES_RGIE());
          java.sql.Date dataAtual = new java.sql.Date(new java.util.Date().getTime());
        stm.setDate(6, dataAtual);
        stm.setString(7, pessoa.getPES_ENDERECO());
        stm.setString(8, pessoa.getPES_NUMERO());
        stm.setString(9, pessoa.getPES_COMPLEMENTO());
        stm.setString(10, pessoa.getPES_BAIRRO());
        stm.setString(11, pessoa.getPES_CIDADE());
        stm.setString(12, pessoa.getPES_UF());
        stm.setString(13, pessoa.getPES_CEP());
        stm.setString(14, pessoa.getPES_FONE1());
        stm.setString(15, pessoa.getPES_FONE2());
        stm.setString(16, pessoa.getPES_CEL());
        stm.setString(17, pessoa.getPES_SITE());
        stm.setString(18, pessoa.getPES_EMAIL());
        stm.setInt(19, pessoa.getPES_ATIVO());
        stm.setInt(20,pessoa.getPES_TIPO());

        stm.execute();
        stm.close();
    }

    public void alterar(PessoaModel pessoa) throws SQLException {
         
        String sql = " UPDATE PESSOA SET PES_NOME = ?, PES_FANTASIA = ?,"
                + " PES_FISICA = ?, PES_CPFCNPJ = ?, PES_RGIE = ?, PES_CADASTRO = ?, PES_ENDERECO = ?, "
                + "PES_NUMERO = ?, PES_COMPLEMENTO = ?, PES_BAIRRO = ?, PES_CIDADE = ?, "
                + "PES_UF = ?, PES_CEP = ?, PES_FONE1 = ?, PES_FONE2 = ?, PES_CELULAR = ?, PES_SITE = ?, PES_EMAIL = ?, PES_ATIVO = ?, PES_TIPO = ?"
                + " WHERE PES_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setString(1, pessoa.getPES_NOME());
        stm.setString(2, pessoa.getPES_FANTASIA());
        stm.setInt(3, pessoa.getPES_FISICA());
        stm.setString(4, pessoa.getPES_CPFCNPJ());
        stm.setString(5, pessoa.getPES_RGIE());
        stm.setDate(6, pessoa.getPES_CADASTRO());
        stm.setString(7, pessoa.getPES_ENDERECO());
        stm.setString(8, pessoa.getPES_NUMERO());
        stm.setString(9, pessoa.getPES_COMPLEMENTO());
        stm.setString(10, pessoa.getPES_BAIRRO());
        stm.setString(11, pessoa.getPES_CIDADE());
        stm.setString(12, pessoa.getPES_UF());
        stm.setString(13,pessoa.getPES_CEP());
        stm.setString(14, pessoa.getPES_FONE1());
        stm.setString(15, pessoa.getPES_FONE2());
        stm.setString(16, pessoa.getPES_CEL());
        stm.setString(17, pessoa.getPES_SITE());
        stm.setString(18, pessoa.getPES_EMAIL());
        stm.setInt(19, pessoa.getPES_ATIVO());
        stm.setInt(20,pessoa.getPES_TIPO());
        stm.setInt(21, pessoa.getPES_CODIGO());

        stm.executeUpdate();
        stm.close();
        
    }

    public void excluir(PessoaModel pessoa) throws SQLException {
        String sql = "DELETE FROM PESSOA WHERE PES_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, pessoa.getPES_CODIGO());
        stm.execute();
        stm.close();
    }

    public ArrayList<PessoaModel> consultar(String filtro) throws SQLException {
        ArrayList<PessoaModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT * FROM PESSOA";
        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            PessoaModel objpro = new PessoaModel();
            objpro.setPES_CODIGO(rs.getInt("PES_CODIGO"));
            objpro.setPES_NOME(rs.getString("PES_NOME"));
            objpro.setPES_FANTASIA(rs.getString("PES_FANTASIA"));
            objpro.setPES_FISICA(rs.getInt("PES_FISICA"));
            objpro.setPES_CPFCNPJ(rs.getString("PES_CPFCNPJ"));
            objpro.setPES_RGIE(rs.getString("PES_RGIE"));
            objpro.setPES_CADASTRO(rs.getDate("PES_CADASTRO"));
            objpro.setPES_ENDERECO(rs.getString("PES_ENDERECO"));
            objpro.setPES_NUMERO(rs.getString("PES_NUMERO"));
            objpro.setPES_COMPLEMENTO(rs.getString("PES_COMPLEMENTO"));
            objpro.setPES_BAIRRO(rs.getString("PES_BAIRRO"));
            objpro.setPES_CIDADE(rs.getString("PES_CIDADE"));
            objpro.setPES_UF(rs.getString("PES_UF"));
            objpro.setPES_CEP(rs.getString("PES_CEP"));
            objpro.setPES_FONE1(rs.getString("PES_FONE1"));
            objpro.setPES_FONE2(rs.getString("PES_FONE2"));
            objpro.setPES_CEL(rs.getString("PES_CELULAR"));
            objpro.setPES_SITE(rs.getString("PES_SITE"));
            objpro.setPES_EMAIL(rs.getString("PES_EMAIL"));
            objpro.setPES_ATIVO(rs.getInt("PES_ATIVO"));
            objpro.setPES_TIPO(rs.getInt("PES_TIPO"));

            lista.add(objpro);
        }
        rs.close();
        stm.close();
        return lista;

    }
    
    public int getUltimoCod() throws SQLException{
     PreparedStatement stm;
     ResultSet rs;
     int pes_codigo;
     String sql = "SELECT COALESCE(MAX(PES_CODIGO), 1) AS ULTIMO FROM PESSOA";
     
     stm = conexao.prepareStatement(sql);
     rs = stm.executeQuery();
     rs.next();
     
     pes_codigo = rs.getInt("ULTIMO");
     rs.close();
     stm.close();
     return pes_codigo;
    }
}
