package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.ProdutoModel;
import model.VendaProdutoModel;

public class ProdutoDao {

    private Connection conexao = null;

    public ProdutoDao() throws SQLException {
        this.conexao = Conexao.getConexao();
    }

    public void adicionar(ProdutoModel produto) throws SQLException {
        String sql = "INSERT INTO PRODUTO (PRO_NOME, PRO_ESTOQUE, PRO_UNIDADE, PRO_PRECO, PRO_CUSTO, PRO_ATACADO, PRO_MIN, PRO_MAX, PRO_EMBALAGEM, "
                + "PRO_PESO, PRO_DTCADASTRO, PRO_OBS, PRO_ATIVO, PRO_TIPO)"
                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setString(1, produto.getPRO_NOME());
        stm.setFloat(2, produto.getPRO_ESTOQUE());
        stm.setString(3, produto.getPRO_UNIDADE());
        stm.setFloat(4, produto.getPRO_PRECO());
        stm.setFloat(5, produto.getPRO_CUSTO());
        stm.setFloat(6, produto.getPRO_ATACADO());
        stm.setFloat(7, produto.getPRO_MIN());
        stm.setFloat(8, produto.getPRO_MAX());
        stm.setFloat(9, produto.getPRO_EMBALAGEM());
        stm.setFloat(10, produto.getPRO_PESO());
        java.sql.Date dataAtual = new java.sql.Date(new java.util.Date().getTime());
        stm.setDate(11, dataAtual);
        stm.setString(12, produto.getPRO_OBS());
        stm.setInt(13, produto.getPRO_ATIVO());
        stm.setInt(14, produto.getPRO_TIPO());

        stm.execute();
        stm.close();
    }

    public void alterar(ProdutoModel produto) throws SQLException {
        String sql = "UPDATE PRODUTO SET PRO_NOME = ?, PRO_ESTOQUE = ?, "
                + "PRO_UNIDADE = ?, PRO_PRECO = ?, PRO_CUSTO = ?, PRO_ATACADO = ?, PRO_MIN = ?, PRO_MAX = ?, PRO_EMBALAGEM = ?, PRO_PESO = ?, PRO_DTCADASTRO = ?,"
                + "PRO_OBS = ?, PRO_ATIVO = ?, PRO_TIPO = ?"
                + "WHERE PRO_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setString(1, produto.getPRO_NOME());
        stm.setFloat(2, produto.getPRO_ESTOQUE());
        stm.setString(3, produto.getPRO_UNIDADE());
        stm.setFloat(4, produto.getPRO_PRECO());
        stm.setString(5, produto.getPRO_UNIDADE());
        stm.setFloat(6, produto.getPRO_PRECO());
        stm.setFloat(7, produto.getPRO_CUSTO());
        stm.setFloat(7, produto.getPRO_ATACADO());
        stm.setFloat(8, produto.getPRO_MIN());
        stm.setFloat(9, produto.getPRO_MAX());
        stm.setFloat(10, produto.getPRO_EMBALAGEM());
        stm.setFloat(11, produto.getPRO_PESO());
        stm.setDate(12, produto.getPRO_DTCADASTRO());
        stm.setString(13, produto.getPRO_OBS());
        stm.setInt(14, produto.getPRO_ATIVO());
        stm.setInt(15, produto.getPRO_TIPO());
        stm.setInt(16, produto.getPRO_CODIGO());

        stm.execute();
        stm.close();
    }

    public void excluir(ProdutoModel produto) throws SQLException {
        String sql = "DELETE FROM PRODUTO WHERE PRO_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, produto.getPRO_CODIGO());
        stm.execute();
        stm.close();
    }
    
    public void excluirVenda(ProdutoModel  venda) throws SQLException{
        String sql = "DELETE FROM VENDA_PRODUTO WHERE PRO_CODIGO = ? ";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1,venda.getPRO_CODIGO());
        stm.execute();
        stm.close();
    }
    
     public void excluirCompra(ProdutoModel  compra) throws SQLException{
        String sql = "DELETE FROM COMPRA_PRODUTO WHERE PRO_CODIGO = ? ";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1,compra.getPRO_CODIGO());
        stm.execute();
        stm.close();
    }

    public ArrayList<ProdutoModel> consultar(String filtro) throws SQLException {
        ArrayList<ProdutoModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT * FROM PRODUTO";
        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            ProdutoModel objpro = new ProdutoModel();
            objpro.setPRO_CODIGO(rs.getInt("PRO_CODIGO"));
            objpro.setPRO_NOME(rs.getString("PRO_NOME"));
            objpro.setPRO_ESTOQUE(rs.getFloat("PRO_ESTOQUE"));
            objpro.setPRO_UNIDADE(rs.getString("PRO_UNIDADE"));
            objpro.setPRO_PRECO(rs.getFloat("PRO_PRECO"));
            objpro.setPRO_CUSTO(rs.getFloat("PRO_CUSTO"));
            objpro.setPRO_ATACADO(rs.getFloat("PRO_ATACADO"));
            objpro.setPRO_MIN(rs.getFloat("PRO_MIN"));
            objpro.setPRO_MAX(rs.getFloat("PRO_MAX"));
            objpro.setPRO_EMBALAGEM(rs.getFloat("PRO_EMBALAGEM"));
            objpro.setPRO_PESO(rs.getFloat("PRO_PESO"));
            objpro.setPRO_DTCADASTRO(rs.getDate("PRO_DTCADASTRO"));
            objpro.setPRO_OBS(rs.getString("PRO_OBS"));
            objpro.setPRO_ATIVO(rs.getInt("PRO_ATIVO"));
            objpro.setPRO_TIPO(rs.getInt("PRO_TIPO"));

            lista.add(objpro);
        }
        rs.close();
        stm.close();
        return lista;
    }

}
