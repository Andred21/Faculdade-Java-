package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ClienteModel;
import model.FormaPagtoModel;
import model.UsuarioModel;
import model.PessoaModel;
import model.VendaModel;


public class VendaDao {

    private Connection conexao = null;

    public VendaDao() throws SQLException {
        this.conexao = Conexao.getConexao();

    }

    public void adicionar(VendaModel venda) throws SQLException {

        String sql = "INSERT INTO VENDA (USU_CODIGO, CLI_CODIGO, VDA_DATA, VDA_VALOR, VDA_DESCONTO, VDA_TOTAL, VDA_OBS) "
                + " VALUES (?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, venda.getUsuario().getUSU_CODIGO());
        stm.setInt(2, venda.getCliente().getCLI_CODIGO());
        java.sql.Date dataAtual = new java.sql.Date(new java.util.Date().getTime());
        stm.setDate(3, dataAtual);
        stm.setFloat(4, venda.getVDA_VALOR());
        stm.setFloat(5, venda.getVDA_DESCONTO());
        stm.setFloat(6, venda.getVDA_TOTAL());
        stm.setString(7, venda.getVDA_OBS());
      

        stm.execute();
        stm.close();
    }

    public void alterar(VendaModel venda) throws SQLException {

        String sql = "UPDATE VENDA SET USU_CODIGO = ?, CLI_CODIGO = ?, VDA_DATA = ?, VDA_VALOR = ?, VDA_DESCONTO = ?, "
                + "VDA_TOTAL = ?, VDA_OBS = ?"
                + " WHERE VDA_CODIGO = ?";

        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setInt(1, venda.getUsuario().getUSU_CODIGO());
        stm.setInt(2, venda.getCliente().getCLI_CODIGO());
        java.sql.Date dataAtual = new java.sql.Date(new java.util.Date().getTime());
        stm.setDate(3, dataAtual);
        stm.setFloat(4, venda.getVDA_VALOR());
        stm.setFloat(5, venda.getVDA_DESCONTO());
        stm.setFloat(6, venda.getVDA_TOTAL());
        stm.setString(7, venda.getVDA_OBS());
        stm.setInt(8, venda.getVDA_CODIGO());
     

        stm.execute();
        stm.close();
    }
    
     public void excluirProdutos(VendaModel venda) throws SQLException{
        
        String sql = "DELETE FROM VENDA_PRODUTO WHERE VDA_CODIGO = ?";
 
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, venda.getVDA_CODIGO());
        stm.execute();
        stm.close();
    }

    public void excluir(VendaModel venda) throws SQLException {

        String sql = "DELETE FROM VENDA WHERE VDA_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, venda.getVDA_CODIGO());
        stm.execute();
        stm.close();

    }
    public void excluirForma(VendaModel venda) throws SQLException{
        
        String sql = "DELETE FROM VENDA_PAGTO WHERE VDA_CODIGO = ?";
 
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, venda.getVDA_CODIGO());
        stm.execute();
        stm.close();
    }

    public ArrayList<VendaModel> consultar(String filtro) throws SQLException {
        ArrayList<VendaModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT V.*, U.USU_CODIGO, U.USU_LOGIN, C.CLI_CODIGO, P.PES_CPFCNPJ, P.PES_NOME FROM VENDA V "
                + "INNER JOIN USUARIO U ON V.USU_CODIGO = U.USU_CODIGO "
                + "INNER JOIN CLIENTE C ON V.CLI_CODIGO = C.CLI_CODIGO "
                + "INNER JOIN PESSOA P ON C.PES_CODIGO = P.PES_CODIGO ";

        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            VendaModel venda = new VendaModel();
            venda.setVDA_CODIGO(rs.getInt("VDA_CODIGO"));
            venda.setVDA_DATA(rs.getDate("VDA_DATA"));
            venda.setVDA_VALOR(rs.getFloat("VDA_VALOR"));
            venda.setVDA_DESCONTO(rs.getFloat("VDA_DESCONTO"));
            venda.setVDA_TOTAL(rs.getFloat("VDA_TOTAL"));
            venda.setVDA_OBS(rs.getString("VDA_OBS"));

            UsuarioModel usuario = new UsuarioModel();
            usuario.setUSU_CODIGO(rs.getInt("USU_CODIGO"));
            usuario.setUSU_LOGIN(rs.getString("USU_LOGIN"));

            ClienteModel cliente = new ClienteModel();
            cliente.setCLI_CODIGO(rs.getInt("CLI_CODIGO"));

            PessoaModel pessoa = new PessoaModel();
            pessoa.setPES_CPFCNPJ(rs.getString("PES_CPFCNPJ"));
            pessoa.setPES_NOME(rs.getString("PES_NOME"));

            cliente.setPessoa(pessoa);
            venda.setUsuario(usuario);
            venda.setCliente(cliente);

            lista.add(venda);
        }
        rs.close();
        stm.close();
        return lista;
    }
    
    public int getUltimoCod() throws SQLException{
     PreparedStatement stm;
     ResultSet rs;
     int vda_codigo;
     String sql = "SELECT COALESCE(MAX(VDA_CODIGO), 1) AS ULTIMO FROM VENDA";
     
     stm = conexao.prepareStatement(sql);
     rs = stm.executeQuery();
     rs.next();
     
     vda_codigo = rs.getInt("ULTIMO");
     rs.close();
     stm.close();
     return vda_codigo;
    }
    
    
     public List<FormaPagtoModel> getAllFormaPagto() throws SQLException {
        List<FormaPagtoModel> forma = new ArrayList<>();
        PreparedStatement stm;
        ResultSet rs;
        
        String sql = "SELECT FPG_CODIGO FROM FORMA_PAGTO";
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
            while (rs.next()) {
                FormaPagtoModel forma2 = new FormaPagtoModel();
                forma2.setFPG_CODIGO(rs.getInt("FPG_CODIGO"));
               
               
                forma.add(forma2);
            }
        
        return forma;
    }
}
