package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.FormaPagtoModel;
import model.VendaModel;
import model.VendaPagtoModel;

public class VendaPagtoDao {

    private Connection conexao = null;

    public VendaPagtoDao() throws SQLException {
        this.conexao = Conexao.getConexao();

    }

    public void adicionar(VendaPagtoModel vendaPagto) throws SQLException {

        String sql = "INSERT INTO VENDA_PAGTO (VDA_CODIGO, FPG_CODIGO, VDP_VALOR) "
                + " VALUES (?, ?, ?)";

        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, vendaPagto.getVenda().getVDA_CODIGO());
        stm.setInt(2, vendaPagto.getFormaPagto().getFPG_CODIGO());
        stm.setFloat(3, vendaPagto.getVDP_VALOR());

        stm.execute();
        stm.close();
    }

    public void alterar(VendaPagtoModel vendaPagto) throws SQLException {

        String sql = "UPDATE VENDA_PAGTO SET VDA_CODIGO = ?, FPG_CODIGO = ?, VDP_VALOR = ? "
                + " WHERE VDP_CODIGO = ?";

        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setInt(1, vendaPagto.getVenda().getVDA_CODIGO());
        stm.setInt(2, vendaPagto.getFormaPagto().getFPG_CODIGO());
        stm.setFloat(3, vendaPagto.getVDP_VALOR());
        stm.setFloat(4, vendaPagto.getVDP_CODIGO());

        stm.execute();
        stm.close();
    }

    public void excluir(VendaPagtoModel vendaPagto) throws SQLException {

        String sql = "DELETE FROM VENDA_PAGTO WHERE VDP_CODIGO = ? ";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, vendaPagto.getVDP_CODIGO());
        stm.execute();
        stm.close();

    }

    public ArrayList<VendaPagtoModel> consultar(String filtro) throws SQLException {
        ArrayList<VendaPagtoModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT VP.*, V.VDA_CODIGO, F.FPG_CODIGO, F.FPG_NOME FROM VENDA_PAGTO VP "
                + "INNER JOIN VENDA V ON V.VDA_CODIGO = VP.VDA_CODIGO "
                + "INNER JOIN FORMA_PAGTO F ON F.FPG_CODIGO = VP.FPG_CODIGO ";

        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            VendaPagtoModel vendaPagto = new VendaPagtoModel();
            vendaPagto.setVDP_CODIGO(rs.getInt("VDP_CODIGO"));
            vendaPagto.setVDP_VALOR(rs.getFloat("VDP_VALOR"));

            VendaModel venda = new VendaModel();
            venda.setVDA_CODIGO(rs.getInt("VDA_CODIGO"));

            FormaPagtoModel forma = new FormaPagtoModel();
            forma.setFPG_CODIGO(rs.getInt("FPG_CODIGO"));
            forma.setFPG_NOME(rs.getString("FPG_NOME"));

            vendaPagto.setVenda(venda);
            vendaPagto.setFormaPagto(forma);

            lista.add(vendaPagto);
        }
        rs.close();
        stm.close();
        return lista;
    }
}
