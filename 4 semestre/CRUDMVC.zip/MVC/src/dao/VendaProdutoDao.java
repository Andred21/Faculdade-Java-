package dao;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.VendaModel;
import model.VendaProdutoModel;
import model.ProdutoModel;

public class VendaProdutoDao {

    private Connection conexao = null;

    public VendaProdutoDao() throws SQLException {
        this.conexao = Conexao.getConexao();

    }

    public void adicionar(VendaProdutoModel vendaProduto) throws SQLException {

        String sql = "INSERT INTO VENDA_PRODUTO (VDA_CODIGO, PRO_CODIGO, VEP_QTDE, VEP_PRECO, VEP_DESCONTO, VEP_TOTAL ) "
                + " VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, vendaProduto.getVenda().getVDA_CODIGO());
        stm.setInt(2, vendaProduto.getProduto().getPRO_CODIGO());
        stm.setFloat(3, vendaProduto.getVEP_QTDE());
        stm.setFloat(4, vendaProduto.getVEP_PRECO());
        stm.setFloat(5, vendaProduto.getVEP_DESCONTO());
        float total = (vendaProduto.getVEP_QTDE() * vendaProduto.getVEP_PRECO() - vendaProduto.getVEP_DESCONTO());
        stm.setFloat(6, total);

        stm.execute();
        stm.close();
    }

    public void alterar(VendaProdutoModel vendaProduto) throws SQLException {

        String sql = "UPDATE VENDA_PRODUTO SET VDA_CODIGO = ?, PRO_CODIGO = ?, VEP_QTDE = ?, VEP_PRECO = ?, VEP_DESCONTO = ?, "
                + " VEP_TOTAL = ? "
                + " WHERE VEP_CODIGO = ?";

        PreparedStatement stm = conexao.prepareStatement(sql);

        stm.setInt(1, vendaProduto.getVenda().getVDA_CODIGO());
        stm.setInt(2, vendaProduto.getProduto().getPRO_CODIGO());
        stm.setFloat(3, vendaProduto.getVEP_QTDE());
        stm.setFloat(4, vendaProduto.getVEP_PRECO());
        stm.setFloat(5, vendaProduto.getVEP_DESCONTO());
        stm.setFloat(6, vendaProduto.getVEP_TOTAL());
        stm.setFloat(7, vendaProduto.getVEP_CODIGO());

        stm.execute();
        stm.close();
    }

    public void excluir(VendaProdutoModel vendaProduto) throws SQLException {

        String sql = "DELETE FROM VENDA_PRODUTO WHERE VEP_CODIGO = ?";
        PreparedStatement stm = conexao.prepareStatement(sql);
        stm.setInt(1, vendaProduto.getVEP_CODIGO());
        stm.execute();
        stm.close();

    }
    
  
    
    
  

    public ArrayList<VendaProdutoModel> consultar(String filtro) throws SQLException {
        ArrayList<VendaProdutoModel> lista = null;
        PreparedStatement stm;
        ResultSet rs;
        String sql = "SELECT VP.*, V.VDA_CODIGO, P.PRO_CODIGO, P.PRO_NOME FROM VENDA_PRODUTO VP "
                + "INNER JOIN VENDA V ON V.VDA_CODIGO = VP.VDA_CODIGO "
                + "INNER JOIN PRODUTO P ON P.PRO_CODIGO = VP.PRO_CODIGO ";

        if (!filtro.equals("")) {
            sql += " WHERE " + filtro;
        }
        stm = conexao.prepareStatement(sql);
        rs = stm.executeQuery();
        lista = new ArrayList<>();

        while (rs.next()) {
            VendaProdutoModel vendaProduto = new VendaProdutoModel();
            vendaProduto.setVEP_CODIGO(rs.getInt("VEP_CODIGO"));
            vendaProduto.setVEP_QTDE(rs.getFloat("VEP_QTDE"));
            vendaProduto.setVEP_PRECO(rs.getFloat("VEP_PRECO"));
            vendaProduto.setVEP_DESCONTO(rs.getFloat("VEP_DESCONTO"));
            vendaProduto.setVEP_TOTAL(rs.getFloat("VEP_TOTAL"));

            VendaModel venda = new VendaModel();
            venda.setVDA_CODIGO(rs.getInt("VDA_CODIGO"));

            ProdutoModel produto = new ProdutoModel();
            produto.setPRO_CODIGO(rs.getInt("PRO_CODIGO"));
            produto.setPRO_NOME(rs.getString("PRO_NOME"));

            vendaProduto.setVenda(venda);
            vendaProduto.setProduto(produto);

            lista.add(vendaProduto);
        }
        rs.close();
        stm.close();
        return lista;

    }
}
