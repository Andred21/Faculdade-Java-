
package model;


public class ClienteModel {
    private int CLI_CODIGO;
    private PessoaModel pessoa;
    private float CLI_LIMITECRED;
    
    public ClienteModel(){
        
    }

    public ClienteModel(int CLI_CODIGO, PessoaModel pessoa, float CLI_LIMITECRED) {
        this.CLI_CODIGO = CLI_CODIGO;
        this.pessoa = pessoa;
        this.CLI_LIMITECRED = CLI_LIMITECRED;
    }

    public int getCLI_CODIGO() {
        return CLI_CODIGO;
    }

    public void setCLI_CODIGO(int CLI_CODIGO) {
        this.CLI_CODIGO = CLI_CODIGO;
    }

    public PessoaModel getPessoa() {
        return pessoa;
    }

    public void setPessoa(PessoaModel pessoa) {
        this.pessoa = pessoa;
    }

    public float getCLI_LIMITECRED() {
        return CLI_LIMITECRED;
    }

    public void setCLI_LIMITECRED(float CLI_LIMITECRED) {
        this.CLI_LIMITECRED = CLI_LIMITECRED;
    }
     @Override
    public String toString() {
        return String.valueOf(CLI_CODIGO);
    }
    
    
    
}
