
package model;

import controller.UsuarioController;
import java.sql.Date;


public class CompraModel {
    private int CPR_CODIGO;
    private UsuarioModel usuario;
    private FornecedorModel fornecedor;
    private Date CPR_EMISSAO;
    private float CPR_VALOR;
    private float CPR_DESCONTO;
    private float CPR_TOTAL;
    private Date CPR_DTTENTRADA;
    private String CPR_OBS;
    
    public CompraModel(){
        
    }

    public CompraModel(int CPR_CODIGO, UsuarioModel usuario, FornecedorModel fornecedor, Date CPR_EMISSAO, float CPR_VALOR, float CPR_DESCONTO, float CPR_TOTAL, Date CPR_DTTENTRADA, String CPR_OBS) {
        this.CPR_CODIGO = CPR_CODIGO;
        this.usuario = usuario;
        this.fornecedor = fornecedor;
        this.CPR_EMISSAO = CPR_EMISSAO;
        this.CPR_VALOR = CPR_VALOR;
        this.CPR_DESCONTO = CPR_DESCONTO;
        this.CPR_TOTAL = CPR_TOTAL;
        this.CPR_DTTENTRADA = CPR_DTTENTRADA;
        this.CPR_OBS = CPR_OBS;
    }

    public int getCPR_CODIGO() {
        return CPR_CODIGO;
    }

    public void setCPR_CODIGO(int CPR_CODIGO) {
        this.CPR_CODIGO = CPR_CODIGO;
    }

    public UsuarioModel getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioModel usuario) {
        this.usuario = usuario;
    }

    public FornecedorModel getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(FornecedorModel fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Date getCPR_EMISSAO() {
        return CPR_EMISSAO;
    }

    public void setCPR_EMISSAO(Date CPR_EMISSAO) {
        this.CPR_EMISSAO = CPR_EMISSAO;
    }

    public float getCPR_VALOR() {
        return CPR_VALOR;
    }

    public void setCPR_VALOR(float CPR_VALOR) {
        this.CPR_VALOR = CPR_VALOR;
    }

    public float getCPR_DESCONTO() {
        return CPR_DESCONTO;
    }

    public void setCPR_DESCONTO(float CPR_DESCONTO) {
        this.CPR_DESCONTO = CPR_DESCONTO;
    }

    public float getCPR_TOTAL() {
        return CPR_TOTAL;
    }

    public void setCPR_TOTAL(float CPR_TOTAL) {
        this.CPR_TOTAL = CPR_TOTAL;
    }

    public Date getCPR_DTTENTRADA() {
        return CPR_DTTENTRADA;
    }

    public void setCPR_DTTENTRADA(Date CPR_DTTENTRADA) {
        this.CPR_DTTENTRADA = CPR_DTTENTRADA;
    }

    public String getCPR_OBS() {
        return CPR_OBS;
    }

    public void setCPR_OBS(String CPR_OBS) {
        this.CPR_OBS = CPR_OBS;
    }
    
    
}
