
package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CompraProdutoModel {
    private int CPP_CODIGO;
    private CompraModel compra;
    private ProdutoModel produto;
    private float CPP_QTDE;
    private float CPP_PRECO;
    private float CPP_DESCONTO;
    private float CPP_TOTAL;
    
    public CompraProdutoModel(){
        
    }

    public CompraProdutoModel(int CPP_CODIGO, CompraModel compra, ProdutoModel produto, float CPP_QTDE, float CPP_PRECO, float CPP_DESCONTO, float CPP_TOTAL) {
        this.CPP_CODIGO = CPP_CODIGO;
        this.compra = compra;
        this.produto = produto;
        this.CPP_QTDE = CPP_QTDE;
        this.CPP_PRECO = CPP_PRECO;
        this.CPP_DESCONTO = CPP_DESCONTO;
        this.CPP_TOTAL = CPP_TOTAL;
    }

    public int getCPP_CODIGO() {
        return CPP_CODIGO;
    }

    public void setCPP_CODIGO(int CPP_CODIGO) {
        this.CPP_CODIGO = CPP_CODIGO;
    }

    public CompraModel getCompra() {
        return compra;
    }

    public void setCompra(CompraModel compra) {
        this.compra = compra;
    }

    public ProdutoModel getProduto() {
        return produto;
    }

    public void setProduto(ProdutoModel produto) {
        this.produto = produto;
    }

    public float getCPP_QTDE() {
        return CPP_QTDE;
    }

    public void setCPP_QTDE(float CPP_QTDE) {
        this.CPP_QTDE = CPP_QTDE;
    }

    public float getCPP_PRECO() {
        return CPP_PRECO;
    }

    public void setCPP_PRECO(float CPP_PRECO) {
        this.CPP_PRECO = CPP_PRECO;
    }

    public float getCPP_DESCONTO() {
        return CPP_DESCONTO;
    }

    public void setCPP_DESCONTO(float CPP_DESCONTO) {
        this.CPP_DESCONTO = CPP_DESCONTO;
    }

    public float getCPP_TOTAL() {
        return CPP_TOTAL;
    }

    public void setCPP_TOTAL(float CPP_TOTAL) {
        this.CPP_TOTAL = CPP_TOTAL;
    }

   
    
    
   
}
