
package model;

public class FormaPagtoModel {
    private int FPG_CODIGO;
    private String FPG_NOME;
    private int FPG_ATIVO;
    
    public FormaPagtoModel(){
        
    }

    public FormaPagtoModel(int FPG_CODIGO, String FPG_NOME, int FPG_ATIVO) {
        this.FPG_CODIGO = FPG_CODIGO;
        this.FPG_NOME = FPG_NOME;
        this.FPG_ATIVO = FPG_ATIVO;
    }

    public int getFPG_CODIGO() {
        return FPG_CODIGO;
    }

    public void setFPG_CODIGO(int FPG_CODIGO) {
        this.FPG_CODIGO = FPG_CODIGO;
    }

    public String getFPG_NOME() {
        return FPG_NOME;
    }

    public void setFPG_NOME(String FPG_NOME) {
        this.FPG_NOME = FPG_NOME;
    }

    public int getFPG_ATIVO() {
        return FPG_ATIVO;
    }

    public void setFPG_ATIVO(int FPG_ATIVO) {
        this.FPG_ATIVO = FPG_ATIVO;
    }
     @Override
    public String toString() {
        return String.valueOf(FPG_CODIGO);
    }
    
}
