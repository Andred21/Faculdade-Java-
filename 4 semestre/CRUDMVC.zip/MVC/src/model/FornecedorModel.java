/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author GC Info Gamer
 */
public class FornecedorModel  {
    private int FOR_CODIGO;
    private PessoaModel pessoa;
    private String FOR_CONTATO;
    
    public FornecedorModel(){
        
    }

    public FornecedorModel(int FOR_CODIGO, PessoaModel pessoa, String FOR_CONTATO) {
        this.FOR_CODIGO = FOR_CODIGO;
        this.pessoa = pessoa;
        this.FOR_CONTATO = FOR_CONTATO;
    }

    public int getFOR_CODIGO() {
        return FOR_CODIGO;
    }

    public void setFOR_CODIGO(int FOR_CODIGO) {
        this.FOR_CODIGO = FOR_CODIGO;
    }

    public PessoaModel getPessoa() {
        return pessoa;
    }

    public void setPessoa(PessoaModel pessoa) {
        this.pessoa = pessoa;
    }

    public String getFOR_CONTATO() {
        return FOR_CONTATO;
    }

    public void setFOR_CONTATO(String FOR_CONTATO) {
        this.FOR_CONTATO = FOR_CONTATO;
    }
    
    public void associarPessoaModel(){
        this.pessoa = pessoa;
    }
     
    public void desassociarPessoaModel(){
        this.pessoa = null;
    }
    
    @Override
    public String toString() {
        return String.valueOf(FOR_CODIGO);
    }
}
