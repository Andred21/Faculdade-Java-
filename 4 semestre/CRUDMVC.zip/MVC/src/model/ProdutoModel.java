package model;

import java.sql.Date;

public class ProdutoModel {

    private int PRO_CODIGO;
    private String PRO_NOME;
    private float PRO_ESTOQUE;
    private String PRO_UNIDADE;
    private float PRO_PRECO;
    private float PRO_CUSTO;
    private float PRO_ATACADO;
    private float PRO_MIN;
    private float PRO_MAX;
    private float PRO_EMBALAGEM;
    private float PRO_PESO;
    private Date PRO_DTCADASTRO;
    private String PRO_OBS;
    private int PRO_ATIVO;
    private int PRO_TIPO;
    
    public ProdutoModel(){
        
    }
    
    public ProdutoModel(int PRO_CODIGO, String PRO_NOME, float PRO_ESTOQUE, String PRO_UNIDADE, float PRO_PRECO, float PRO_CUSTO, float PRO_ATACADO, float PRO_MIN, float PRO_MAX, float PRO_EMBALAGEM, float PRO_PESO, Date PRO_DTCADASTRO, String PRO_OBS, int PRO_ATIVO, int PRO_TIPO) {
        this.PRO_CODIGO = PRO_CODIGO;
        this.PRO_NOME = PRO_NOME;
        this.PRO_ESTOQUE = PRO_ESTOQUE;
        this.PRO_UNIDADE = PRO_UNIDADE;
        this.PRO_PRECO = PRO_PRECO;
        this.PRO_CUSTO = PRO_CUSTO;
        this.PRO_ATACADO = PRO_ATACADO;
        this.PRO_MIN = PRO_MIN;
        this.PRO_MAX = PRO_MAX;
        this.PRO_EMBALAGEM = PRO_EMBALAGEM;
        this.PRO_PESO = PRO_PESO;
        this.PRO_DTCADASTRO = PRO_DTCADASTRO;
        this.PRO_OBS = PRO_OBS;
        this.PRO_ATIVO = PRO_ATIVO;
        this.PRO_TIPO = PRO_TIPO;
    }

    public int getPRO_CODIGO() {
        return PRO_CODIGO;
    }

    public void setPRO_CODIGO(int PRO_CODIGO) {
        this.PRO_CODIGO = PRO_CODIGO;
    }

    public String getPRO_NOME() {
        return PRO_NOME;
    }

    public void setPRO_NOME(String PRO_NOME) {
        this.PRO_NOME = PRO_NOME;
    }

    public float getPRO_ESTOQUE() {
        return PRO_ESTOQUE;
    }

    public void setPRO_ESTOQUE(float PRO_ESTOQUE) {
        this.PRO_ESTOQUE = PRO_ESTOQUE;
    }

    public String getPRO_UNIDADE() {
        return PRO_UNIDADE;
    }

    public void setPRO_UNIDADE(String PRO_UNIDADE) {
        this.PRO_UNIDADE = PRO_UNIDADE;
    }

    public float getPRO_PRECO() {
        return PRO_PRECO;
    }

    public void setPRO_PRECO(float PRO_PRECO) {
        this.PRO_PRECO = PRO_PRECO;
    }

    public float getPRO_CUSTO() {
        return PRO_CUSTO;
    }

    public void setPRO_CUSTO(float PRO_CUSTO) {
        this.PRO_CUSTO = PRO_CUSTO;
    }

    public float getPRO_ATACADO() {
        return PRO_ATACADO;
    }

    public void setPRO_ATACADO(float PRO_ATACADO) {
        this.PRO_ATACADO = PRO_ATACADO;
    }

    public float getPRO_MIN() {
        return PRO_MIN;
    }

    public void setPRO_MIN(float PRO_MIN) {
        this.PRO_MIN = PRO_MIN;
    }

    public float getPRO_MAX() {
        return PRO_MAX;
    }

    public void setPRO_MAX(float PRO_MAX) {
        this.PRO_MAX = PRO_MAX;
    }

    public float getPRO_EMBALAGEM() {
        return PRO_EMBALAGEM;
    }

    public void setPRO_EMBALAGEM(float PRO_EMBALAGEM) {
        this.PRO_EMBALAGEM = PRO_EMBALAGEM;
    }

    public float getPRO_PESO() {
        return PRO_PESO;
    }

    public void setPRO_PESO(float PRO_PESO) {
        this.PRO_PESO = PRO_PESO;
    }

    public Date getPRO_DTCADASTRO() {
        return PRO_DTCADASTRO;
    }

    public void setPRO_DTCADASTRO(Date PRO_DTCADASTRO) {
        this.PRO_DTCADASTRO = PRO_DTCADASTRO;
    }

    public String getPRO_OBS() {
        return PRO_OBS;
    }

    public void setPRO_OBS(String PRO_OBS) {
        this.PRO_OBS = PRO_OBS;
    }

    public int getPRO_ATIVO() {
        return PRO_ATIVO;
    }

    public void setPRO_ATIVO(int PRO_ATIVO) {
        this.PRO_ATIVO = PRO_ATIVO;
    }

    public int getPRO_TIPO() {
        return PRO_TIPO;
    }

    public void setPRO_TIPO(int PRO_TIPO) {
        this.PRO_TIPO = PRO_TIPO;
    }

    @Override
     public String toString() {
        return String.valueOf(PRO_CODIGO);
    }
 

}
