/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author GC Info Gamer
 */
public class VendaModel {

    private int VDA_CODIGO;
    private UsuarioModel usuario;
    private ClienteModel cliente;
    private Date VDA_DATA;
    private float VDA_VALOR;
    private float VDA_DESCONTO;
    private float VDA_TOTAL;
    private String VDA_OBS;
    
    public VendaModel(){
        
    }

    public VendaModel(int VDA_CODIGO, UsuarioModel usuario, ClienteModel cliente, Date VDA_DATA, float VDA_VALOR, float VDA_DESCONTO, float VDA_TOTAL, String VDA_OBS) {
        this.VDA_CODIGO = VDA_CODIGO;
        this.usuario = usuario;
        this.cliente = cliente;
        this.VDA_DATA = VDA_DATA;
        this.VDA_VALOR = VDA_VALOR;
        this.VDA_DESCONTO = VDA_DESCONTO;
        this.VDA_TOTAL = VDA_TOTAL;
        this.VDA_OBS = VDA_OBS;
    }

    public int getVDA_CODIGO() {
        return VDA_CODIGO;
    }

    public void setVDA_CODIGO(int VDA_CODIGO) {
        this.VDA_CODIGO = VDA_CODIGO;
    }

    public UsuarioModel getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioModel usuario) {
        this.usuario = usuario;
    }

    public ClienteModel getCliente() {
        return cliente;
    }

    public void setCliente(ClienteModel cliente) {
        this.cliente = cliente;
    }

    public Date getVDA_DATA() {
        return VDA_DATA;
    }

    public void setVDA_DATA(Date VDA_DATA) {
        this.VDA_DATA = VDA_DATA;
    }

    public float getVDA_VALOR() {
        return VDA_VALOR;
    }

    public void setVDA_VALOR(float VDA_VALOR) {
        this.VDA_VALOR = VDA_VALOR;
    }

    public float getVDA_DESCONTO() {
        return VDA_DESCONTO;
    }

    public void setVDA_DESCONTO(float VDA_DESCONTO) {
        this.VDA_DESCONTO = VDA_DESCONTO;
    }

    public float getVDA_TOTAL() {
        return VDA_TOTAL;
    }

    public void setVDA_TOTAL(float VDA_TOTAL) {
        this.VDA_TOTAL = VDA_TOTAL;
    }

    public String getVDA_OBS() {
        return VDA_OBS;
    }

    public void setVDA_OBS(String VDA_OBS) {
        this.VDA_OBS = VDA_OBS;
    }
    
    
    
}
