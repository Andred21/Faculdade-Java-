
package model;


public class VendaPagtoModel {
    private int VDP_CODIGO;
    private VendaModel venda;
    private FormaPagtoModel formapagto;
    private float VDP_VALOR;
    
    public VendaPagtoModel(){
        
    }

    public VendaPagtoModel(int VDP_CODIGO, VendaModel venda, FormaPagtoModel formapagto, float VDP_VALOR) {
        this.VDP_CODIGO = VDP_CODIGO;
        this.venda = venda;
        this.formapagto = formapagto;
        this.VDP_VALOR = VDP_VALOR;
    }

    public int getVDP_CODIGO() {
        return VDP_CODIGO;
    }

    public void setVDP_CODIGO(int VDP_CODIGO) {
        this.VDP_CODIGO = VDP_CODIGO;
    }

    public VendaModel getVenda() {
        return venda;
    }

    public void setVenda(VendaModel venda) {
        this.venda = venda;
    }

    public FormaPagtoModel getFormaPagto() {
        return formapagto;
    }

    public void setFormaPagto(FormaPagtoModel formaPagto) {
        this.formapagto = formaPagto;
    }

    public float getVDP_VALOR() {
        return VDP_VALOR;
    }

    public void setVDP_VALOR(float VDP_VALOR) {
        this.VDP_VALOR = VDP_VALOR;
    }
    
    
}
