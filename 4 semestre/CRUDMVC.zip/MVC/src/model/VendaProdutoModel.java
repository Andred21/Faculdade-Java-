package model;

public class VendaProdutoModel {

    private int VEP_CODIGO;
    private VendaModel venda;
    private ProdutoModel produto;
    private float VEP_QTDE;
    private float VEP_PRECO;
    private float VEP_DESCONTO;
    private float VEP_TOTAL;
    
    public VendaProdutoModel(){
        
    }

    public VendaProdutoModel(int VEP_CODIGO, VendaModel venda, ProdutoModel produto, float VEP_QTDE, float VEP_PRECO, float VEP_DESCONTO, float VEP_TOTAL) {
        this.VEP_CODIGO = VEP_CODIGO;
        this.venda = venda;
        this.produto = produto;
        this.VEP_QTDE = VEP_QTDE;
        this.VEP_PRECO = VEP_PRECO;
        this.VEP_DESCONTO = VEP_DESCONTO;
        this.VEP_TOTAL = VEP_TOTAL;
    }

    public int getVEP_CODIGO() {
        return VEP_CODIGO;
    }

    public void setVEP_CODIGO(int VEP_CODIGO) {
        this.VEP_CODIGO = VEP_CODIGO;
    }

    public VendaModel getVenda() {
        return venda;
    }

    public void setVenda(VendaModel venda) {
        this.venda = venda;
    }

    public ProdutoModel getProduto() {
        return produto;
    }

    public void setProduto(ProdutoModel produto) {
        this.produto = produto;
    }

    public float getVEP_QTDE() {
        return VEP_QTDE;
    }

    public void setVEP_QTDE(float VEP_QTDE) {
        this.VEP_QTDE = VEP_QTDE;
    }

    public float getVEP_PRECO() {
        return VEP_PRECO;
    }

    public void setVEP_PRECO(float VEP_PRECO) {
        this.VEP_PRECO = VEP_PRECO;
    }

    public float getVEP_DESCONTO() {
        return VEP_DESCONTO;
    }

    public void setVEP_DESCONTO(float VEP_DESCONTO) {
        this.VEP_DESCONTO = VEP_DESCONTO;
    }

    public float getVEP_TOTAL() {
        return VEP_TOTAL;
    }

    public void setVEP_TOTAL(float VEP_TOTAL) {
        this.VEP_TOTAL = VEP_TOTAL;
    }
    
    

}
