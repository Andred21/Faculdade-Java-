/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import conexao.Conexao;
import controller.UsuarioController;
import dao.ClienteDao;
import dao.CompraDao;
import dao.FornecedorDao;
import java.sql.SQLException;
import model.UsuarioModel;
import view.UsuarioView;
import model.FornecedorModel;
import dao.FornecedorDao;
import java.sql.*;
import model.ClienteModel;
import model.CompraModel;
import model.PessoaModel;
import view.TelaLoginView;

/**
 *
 * @author celio
 */
public class MVC_DAO {

    Conexao objconexao;
    TelaLoginView login;

    public MVC_DAO() throws SQLException {
        objconexao = new Conexao();
        login = new TelaLoginView();
      
     
                
    }

    public static void main(String[] args) throws SQLException  {
        MVC_DAO mvc_dao = new MVC_DAO();

    }

}
