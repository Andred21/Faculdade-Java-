package view;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import model.CompraModel;

public class CompraTableModel extends AbstractTableModel{
        private ArrayList<CompraModel> linhas;
    String[] colunas;

    public CompraTableModel(ArrayList<CompraModel> arraycompraproduto, String[] colunas) {
        this.colunas = colunas;
        linhas = arraycompraproduto;
    }

    //Retorna a quantidade de colunas do modelo, que no caso será fixa
    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    //Retorna a quantidade de linhas atual do objeto, que no caso é o tamnho da lista
    @Override
    public int getRowCount() {
        return linhas.size();
    }

    //Retorna o nome da coluna, recebendo seu índice
    @Override
    public String getColumnName(int indiceColuna) {
        return colunas[indiceColuna];
    }

    @Override
    public Object getValueAt(int row, int col) {
        CompraModel compramodel = (CompraModel) linhas.get(row);
        switch (col) {
            case 0:
                return compramodel.getCPR_CODIGO();
            case 1:
                return compramodel.getUsuario().getUSU_CODIGO();
            case 2:
                return compramodel.getFornecedor().getFOR_CODIGO();
            case 3:
                return compramodel.getCPR_VALOR();
            case 4:
                return compramodel.getCPR_DESCONTO();   
            case 5:
                return compramodel.getCPR_TOTAL();
            default:
                return null;
        }
    }

    //Adicionamos várias linhas na tabela de uma vez, recebendo um List de UsuarioModel
    public void addLista(ArrayList<CompraModel> compraproduto) {
        int tamanhoAntigo = getRowCount();

        //Adiciona os usuários
        linhas.addAll(compraproduto);

        //Aqui reportamos a mudança para o JTable, assim ele pode se redesenhar, para visualizarmos a alteração
        fireTableRowsInserted(tamanhoAntigo, getRowCount() - 1);
    }
}
    

