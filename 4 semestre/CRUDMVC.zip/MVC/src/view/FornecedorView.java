package view;

import controller.ClienteController;
import controller.FornecedorController;
import controller.UsuarioController;
import java.awt.Dimension;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import model.FornecedorModel;
import model.PessoaModel;

public class FornecedorView extends javax.swing.JFrame {

    private String operacao;
    private String colunas[] = {"ID", "Nome", "Fantasia", "Cnpj", "Endereço", "Nº", "Telefone", "Ativo"};
    // esse objeto será vinculado com a tabela
    // selecione o objeto tabela, clique em PROPRIEDADES e encontre MODEL
    // no combo "Definir Propriedades" escolha "Código Personalizado"
    // digite o objeto DefaultTableModel, neste exemplo é tabela(criado logo abaixo)
    private ArrayList<FornecedorModel> lista;
    private FornecedorTableModel tabela;

    private String getOperacao() {
        return operacao;
    }

    private void setOperacao(String operacao) {
        Boolean ativar = (operacao.equals("") ? false : true);
        // operacao=""(consulta), operacao="incluir"(inclusão), operacao="alterar"(alteração)
        this.operacao = operacao;
        btnGRAVAR.setEnabled(ativar);
    }

    public FornecedorView() {
        this.setPreferredSize(new Dimension(750, 650));
        initComponents();
        setOperacao(""); // inicializa o form no modo CONSULTA

        consultar();
        // adiciona evento para qdo navegar no JTable, atualizar os dados nos JTextField´s
        tblConsulta.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent evt) {
                if (evt.getValueIsAdjusting()) {
                    return;
                }
                int selecionado = tblConsulta.getSelectedRow();
                if (selecionado >= 0) {
                    mostrar(lista.get(selecionado));
                }
            }
        });
        setVisible(true);
        pack();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jCheckBox1 = new javax.swing.JCheckBox();
        jToolBar1 = new javax.swing.JToolBar();
        btnPRIMEIRO = new javax.swing.JButton();
        btnANTERIOR = new javax.swing.JButton();
        btnPROXIMO = new javax.swing.JButton();
        btnULTIMO = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        btnINCLUIR = new javax.swing.JButton();
        btnALTERAR = new javax.swing.JButton();
        btnEXCLUIR = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        btnGRAVAR = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JToolBar.Separator();
        btnSAIR = new javax.swing.JButton();
        lblTitulo = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        painelDADOS = new javax.swing.JPanel();
        lblUSU_CODIGO = new javax.swing.JLabel();
        lblUSU_NOME = new javax.swing.JLabel();
        lblUSU_LOGIN = new javax.swing.JLabel();
        edtUSU_CODIGO = new javax.swing.JTextField();
        edtUSU_NOME = new javax.swing.JTextField();
        edtUSU_LOGIN = new javax.swing.JTextField();
        lblUSU_SENHA = new javax.swing.JLabel();
        edtPES_CPFCNPJ = new javax.swing.JTextField();
        lblPES_RGIE = new javax.swing.JLabel();
        chkUSU_ATIVO = new javax.swing.JCheckBox();
        lblPES_ENDERECO = new javax.swing.JLabel();
        edtPES_RGIE = new javax.swing.JTextField();
        edtPES_ENDERECO = new javax.swing.JTextField();
        lblPES_NUMERO = new javax.swing.JLabel();
        lblPES_COMPLEMENTO = new javax.swing.JLabel();
        lblPES_CODIGO = new javax.swing.JLabel();
        lblPES_CIDADE = new javax.swing.JLabel();
        edtPES_NUMERO = new javax.swing.JTextField();
        edtPES_COMPLEMENTO = new javax.swing.JTextField();
        edtPES_BAIRRO = new javax.swing.JTextField();
        edtPES_CIDADE = new javax.swing.JTextField();
        boxPES_UF = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        lblPES_CEP = new javax.swing.JLabel();
        edtPES_CEP = new javax.swing.JTextField();
        chkPES_FISICA = new javax.swing.JCheckBox();
        lblPES_FONE2 = new javax.swing.JLabel();
        edtPES_FONE1 = new javax.swing.JTextField();
        lblPES_FONE1 = new javax.swing.JLabel();
        lblPES_CEL = new javax.swing.JLabel();
        edtPES_FONE2 = new javax.swing.JTextField();
        edtPES_CEL = new javax.swing.JTextField();
        lblPES_SITE = new javax.swing.JLabel();
        edtPES_SITE = new javax.swing.JTextField();
        lblPES_EMAIL = new javax.swing.JLabel();
        edtPES_EMAIL = new javax.swing.JTextField();
        lblCLI_LIMITECRED = new javax.swing.JLabel();
        edtCLI_LIMITECRED = new javax.swing.JTextField();
        chkPES_TIPO = new javax.swing.JCheckBox();
        edtPES_CODIGO = new javax.swing.JTextField();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        painelCONSULTA = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblCONS_ID = new javax.swing.JLabel();
        edtCONS_ID1 = new javax.swing.JTextField();
        lblCodigo2 = new javax.swing.JLabel();
        edtCONS_ID2 = new javax.swing.JTextField();
        btnConsulta = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        lblCONS_NOME = new javax.swing.JLabel();
        edtCONS_NOME = new javax.swing.JTextField();
        lblCONS_LOGIN = new javax.swing.JLabel();
        edtCONS_LOGIN = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblConsulta = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MVC - Cadastro de Usuários");
        setFocusable(false);
        getContentPane().setLayout(null);

        jToolBar1.setRollover(true);

        btnPRIMEIRO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/primeiro.png"))); // NOI18N
        btnPRIMEIRO.setText("Primeiro");
        btnPRIMEIRO.setFocusable(false);
        btnPRIMEIRO.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPRIMEIRO.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnPRIMEIRO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPRIMEIROActionPerformed(evt);
            }
        });
        jToolBar1.add(btnPRIMEIRO);

        btnANTERIOR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/anterior.png"))); // NOI18N
        btnANTERIOR.setText("Anterior");
        btnANTERIOR.setFocusable(false);
        btnANTERIOR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnANTERIOR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnANTERIOR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnANTERIORActionPerformed(evt);
            }
        });
        jToolBar1.add(btnANTERIOR);

        btnPROXIMO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/proximo.png"))); // NOI18N
        btnPROXIMO.setText("Próximo");
        btnPROXIMO.setFocusable(false);
        btnPROXIMO.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnPROXIMO.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnPROXIMO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPROXIMOActionPerformed(evt);
            }
        });
        jToolBar1.add(btnPROXIMO);

        btnULTIMO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/ultimo.png"))); // NOI18N
        btnULTIMO.setText("Último");
        btnULTIMO.setFocusable(false);
        btnULTIMO.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnULTIMO.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnULTIMO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnULTIMOActionPerformed(evt);
            }
        });
        jToolBar1.add(btnULTIMO);

        jSeparator1.setSeparatorSize(new java.awt.Dimension(30, 30));
        jToolBar1.add(jSeparator1);

        btnINCLUIR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/novo.png"))); // NOI18N
        btnINCLUIR.setText("Novo");
        btnINCLUIR.setFocusable(false);
        btnINCLUIR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnINCLUIR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnINCLUIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnINCLUIRActionPerformed(evt);
            }
        });
        jToolBar1.add(btnINCLUIR);

        btnALTERAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/alterar.png"))); // NOI18N
        btnALTERAR.setText("Alterar");
        btnALTERAR.setFocusable(false);
        btnALTERAR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnALTERAR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnALTERAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnALTERARActionPerformed(evt);
            }
        });
        jToolBar1.add(btnALTERAR);

        btnEXCLUIR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/excluir.png"))); // NOI18N
        btnEXCLUIR.setText("Excluir");
        btnEXCLUIR.setFocusable(false);
        btnEXCLUIR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEXCLUIR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEXCLUIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEXCLUIRActionPerformed(evt);
            }
        });
        jToolBar1.add(btnEXCLUIR);

        jSeparator2.setSeparatorSize(new java.awt.Dimension(30, 30));
        jToolBar1.add(jSeparator2);

        btnGRAVAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/gravar.png"))); // NOI18N
        btnGRAVAR.setText("Gravar");
        btnGRAVAR.setFocusable(false);
        btnGRAVAR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGRAVAR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGRAVAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGRAVARActionPerformed(evt);
            }
        });
        jToolBar1.add(btnGRAVAR);

        jSeparator3.setSeparatorSize(new java.awt.Dimension(30, 30));
        jToolBar1.add(jSeparator3);

        btnSAIR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/sair.png"))); // NOI18N
        btnSAIR.setText("Sair");
        btnSAIR.setFocusable(false);
        btnSAIR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnSAIR.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnSAIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSAIRActionPerformed(evt);
            }
        });
        jToolBar1.add(btnSAIR);

        getContentPane().add(jToolBar1);
        jToolBar1.setBounds(0, 0, 730, 71);

        lblTitulo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblTitulo.setText("Cadastro de Fornecedores");
        getContentPane().add(lblTitulo);
        lblTitulo.setBounds(210, 70, 460, 29);

        lblUSU_CODIGO.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblUSU_CODIGO.setText("Código");

        lblUSU_NOME.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblUSU_NOME.setText("Nome");

        lblUSU_LOGIN.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblUSU_LOGIN.setText("Fantasia");

        edtUSU_CODIGO.setEditable(false);
        edtUSU_CODIGO.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        edtUSU_CODIGO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtUSU_CODIGOActionPerformed(evt);
            }
        });

        edtUSU_NOME.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        edtUSU_NOME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtUSU_NOMEActionPerformed(evt);
            }
        });

        edtUSU_LOGIN.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        lblUSU_SENHA.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblUSU_SENHA.setText("Cpf");

        edtPES_CPFCNPJ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_CPFCNPJActionPerformed(evt);
            }
        });

        lblPES_RGIE.setText("Rg");

        chkUSU_ATIVO.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        chkUSU_ATIVO.setText("ATIVO?");
        chkUSU_ATIVO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkUSU_ATIVOActionPerformed(evt);
            }
        });

        lblPES_ENDERECO.setText("Endereço");

        edtPES_RGIE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_RGIEActionPerformed(evt);
            }
        });

        edtPES_ENDERECO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_ENDERECOActionPerformed(evt);
            }
        });

        lblPES_NUMERO.setText("Nº");

        lblPES_COMPLEMENTO.setText("Complemento");

        lblPES_CODIGO.setText("Bairro");

        lblPES_CIDADE.setText("Cidade");

        edtPES_NUMERO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_NUMEROActionPerformed(evt);
            }
        });

        edtPES_BAIRRO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_BAIRROActionPerformed(evt);
            }
        });

        edtPES_CIDADE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_CIDADEActionPerformed(evt);
            }
        });

        boxPES_UF.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "RJ", "SP", "MG", "ES" }));
        boxPES_UF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxPES_UFActionPerformed(evt);
            }
        });

        jLabel1.setText("Uf");

        lblPES_CEP.setText("Cep");

        edtPES_CEP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_CEPActionPerformed(evt);
            }
        });

        chkPES_FISICA.setText("Pessoa Física?");
        chkPES_FISICA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkPES_FISICAActionPerformed(evt);
            }
        });

        lblPES_FONE2.setText("Telefone 2");

        edtPES_FONE1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_FONE1ActionPerformed(evt);
            }
        });

        lblPES_FONE1.setText("Telefone 1");

        lblPES_CEL.setText("Celular ");

        edtPES_FONE2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_FONE2ActionPerformed(evt);
            }
        });

        edtPES_CEL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_CELActionPerformed(evt);
            }
        });

        lblPES_SITE.setText("Site");

        edtPES_SITE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_SITEActionPerformed(evt);
            }
        });

        lblPES_EMAIL.setText("Email");

        edtPES_EMAIL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_EMAILActionPerformed(evt);
            }
        });

        lblCLI_LIMITECRED.setText("Contato");

        edtCLI_LIMITECRED.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtCLI_LIMITECREDActionPerformed(evt);
            }
        });

        chkPES_TIPO.setText("Homem?");
        chkPES_TIPO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkPES_TIPOActionPerformed(evt);
            }
        });

        edtPES_CODIGO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtPES_CODIGOActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout painelDADOSLayout = new javax.swing.GroupLayout(painelDADOS);
        painelDADOS.setLayout(painelDADOSLayout);
        painelDADOSLayout.setHorizontalGroup(
            painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelDADOSLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelDADOSLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(chkUSU_ATIVO)
                        .addGap(35, 35, 35)
                        .addComponent(chkPES_FISICA, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(chkPES_TIPO)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelDADOSLayout.createSequentialGroup()
                        .addComponent(lblPES_SITE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edtPES_SITE, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblPES_EMAIL)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edtPES_EMAIL, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblCLI_LIMITECRED)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(edtCLI_LIMITECRED, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(80, 80, 80))
                    .addGroup(painelDADOSLayout.createSequentialGroup()
                        .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelDADOSLayout.createSequentialGroup()
                                .addComponent(lblPES_COMPLEMENTO)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(edtPES_COMPLEMENTO, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblPES_CODIGO)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_BAIRRO, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(lblPES_CIDADE)
                                .addGap(19, 19, 19)
                                .addComponent(edtPES_CIDADE, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(boxPES_UF, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDADOSLayout.createSequentialGroup()
                                .addComponent(lblUSU_SENHA, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_CPFCNPJ, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPES_RGIE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_RGIE, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPES_ENDERECO)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_ENDERECO, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPES_NUMERO)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_NUMERO, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDADOSLayout.createSequentialGroup()
                                .addComponent(lblPES_CEP)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_CEP, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPES_FONE1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_FONE1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPES_FONE2)
                                .addGap(12, 12, 12)
                                .addComponent(edtPES_FONE2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPES_CEL)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtPES_CEL, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDADOSLayout.createSequentialGroup()
                                .addComponent(lblUSU_CODIGO)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(edtPES_CODIGO, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(painelDADOSLayout.createSequentialGroup()
                                        .addComponent(edtUSU_CODIGO, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblUSU_NOME)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(edtUSU_NOME, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblUSU_LOGIN)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(edtUSU_LOGIN, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap(61, Short.MAX_VALUE))))
        );
        painelDADOSLayout.setVerticalGroup(
            painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelDADOSLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUSU_CODIGO)
                    .addComponent(lblUSU_NOME)
                    .addComponent(edtUSU_NOME, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edtUSU_LOGIN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblUSU_LOGIN)
                    .addComponent(edtUSU_CODIGO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(edtPES_CODIGO, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUSU_SENHA, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edtPES_CPFCNPJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPES_RGIE)
                    .addComponent(lblPES_ENDERECO)
                    .addComponent(edtPES_RGIE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edtPES_ENDERECO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPES_NUMERO)
                    .addComponent(edtPES_NUMERO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPES_CODIGO)
                    .addComponent(lblPES_CIDADE)
                    .addComponent(lblPES_COMPLEMENTO)
                    .addComponent(edtPES_COMPLEMENTO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edtPES_CIDADE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(boxPES_UF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(edtPES_BAIRRO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(edtPES_CEL, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblPES_CEP)
                        .addComponent(edtPES_CEP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblPES_FONE2)
                        .addComponent(lblPES_FONE1)
                        .addComponent(edtPES_FONE1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblPES_CEL)
                        .addComponent(edtPES_FONE2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPES_SITE)
                    .addComponent(edtPES_SITE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPES_EMAIL)
                    .addComponent(edtPES_EMAIL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCLI_LIMITECRED)
                    .addComponent(edtCLI_LIMITECRED, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(painelDADOSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkUSU_ATIVO)
                    .addComponent(chkPES_FISICA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(chkPES_TIPO))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Dados do Fornecedor", painelDADOS);

        getContentPane().add(jTabbedPane1);
        jTabbedPane1.setBounds(10, 90, 720, 300);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lblCONS_ID.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblCONS_ID.setText("ID");

        edtCONS_ID1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        lblCodigo2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblCodigo2.setText("à");

        edtCONS_ID2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        btnConsulta.setText("Consulta");
        btnConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultaActionPerformed(evt);
            }
        });

        btnLimpar.setText("Limpa");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        lblCONS_NOME.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblCONS_NOME.setText("Nome");

        edtCONS_NOME.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        lblCONS_LOGIN.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblCONS_LOGIN.setText("Cpf");

        edtCONS_LOGIN.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(lblCONS_NOME)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edtCONS_NOME))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(lblCONS_ID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edtCONS_ID1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblCodigo2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edtCONS_ID2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblCONS_LOGIN)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(edtCONS_LOGIN, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)))
                .addGap(77, 77, 77)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnConsulta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLimpar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(45, 45, 45))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCONS_ID)
                    .addComponent(edtCONS_ID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCodigo2)
                    .addComponent(edtCONS_ID2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConsulta)
                    .addComponent(edtCONS_LOGIN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCONS_LOGIN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(edtCONS_NOME, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCONS_NOME)
                    .addComponent(btnLimpar))
                .addContainerGap())
        );

        jScrollPane2.setViewportView(tblConsulta);

        javax.swing.GroupLayout painelCONSULTALayout = new javax.swing.GroupLayout(painelCONSULTA);
        painelCONSULTA.setLayout(painelCONSULTALayout);
        painelCONSULTALayout.setHorizontalGroup(
            painelCONSULTALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelCONSULTALayout.createSequentialGroup()
                .addGroup(painelCONSULTALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(painelCONSULTALayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 704, Short.MAX_VALUE)))
                .addContainerGap())
        );
        painelCONSULTALayout.setVerticalGroup(
            painelCONSULTALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelCONSULTALayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("Consulta", painelCONSULTA);

        getContentPane().add(jTabbedPane2);
        jTabbedPane2.setBounds(10, 390, 720, 210);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void limparAgenda() {
        edtUSU_CODIGO.setText("0");
        edtUSU_NOME.setText("");
        edtUSU_LOGIN.setText("");
        edtPES_CPFCNPJ.setText("");
        edtPES_RGIE.setText("");
        edtPES_ENDERECO.setText("");
        edtPES_NUMERO.setText("");
        edtPES_COMPLEMENTO.setText("");
        edtPES_BAIRRO.setText("");
        edtPES_CIDADE.setText("");
        boxPES_UF.setSelectedItem("");
        edtPES_CEP.setText("");
        edtPES_FONE1.setText("");
        edtPES_FONE2.setText("");
        edtPES_CEL.setText("");
        edtPES_SITE.setText("");
        edtPES_EMAIL.setText("");
        edtCLI_LIMITECRED.setText("");
        chkUSU_ATIVO.setSelected(false);
        chkPES_FISICA.setSelected(false);
        chkPES_TIPO.setSelected(false);
    }

    private void mostrar(FornecedorModel cliente) {
        edtUSU_CODIGO.setText(String.valueOf(cliente.getFOR_CODIGO()));
        edtPES_CODIGO.setText(String.valueOf(cliente.getPessoa().getPES_CODIGO()));
        edtUSU_NOME.setText(cliente.getPessoa().getPES_NOME());
        edtUSU_LOGIN.setText(cliente.getPessoa().getPES_FANTASIA());
        edtPES_CPFCNPJ.setText(cliente.getPessoa().getPES_CPFCNPJ());
        edtPES_RGIE.setText(cliente.getPessoa().getPES_RGIE());
        edtPES_ENDERECO.setText(cliente.getPessoa().getPES_ENDERECO());
        edtPES_NUMERO.setText(cliente.getPessoa().getPES_NUMERO());
        edtPES_COMPLEMENTO.setText(cliente.getPessoa().getPES_COMPLEMENTO());
        edtPES_BAIRRO.setText(cliente.getPessoa().getPES_BAIRRO());
        edtPES_CIDADE.setText(cliente.getPessoa().getPES_CIDADE());
        boxPES_UF.setSelectedItem(cliente.getPessoa().getPES_UF());
        edtPES_CEP.setText(cliente.getPessoa().getPES_CEP());
        edtPES_FONE1.setText(cliente.getPessoa().getPES_FONE1());
        edtPES_FONE2.setText(cliente.getPessoa().getPES_FONE2());
        edtPES_CEL.setText(cliente.getPessoa().getPES_CEL());
        edtPES_SITE.setText(cliente.getPessoa().getPES_SITE());
        edtPES_EMAIL.setText(cliente.getPessoa().getPES_EMAIL());
        edtCLI_LIMITECRED.setText(cliente.getFOR_CONTATO());
        chkUSU_ATIVO.setSelected((cliente.getPessoa().getPES_ATIVO() == 1));
        chkPES_TIPO.setSelected((cliente.getPessoa().getPES_TIPO() == 1));
    }

    private String filtroConsulta() {
        String condicao = "";
        if (!edtCONS_ID1.getText().trim().equals("")) {
            condicao += "(FOR_CODIGO >= " + edtCONS_ID1.getText() + ")";
        }
        if (!edtCONS_ID2.getText().trim().equals("")) {
            if (!condicao.isEmpty()) {
                condicao += " AND ";
            }
            condicao += "(FOR_CODIGO <= " + edtCONS_ID2.getText() + ")";
        }
        if (!edtCONS_NOME.getText().trim().equals("")) {
            if (!condicao.isEmpty()) {
                condicao += " AND ";
            }
            condicao += "(PES_NOME LIKE ('%" + edtCONS_NOME.getText() + "%'))";
        }
        if (!edtCONS_LOGIN.getText().trim().equals("")) {
            if (!condicao.isEmpty()) {
                condicao += " AND ";
            }
            condicao += "(PES_CPFCNPJ LIKE ('%" + edtCONS_LOGIN.getText() + "%'))";
        }
        return condicao;
    }

    private void consultar() {
        try {
            String condicao = filtroConsulta();
            FornecedorController fornecedorcontroller = new FornecedorController();
            lista = null;
            lista = fornecedorcontroller.consultar(condicao);
            if (lista.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Não Existem Fornecedores Cadastrados !");
            } else {
                tabela = new FornecedorTableModel(lista, colunas);
                tblConsulta.setModel(tabela);
                tblConsulta.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na Consulta do Fornecedor \n" + ex.getMessage());
        }
    }

    private void btnPRIMEIROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPRIMEIROActionPerformed
        if (lista.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Não Existem Fornecedores Cadastrados !");
        }
        int primeiro = 0;
        mostrarRegistro(primeiro);
    }//GEN-LAST:event_btnPRIMEIROActionPerformed

    private void btnINCLUIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnINCLUIRActionPerformed
        limparAgenda();
        setOperacao("incluir");
        edtUSU_NOME.setFocusable(true);
        chkUSU_ATIVO.setSelected(true);
    }//GEN-LAST:event_btnINCLUIRActionPerformed

    private void btnGRAVARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGRAVARActionPerformed

        if (JOptionPane.showConfirmDialog(this, "Confirma Gravação deste Cliente ?",
                "Confirmação", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                FornecedorModel objusuario = new FornecedorModel();
                objusuario.setFOR_CODIGO(Integer.parseInt(edtUSU_CODIGO.getText()));
                objusuario.setFOR_CONTATO(edtCLI_LIMITECRED.getText());

                PessoaModel pessoa = new PessoaModel();
                pessoa.setPES_CODIGO(Integer.parseInt(edtPES_CODIGO.getText()));
                pessoa.setPES_NOME(edtUSU_NOME.getText());
                pessoa.setPES_FANTASIA(edtUSU_LOGIN.getText());
                pessoa.setPES_FISICA(chkPES_FISICA.isSelected() ? 1 : 0);
                pessoa.setPES_CPFCNPJ(edtPES_CPFCNPJ.getText());
                pessoa.setPES_RGIE(edtPES_RGIE.getText());
                pessoa.setPES_ENDERECO(edtPES_ENDERECO.getText());
                pessoa.setPES_NUMERO(edtPES_NUMERO.getText());
                pessoa.setPES_COMPLEMENTO(edtPES_COMPLEMENTO.getText());
                pessoa.setPES_BAIRRO(edtPES_BAIRRO.getText());
                pessoa.setPES_CIDADE(edtPES_CIDADE.getText());
                pessoa.setPES_UF((String) boxPES_UF.getSelectedItem());
                pessoa.setPES_CEP(edtPES_CEP.getText());
                pessoa.setPES_FONE1(edtPES_FONE1.getText());
                pessoa.setPES_FONE2(edtPES_FONE2.getText());
                pessoa.setPES_CEL(edtPES_CEL.getText());
                pessoa.setPES_SITE(edtPES_SITE.getText());
                pessoa.setPES_EMAIL(edtPES_EMAIL.getText());
                pessoa.setPES_ATIVO((chkUSU_ATIVO.isSelected() ? 1 : 0));
                pessoa.setPES_TIPO((chkPES_TIPO.isSelected() ? 1 : 0));

                objusuario.setPessoa(pessoa);

                FornecedorController fornecedorcontroller = new FornecedorController();
                fornecedorcontroller.gravar(getOperacao(), objusuario);

                JOptionPane.showMessageDialog(null, "Dados Gravados com Sucesso");
                consultar();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erro na Gravação \n" + ex.getMessage());
            }
        }
    }//GEN-LAST:event_btnGRAVARActionPerformed

    private void btnALTERARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnALTERARActionPerformed
        setOperacao("alterar");
    }//GEN-LAST:event_btnALTERARActionPerformed

    private void btnConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultaActionPerformed
        consultar();
    }//GEN-LAST:event_btnConsultaActionPerformed

    private void btnSAIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSAIRActionPerformed
        dispose();
        MenuView menu = new MenuView();
        menu.setVisible(true);
    }//GEN-LAST:event_btnSAIRActionPerformed

    private void btnANTERIORActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnANTERIORActionPerformed
        int selecionado = tblConsulta.getSelectedRow() - 1;
        mostrarRegistro(selecionado);
    }//GEN-LAST:event_btnANTERIORActionPerformed

    private void mostrarRegistro(int registro) {
        if (registro >= 0 && registro < lista.size()) {
            // exibe os dados do registro na aba Dados
            mostrar(lista.get(registro));

            // posicionar o registro selecionado na tabela (JTable)
            tblConsulta.changeSelection(registro, 0, false, false);
        }
    }

    private void btnPROXIMOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPROXIMOActionPerformed
        int selecionado = tblConsulta.getSelectedRow() + 1;
        mostrarRegistro(selecionado);
    }//GEN-LAST:event_btnPROXIMOActionPerformed

    private void btnULTIMOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnULTIMOActionPerformed
        int ultimo = lista.size() - 1;
        mostrarRegistro(ultimo);
    }//GEN-LAST:event_btnULTIMOActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed

    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnEXCLUIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEXCLUIRActionPerformed
        setOperacao("");
        if (JOptionPane.showConfirmDialog(this, "Confirma Exclusão deste Registro ?",
                "Confirmação", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {

                FornecedorModel objusuario = new FornecedorModel();
                objusuario.setFOR_CODIGO(Integer.parseInt(edtUSU_CODIGO.getText()));
                objusuario.setFOR_CONTATO(edtCLI_LIMITECRED.getText());

                PessoaModel pessoa = new PessoaModel();

                pessoa.setPES_CODIGO(Integer.parseInt(edtPES_CODIGO.getText()));
                pessoa.setPES_NOME(edtUSU_NOME.getText());
                pessoa.setPES_FANTASIA(edtUSU_LOGIN.getText());
                pessoa.setPES_FISICA(chkPES_FISICA.isSelected() ? 1 : 0);
                pessoa.setPES_CPFCNPJ(edtPES_CPFCNPJ.getText());
                pessoa.setPES_RGIE(edtPES_RGIE.getText());
                pessoa.setPES_ENDERECO(edtPES_ENDERECO.getText());
                pessoa.setPES_NUMERO(edtPES_NUMERO.getText());
                pessoa.setPES_COMPLEMENTO(edtPES_COMPLEMENTO.getText());
                pessoa.setPES_BAIRRO(edtPES_BAIRRO.getText());
                pessoa.setPES_CIDADE(edtPES_CIDADE.getText());
                pessoa.setPES_UF((String) boxPES_UF.getSelectedItem());
                pessoa.setPES_CEP(edtPES_CEP.getText());
                pessoa.setPES_FONE1(edtPES_FONE1.getText());
                pessoa.setPES_FONE2(edtPES_FONE2.getText());
                pessoa.setPES_CEL(edtPES_CEL.getText());
                pessoa.setPES_SITE(edtPES_SITE.getText());
                pessoa.setPES_EMAIL(edtPES_EMAIL.getText());
                pessoa.setPES_ATIVO((chkUSU_ATIVO.isSelected() ? 1 : 0));
                pessoa.setPES_TIPO((chkPES_TIPO.isSelected() ? 1 : 0));

                objusuario.setPessoa(pessoa);

                FornecedorController fornecedorcontroller = new FornecedorController();
                fornecedorcontroller.excluir(objusuario);

                JOptionPane.showMessageDialog(null, "Registro Excluído com Sucesso");
                consultar();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erro na Exclusão de Registro \n" + ex.getMessage());
            }
        }
    }//GEN-LAST:event_btnEXCLUIRActionPerformed

    private void edtUSU_NOMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtUSU_NOMEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtUSU_NOMEActionPerformed

    private void edtUSU_CODIGOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtUSU_CODIGOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtUSU_CODIGOActionPerformed

    private void chkPES_FISICAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkPES_FISICAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkPES_FISICAActionPerformed

    private void chkUSU_ATIVOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkUSU_ATIVOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkUSU_ATIVOActionPerformed

    private void edtPES_RGIEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_RGIEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_RGIEActionPerformed

    private void edtPES_ENDERECOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_ENDERECOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_ENDERECOActionPerformed

    private void edtPES_CPFCNPJActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_CPFCNPJActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_CPFCNPJActionPerformed

    private void edtPES_NUMEROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_NUMEROActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_NUMEROActionPerformed

    private void edtPES_BAIRROActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_BAIRROActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_BAIRROActionPerformed

    private void boxPES_UFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxPES_UFActionPerformed


    }//GEN-LAST:event_boxPES_UFActionPerformed

    private void edtPES_CIDADEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_CIDADEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_CIDADEActionPerformed

    private void edtPES_CEPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_CEPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_CEPActionPerformed

    private void edtPES_FONE1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_FONE1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_FONE1ActionPerformed

    private void edtPES_FONE2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_FONE2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_FONE2ActionPerformed

    private void edtPES_CELActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_CELActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_CELActionPerformed

    private void edtPES_SITEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_SITEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_SITEActionPerformed

    private void edtPES_EMAILActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_EMAILActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_EMAILActionPerformed

    private void edtCLI_LIMITECREDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtCLI_LIMITECREDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtCLI_LIMITECREDActionPerformed

    private void chkPES_TIPOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkPES_TIPOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkPES_TIPOActionPerformed

    private void edtPES_CODIGOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtPES_CODIGOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtPES_CODIGOActionPerformed
    /**
     * @param args the command line arguments
     */
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> boxPES_UF;
    private javax.swing.JButton btnALTERAR;
    private javax.swing.JButton btnANTERIOR;
    private javax.swing.JButton btnConsulta;
    private javax.swing.JButton btnEXCLUIR;
    private javax.swing.JButton btnGRAVAR;
    private javax.swing.JButton btnINCLUIR;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnPRIMEIRO;
    private javax.swing.JButton btnPROXIMO;
    private javax.swing.JButton btnSAIR;
    private javax.swing.JButton btnULTIMO;
    private javax.swing.JCheckBox chkPES_FISICA;
    private javax.swing.JCheckBox chkPES_TIPO;
    private javax.swing.JCheckBox chkUSU_ATIVO;
    private javax.swing.JTextField edtCLI_LIMITECRED;
    private javax.swing.JTextField edtCONS_ID1;
    private javax.swing.JTextField edtCONS_ID2;
    private javax.swing.JTextField edtCONS_LOGIN;
    private javax.swing.JTextField edtCONS_NOME;
    private javax.swing.JTextField edtPES_BAIRRO;
    private javax.swing.JTextField edtPES_CEL;
    private javax.swing.JTextField edtPES_CEP;
    private javax.swing.JTextField edtPES_CIDADE;
    private javax.swing.JTextField edtPES_CODIGO;
    private javax.swing.JTextField edtPES_COMPLEMENTO;
    private javax.swing.JTextField edtPES_CPFCNPJ;
    private javax.swing.JTextField edtPES_EMAIL;
    private javax.swing.JTextField edtPES_ENDERECO;
    private javax.swing.JTextField edtPES_FONE1;
    private javax.swing.JTextField edtPES_FONE2;
    private javax.swing.JTextField edtPES_NUMERO;
    private javax.swing.JTextField edtPES_RGIE;
    private javax.swing.JTextField edtPES_SITE;
    private javax.swing.JTextField edtUSU_CODIGO;
    private javax.swing.JTextField edtUSU_LOGIN;
    private javax.swing.JTextField edtUSU_NOME;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JLabel lblCLI_LIMITECRED;
    private javax.swing.JLabel lblCONS_ID;
    private javax.swing.JLabel lblCONS_LOGIN;
    private javax.swing.JLabel lblCONS_NOME;
    private javax.swing.JLabel lblCodigo2;
    private javax.swing.JLabel lblPES_CEL;
    private javax.swing.JLabel lblPES_CEP;
    private javax.swing.JLabel lblPES_CIDADE;
    private javax.swing.JLabel lblPES_CODIGO;
    private javax.swing.JLabel lblPES_COMPLEMENTO;
    private javax.swing.JLabel lblPES_EMAIL;
    private javax.swing.JLabel lblPES_ENDERECO;
    private javax.swing.JLabel lblPES_FONE1;
    private javax.swing.JLabel lblPES_FONE2;
    private javax.swing.JLabel lblPES_NUMERO;
    private javax.swing.JLabel lblPES_RGIE;
    private javax.swing.JLabel lblPES_SITE;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblUSU_CODIGO;
    private javax.swing.JLabel lblUSU_LOGIN;
    private javax.swing.JLabel lblUSU_NOME;
    private javax.swing.JLabel lblUSU_SENHA;
    private javax.swing.JPanel painelCONSULTA;
    private javax.swing.JPanel painelDADOS;
    private javax.swing.JTable tblConsulta;
    // End of variables declaration//GEN-END:variables
}
