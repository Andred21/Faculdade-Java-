package view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;

public class MenuView extends JFrame {

    private JMenuBar menuBar;
    private JMenu cadastro, movimentos, sair;
    private JMenuItem cliente, fornecedor, formaPagamento, usuario, produto, venda, compra, sair2;
    private JPanel panelCorrente;

    public MenuView() {
        setTitle("Gerenciamento de Compras e Vendas"); // título do frame
        setPreferredSize(new Dimension(750, 650)); // ajuste do tamanho e layout
        setLayout(null); // aqui a definicao para utilizacao de layout absoluto

        instanciarMenu();
        adicionarMenu();
        posicionarMenu();
        Eventos();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true); // deixa o frame visível
        pack(); // reorganiza os componentes (objetos) no frame
    }

    public void instanciarMenu() {
        menuBar = new JMenuBar();
        Border border = BorderFactory.createEtchedBorder();
        menuBar.setBorder(border);

        cadastro = new JMenu("Cadastros");
        movimentos = new JMenu("Movimentos");
        sair = new JMenu("Sair");

        cliente = new JMenuItem("Cliente");
        fornecedor = new JMenuItem("Fornecedor");
        formaPagamento = new JMenuItem("Forma de Pagamento");
        usuario = new JMenuItem("Usuário");
        produto = new JMenuItem("Produto");

        venda = new JMenuItem("Venda");
        compra = new JMenuItem("Compra");

        sair2 = new JMenuItem("sair");

    }

    public void Eventos() {
        cliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                ClienteView view = new ClienteView();
                view.setVisible(true);
                dispose();

            }
        });

        fornecedor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                FornecedorView view = new FornecedorView();
                view.setVisible(true);
                dispose();

            }
        });
        formaPagamento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                FormaPagtoView view = new FormaPagtoView();
                view.setVisible(true);
                dispose();
            }
        });
        usuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                UsuarioView view = new UsuarioView();
                view.setVisible(true);
                dispose();
            }
        });

        produto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProdutoView view = new ProdutoView();
                view.setVisible(true);
                dispose();
            }
        });

        venda.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

               VendaView view = new VendaView();
                view.setVisible(true);
                dispose();

            }
        });

        compra.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                CompraView view = new CompraView();
                view.setVisible(true);
                dispose();

            }
        });
        sair2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TelaLoginView s = new TelaLoginView();
                s.setVisible(true);
                dispose();
            }
        });

    }

    public void adicionarMenu() {
        cadastro.add(cliente);
        cadastro.add(fornecedor);
        cadastro.add(formaPagamento);
        cadastro.add(usuario);
        cadastro.add(produto);

        movimentos.add(venda);
        movimentos.add(compra);
        sair.add(sair2);
        menuBar.add(cadastro);
        menuBar.add(movimentos);
        menuBar.add(sair);

        add(menuBar);

    }

    public void posicionarMenu() {
        menuBar.setBounds(0, 0, 800, 24);
    }

}
