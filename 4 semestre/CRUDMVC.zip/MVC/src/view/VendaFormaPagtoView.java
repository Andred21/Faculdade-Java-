/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import controller.ClienteController;
import controller.CompraController;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import controller.CompraProdutoController;
import controller.FormaPagtoController;
import controller.ProdutoController;
import controller.VendaController;
import controller.VendaPagtoController;
import controller.VendaProdutoController;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import model.CompraModel;
import model.CompraProdutoModel;
import model.FormaPagtoModel;
import model.ProdutoModel;
import model.VendaPagtoModel;
import model.VendaProdutoModel;

/**
 *
 * @author GC Info Gamer
 */
public class VendaFormaPagtoView extends javax.swing.JFrame {

    private ArrayList<VendaProdutoModel> cplist;

    public VendaFormaPagtoView() {
        this.setPreferredSize(new Dimension(600, 400));
        initComponents();

    }

    public void mostrar2(VendaPagtoModel venda) {

        int formaID = venda.getFormaPagto().getFPG_CODIGO();
        for (int i = 0; i < jComboBox1.getItemCount(); i++) {
            FormaPagtoModel forma = (FormaPagtoModel) jComboBox1.getItemAt(i);
            if (forma.getFPG_CODIGO() == formaID) {
                jComboBox1.setSelectedItem(forma);
                break;
            }
        }
        edtCPP_QTDE.setText(String.valueOf(venda.getVDP_VALOR()));
      
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblPRO_CODIGO = new javax.swing.JLabel();
        llbCPP_QTDE = new javax.swing.JLabel();
        edtCPP_QTDE = new javax.swing.JTextField();
        btnGRAVAR = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblTitulo.setText("Forma de Pagamento");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cashless-payment.png"))); // NOI18N

        lblPRO_CODIGO.setText("Código Forma de Pagamento");

        llbCPP_QTDE.setText("Valor");

        btnGRAVAR.setText("Adicionar à Venda");
        btnGRAVAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGRAVARActionPerformed(evt);
            }
        });

        VendaController venda = new VendaController();
        try{
            List<FormaPagtoModel> formas = venda.getAllFormaPagto();
            for (FormaPagtoModel forma : formas) {

                jComboBox1.addItem(forma);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        /*
        jComboBox1.setModel(null);
        */

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPRO_CODIGO)
                            .addComponent(llbCPP_QTDE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(edtCPP_QTDE, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnGRAVAR, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(117, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(lblTitulo)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPRO_CODIGO)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(llbCPP_QTDE)
                    .addComponent(edtCPP_QTDE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addComponent(btnGRAVAR)
                .addContainerGap(79, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnGRAVARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGRAVARActionPerformed

        if (JOptionPane.showConfirmDialog(this, "Confirma Gravação desta Compra ?",
                "Confirmação", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                cplist = new ArrayList<>();
                VendaPagtoModel prop = new VendaPagtoModel();
                prop.setVDP_VALOR(Float.parseFloat(edtCPP_QTDE.getText()));
               
                
                FormaPagtoModel selectedForma = (FormaPagtoModel) jComboBox1.getSelectedItem();
                int formaID = selectedForma.getFPG_CODIGO();
                selectedForma.setFPG_CODIGO(formaID);

                prop.setFormaPagto(selectedForma);
                VendaPagtoController.getVendaFormaPagtoList().add(prop);

                JOptionPane.showMessageDialog(null, "Dados Gravados com Sucesso");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erro na Gravação \n" + ex.getMessage());
            }
        }


    }//GEN-LAST:event_btnGRAVARActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGRAVAR;
    private javax.swing.JTextField edtCPP_QTDE;
    private javax.swing.JComboBox<FormaPagtoModel> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblPRO_CODIGO;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel llbCPP_QTDE;
    // End of variables declaration//GEN-END:variables

}
