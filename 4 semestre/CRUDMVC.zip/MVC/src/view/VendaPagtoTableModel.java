package view;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import model.VendaPagtoModel;

public class VendaPagtoTableModel extends AbstractTableModel{
        private ArrayList<VendaPagtoModel> linhas;
    String[] colunas;

    public VendaPagtoTableModel(ArrayList<VendaPagtoModel> arrayvendapagto, String[] colunas) {
        this.colunas = colunas;
        linhas = arrayvendapagto;
    }

    //Retorna a quantidade de colunas do modelo, que no caso será fixa
    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    //Retorna a quantidade de linhas atual do objeto, que no caso é o tamnho da lista
    @Override
    public int getRowCount() {
        return linhas.size();
    }

    //Retorna o nome da coluna, recebendo seu índice
    @Override
    public String getColumnName(int indiceColuna) {
        return colunas[indiceColuna];
    }

    @Override
    public Object getValueAt(int row, int col) {
        VendaPagtoModel vendapagtomodel = (VendaPagtoModel) linhas.get(row);
        switch (col) {
            case 0:
                return vendapagtomodel.getVDP_CODIGO();
            case 1:
                return vendapagtomodel.getVenda().getVDA_CODIGO();
            case 2:
                return vendapagtomodel.getFormaPagto().getFPG_CODIGO();
            case 3:
                return vendapagtomodel.getFormaPagto().getFPG_NOME();
            case 4: 
                return vendapagtomodel.getVDP_VALOR();
            default:
                return null;
        }
    }

    //Adicionamos várias linhas na tabela de uma vez, recebendo um List de UsuarioModel
    public void addLista(ArrayList<VendaPagtoModel> vendapagto) {
        int tamanhoAntigo = getRowCount();

        //Adiciona os usuários
        linhas.addAll(vendapagto);

        //Aqui reportamos a mudança para o JTable, assim ele pode se redesenhar, para visualizarmos a alteração
        fireTableRowsInserted(tamanhoAntigo, getRowCount() - 1);
    }
}
    


