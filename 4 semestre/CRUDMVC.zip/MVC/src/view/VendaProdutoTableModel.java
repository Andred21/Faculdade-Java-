
package view;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import model.VendaProdutoModel;

public class VendaProdutoTableModel extends AbstractTableModel{
        private ArrayList<VendaProdutoModel> linhas;
    String[] colunas;

    public VendaProdutoTableModel(ArrayList<VendaProdutoModel> arrayvendaproduto, String[] colunas) {
        this.colunas = colunas;
        linhas = arrayvendaproduto;
    }

    //Retorna a quantidade de colunas do modelo, que no caso será fixa
    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    //Retorna a quantidade de linhas atual do objeto, que no caso é o tamnho da lista
    @Override
    public int getRowCount() {
        return linhas.size();
    }

    //Retorna o nome da coluna, recebendo seu índice
    @Override
    public String getColumnName(int indiceColuna) {
        return colunas[indiceColuna];
    }

    @Override
    public Object getValueAt(int row, int col) {
        VendaProdutoModel vendaprodutomodel = (VendaProdutoModel) linhas.get(row);
        switch (col) {
            case 0:
                return vendaprodutomodel.getVEP_CODIGO();
            case 1:
                return vendaprodutomodel.getVenda().getVDA_CODIGO();
            case 2:
                return vendaprodutomodel.getProduto().getPRO_CODIGO();
            case 3:
                return vendaprodutomodel.getProduto().getPRO_NOME();
            case 4:
                return vendaprodutomodel.getVEP_QTDE();
            case 5:
                return vendaprodutomodel.getVEP_PRECO();   
            case 6:
                return vendaprodutomodel.getVEP_DESCONTO();
            case 7: 
                return vendaprodutomodel.getVEP_TOTAL();
            default:
                return null;
        }
    }

    //Adicionamos várias linhas na tabela de uma vez, recebendo um List de UsuarioModel
    public void addLista(ArrayList<VendaProdutoModel> vendaproduto) {
        int tamanhoAntigo = getRowCount();

        //Adiciona os usuários
        linhas.addAll(vendaproduto);

        //Aqui reportamos a mudança para o JTable, assim ele pode se redesenhar, para visualizarmos a alteração
        fireTableRowsInserted(tamanhoAntigo, getRowCount() - 1);
    }
}
    

