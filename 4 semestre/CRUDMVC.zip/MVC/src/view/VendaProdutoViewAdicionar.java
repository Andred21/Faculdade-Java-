/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import controller.ClienteController;
import controller.CompraController;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import controller.CompraProdutoController;
import controller.ProdutoController;
import controller.VendaProdutoController;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import model.CompraModel;
import model.CompraProdutoModel;
import model.ProdutoModel;
import model.VendaModel;
import model.VendaProdutoModel;

/**
 *
 * @author GC Info Gamer
 */
public class VendaProdutoViewAdicionar extends javax.swing.JFrame {

    private ArrayList<VendaProdutoModel> cplist;

    public VendaProdutoViewAdicionar() {
        this.setPreferredSize(new Dimension(600, 400));
        initComponents();

    }

      public void definirValorSegunda(String valor) {
        edtVDA_CODIGO.setText(valor);
    }

    public void mostrar2(VendaProdutoModel venda) {

        int proID = venda.getProduto().getPRO_CODIGO();
        for (int i = 0; i < jComboBox1.getItemCount(); i++) {
            ProdutoModel pro = (ProdutoModel) jComboBox1.getItemAt(i);
            if (pro.getPRO_CODIGO() == proID) {
                jComboBox1.setSelectedItem(pro);
                break;
            }
        }
        edtVDA_CODIGO.setText(String.valueOf(venda.getVenda().getVDA_CODIGO()));
        edtCPP_QTDE.setText(String.valueOf(venda.getVEP_QTDE()));
        edtCPP_PRECO.setText(String.valueOf(venda.getVEP_PRECO()));
        edtCPP_DESCONTO.setText(String.valueOf(venda.getVEP_DESCONTO()));
        edtCPP_TOTAL.setText(String.valueOf(venda.getVEP_TOTAL()));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblPRO_CODIGO = new javax.swing.JLabel();
        llbCPP_QTDE = new javax.swing.JLabel();
        edtCPP_QTDE = new javax.swing.JTextField();
        lblCPP_PRECO = new javax.swing.JLabel();
        edtCPP_PRECO = new javax.swing.JTextField();
        lblCPP_DESCONTO = new javax.swing.JLabel();
        edtCPP_DESCONTO = new javax.swing.JTextField();
        lblCPP_TOTAL = new javax.swing.JLabel();
        edtCPP_TOTAL = new javax.swing.JTextField();
        btnGRAVAR = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        edtVDA_CODIGO = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblTitulo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblTitulo.setText("Carrinho de Compras");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/shopping-cart_resized (1).png"))); // NOI18N

        lblPRO_CODIGO.setText("Código Produto");

        llbCPP_QTDE.setText("Quantidade");

        lblCPP_PRECO.setText("Preço");

        edtCPP_PRECO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtCPP_PRECOActionPerformed(evt);
            }
        });

        lblCPP_DESCONTO.setText("Desconto");

        lblCPP_TOTAL.setText("Total");

        edtCPP_TOTAL.setEditable(false);
        edtCPP_TOTAL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtCPP_TOTALActionPerformed(evt);
            }
        });

        btnGRAVAR.setText("Adicionar à Venda");
        btnGRAVAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGRAVARActionPerformed(evt);
            }
        });

        jButton1.setText("calcular");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        CompraController compra = new CompraController();
        try{
            List<ProdutoModel> produtos = compra.getAllProdutos();
            for (ProdutoModel produto : produtos) {

                jComboBox1.addItem(produto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        /*
        */

        edtVDA_CODIGO.setEditable(false);

        jLabel2.setText("ID Venda");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(llbCPP_QTDE)
                                    .addComponent(lblPRO_CODIGO))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(edtCPP_QTDE, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblCPP_PRECO))
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblCPP_TOTAL)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(edtCPP_TOTAL, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(64, 64, 64))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtCPP_PRECO, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblCPP_DESCONTO)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edtCPP_DESCONTO, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(85, 85, 85)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(edtVDA_CODIGO, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addComponent(btnGRAVAR, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(lblTitulo)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblPRO_CODIGO)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(edtVDA_CODIGO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(llbCPP_QTDE)
                    .addComponent(edtCPP_QTDE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCPP_PRECO)
                    .addComponent(edtCPP_PRECO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCPP_DESCONTO)
                    .addComponent(edtCPP_DESCONTO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCPP_TOTAL)
                    .addComponent(edtCPP_TOTAL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(30, 30, 30)
                .addComponent(btnGRAVAR)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
     

    private void edtCPP_PRECOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtCPP_PRECOActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtCPP_PRECOActionPerformed

    private void btnGRAVARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGRAVARActionPerformed
        if (JOptionPane.showConfirmDialog(this, "Confirma Gravação desta Venda ?",
                "Confirmação", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try {
                cplist = new ArrayList<>();
                VendaProdutoModel prop = new VendaProdutoModel();
                prop.setVEP_QTDE(Float.parseFloat(edtCPP_QTDE.getText()));
                prop.setVEP_PRECO(Float.parseFloat(edtCPP_PRECO.getText()));
                prop.setVEP_DESCONTO(Float.parseFloat(edtCPP_DESCONTO.getText()));
                prop.setVEP_TOTAL(Float.parseFloat(edtCPP_TOTAL.getText()));
               
                VendaModel venda = new VendaModel();
                venda.setVDA_CODIGO(Integer.parseInt(edtVDA_CODIGO.getText()));

                ProdutoModel selectedProduto = (ProdutoModel) jComboBox1.getSelectedItem();
                int produtoID = selectedProduto.getPRO_CODIGO();
                selectedProduto.setPRO_CODIGO(produtoID);

                prop.setVenda(venda);
                prop.setProduto(selectedProduto);
                VendaProdutoController vp = new VendaProdutoController();
                vp.adicionar(prop);

                JOptionPane.showMessageDialog(null, "Dados Gravados com Sucesso");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erro na Gravação \n" + ex.getMessage());
            }
        }


    }//GEN-LAST:event_btnGRAVARActionPerformed

    private void edtCPP_TOTALActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtCPP_TOTALActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edtCPP_TOTALActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            Float quantidade = Float.parseFloat(edtCPP_QTDE.getText());
            Float preco = Float.parseFloat(edtCPP_PRECO.getText());
            Float desconto = Float.parseFloat(edtCPP_DESCONTO.getText());
            Float resultado = quantidade * preco - desconto;
            edtCPP_TOTAL.setText(String.valueOf(resultado));
        } catch (NumberFormatException ex) {
            edtCPP_TOTAL.setText("Valores inválidos");
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGRAVAR;
    private javax.swing.JTextField edtCPP_DESCONTO;
    private javax.swing.JTextField edtCPP_PRECO;
    private javax.swing.JTextField edtCPP_QTDE;
    private javax.swing.JTextField edtCPP_TOTAL;
    private javax.swing.JTextField edtVDA_CODIGO;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<ProdutoModel> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel lblCPP_DESCONTO;
    private javax.swing.JLabel lblCPP_PRECO;
    private javax.swing.JLabel lblCPP_TOTAL;
    private javax.swing.JLabel lblPRO_CODIGO;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel llbCPP_QTDE;
    // End of variables declaration//GEN-END:variables

}
