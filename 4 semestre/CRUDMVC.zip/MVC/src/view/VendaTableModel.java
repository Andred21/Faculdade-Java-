package view;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import model.VendaModel;

public class VendaTableModel extends AbstractTableModel{
        private ArrayList<VendaModel> linhas;
    String[] colunas;

    public VendaTableModel(ArrayList<VendaModel> arrayvendaproduto, String[] colunas) {
        this.colunas = colunas;
        linhas = arrayvendaproduto;
    }

    //Retorna a quantidade de colunas do modelo, que no caso será fixa
    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    //Retorna a quantidade de linhas atual do objeto, que no caso é o tamnho da lista
    @Override
    public int getRowCount() {
        return linhas.size();
    }

    //Retorna o nome da coluna, recebendo seu índice
    @Override
    public String getColumnName(int indiceColuna) {
        return colunas[indiceColuna];
    }

    @Override
    public Object getValueAt(int row, int col) {
        VendaModel vendamodel = (VendaModel) linhas.get(row);
        switch (col) {
            case 0:
                return vendamodel.getVDA_CODIGO();
            case 1:
                return vendamodel.getUsuario().getUSU_CODIGO();
            case 2:
                return vendamodel.getCliente().getCLI_CODIGO();
            case 3:
                return vendamodel.getVDA_VALOR();
            case 4:
                return vendamodel.getVDA_DESCONTO();   
            case 5:
                return vendamodel.getVDA_TOTAL();
            default:
                return null;
        }
    }

    //Adicionamos várias linhas na tabela de uma vez, recebendo um List de UsuarioModel
    public void addLista(ArrayList<VendaModel> vendaproduto) {
        int tamanhoAntigo = getRowCount();

        //Adiciona os usuários
        linhas.addAll(vendaproduto);

        //Aqui reportamos a mudança para o JTable, assim ele pode se redesenhar, para visualizarmos a alteração
        fireTableRowsInserted(tamanhoAntigo, getRowCount() - 1);
    }
}
    


