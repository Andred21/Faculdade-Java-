package formfuncionario;

import java.awt.*;
//import java.net.URL;
import javax.swing.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

public class FormFuncionario extends JFrame {

    private JToolBar tbBarra1, tbBarra2;
    private JLabel lblCpf, lblNome, lblStt1, lblSituacao1, lblAberta, lblAtivo;
    private JLabel lblDadosGerais, lblEmpresa, lblDivicaoRh, lblMatricula, lblFuncinario;
    private JLabel lblEndereco, lblCep, lblEndereco1, lblNumero, lblBairro, lblMunicipio, lblTelefone, lblTelefoneCel, lblEmail;
    private JLabel lblDadosPessoais, lblSexo, lblDataNasc, lblEstadoCivil, lblNaturalidade, lblGrauDeInstrucao, lblNacionalidade, lblFormacao;
    private JLabel lblFiliacao, lblPai, lblMae;
    private JLabel lblRg, lblNumeroRg, lblOrgaoExpeditor, lblUf, lblDataExpedicaoRg;
    private JLabel lblInformacaoMilitar, lblSituacao, lblDataBaixa, lblNumeroMilitar, lblCategoria;
    private JLabel lblCnh, lblNumeroCnh, lblCategoriaCnh, lblDataCadastro, lblDataVencimentos;
    private JLabel lblConselhoRegional, lblNomeConselho, lblSigla, lblRegRegiao, lblNumeroConselho, lblDataExpedicao, lblOrgaoEmissorConselho, lblDataValidadeConselho;
    private JLabel lblCtps, lblNumeroCtps, lblSerie, lblOrgao, lblUfCtps;
    private JLabel lblCpfDocumentacao, lblNumeroCpf;
    private JLabel lblPis, lblNumeroPis, lblDataCadastroPis;
    private JLabel lblTituloDeEleitor, lblNumTituloEleitor, lblZona, lblSecao;
    private JLabel lblRic, lblNumRic, lblOrgaoExpedidorRic, lblDataexpedicaoRic;
    private JComboBox boxUf, boxDataExpedicao, boxDataBaixa, boxCategoria, boxDataCadastroCnh, boxDataVencimentoCnh, boxDataExpedicaoRg,
            boxDataValidadeConselho, boxUfCtps, boxDataCadastroPis, boxDataExpedicaoRic;
    private JComboBox boxEmpresa, boxDivicaoRh, boxMuncipio, boxSexo, boxDatanasc, boxEstadoCivil, boxGrauDeInstrucao;
    private JSpinner spinDataNasc, spinDataExame;
    private JTextField txtCpf, txtNome;
    private JTextField txtMatricula, txtFuncionario;
    private JTextField txtCep, txtEndereco, txtNumero, txtBairro, txtTelefone, txtTelefoneCel, txtEmail;
    private JTextField txtNaturalidade, txtNacionalidade, txtFormacao;
    private JTextField txtPai, txtMae;
    private JTextField txtNumeroRg, txtOrgaoExpeditorRg, txtSituacao, txtNumeroMilitar, txtNumeroCnh, txtCategoriaCnh,
            txtNomeConselho, txtSigla, txtRegRegiao, txtNumeroConselho, txtOrgaoEmissorConselho, txtNumeroCtps, txtSerie, txtOrgao,
            txtNumeroCpf, txtNumeroPis, txtNumeroEleitor, txtZona, txtSecao, txtNumeroRic, txtOrgaoExpedidorRic;
    private JButton btSalvar, btConcluir, btExcluir, btOcorrencia, btFechar;

//Variaveis Painel Contrato    
    private JLabel lblVinculo, lblTipoAdmissao, lblDataAdmissao, lblTipoSalario, lblHorario, lblHrsSem;
    private JSpinner spinDataAdmissao;
    private JComboBox boxVinculo, boxTipoAdmissao, boxTipoSalario, boxHorario;
    private JTextField txtHrsSem;

    private JLabel lblFgts, lblOpcao, lblDataOpcao;
    private JComboBox boxOpcao;
    private JSpinner spinDataOpcao;

    private JLabel lblAtividadeDesenvolvida;
    private JRadioButton rbUrbana, rbRural;

    private JLabel lblAdiantamentoQuinzenal, lblAdiantamento, lblPercentual, lblValorFixo;
    private JComboBox boxAdiantamento;
    private JTextField txtPercentual, txtValorFixo;

    private JLabel lblExperiencia, lblVencimento, lblProrrogacao;
    private JSpinner spinVencimento, spinProrrogacao;

    private JLabel lblValorSalario, lblTipoReajuste;
    private JTextField txtValorSalario;
    private JComboBox boxTipoReajuste;

    private JLabel lblCargo, lblDepartamento;
    private JComboBox boxCargo, boxDepartamento;

    private JLabel lblCategoriaGfip, lblTipoContrato;
    private JComboBox boxCategoriaGfip, boxTipoContrato;

    private JLabel lblRecisao, lblDataDemissao, lblMotivoDemissao, lblDataAvisoInicio, lblDataAvisoFim, lblMotivoRais;
    private JComboBox boxMotivoDemissao, boxMotivoRais;
    private JSpinner spinDataDemissao, spinDataAvisoInicio, spinDataAvisoFim;
    private JCheckBox cbAvisoPrevio;

//Variaveis Painel Operacional
    private JCheckBox cbInss, cbFgts, cbIrrf, cbReembolsoInss, cbEmpregadoDomestico, cbBeneficioPrevidencia, cbValeTransporte, cbValeRefeicao, cbPlanoSaude;

    private JLabel lblRacaCor, lblTipoDeficiencia;
    private JComboBox boxRacaCor, boxTipoDeficiencia;

    private JLabel lblSindicato, lblMesDissidio;
    private JComboBox boxSindicato, boxMesDissidio;

    private JLabel lblDadosFuncionario, lblFormaPagamento, lblBanco, lblAgencia, lblNumeroConta;
    private JComboBox boxFormaPagamento, boxBanco;
    private JTextField txtAgencia, txtNumeroConta;

    private JLabel lblExamesAdicionais, lblNomeMedico, lblCrm, lblDataExame, lblFoto;
    private JTextField txtNomeMedico, txtCrm;
    private JSpinner spinDataExpedicaoRg, spinDataBaixa, spinDataCadastroCnh,
            spinDataVencimentoCnh, spinDataExpedicaoConselho, spinDataValidadeConselho, spinDataCadastroPis, spinDataExpedicaoRic;
    private JButton btSelecionar, btLimpar;
    private FileInputStream fis;
    private int tamanho;

    private JTabbedPane tpPainel;

    private JPanel panelPrincipal, panelDocumetacao, panelContrato, panelOperacional;

    private JPanel panelOpChecks, panelOpRaca, panelOpSindicato, panelOpDados, panelOpExames, panelOpFoto;
    private JPanel panelDadosGerais, panelEndereco, panelDadosPessoais, panelFiliacao;
    private JPanel panelRg, panelMilitar, panelCnh, panelConselho, panelCtps, panelCpf, panelPis, panelTitulo, panelRic;
    private JPanel panelConVinculo, panelConFgts, panelConAtividade, panelConAdiantamento, panelConExperiencia, panelConSalario, panelConCargo, panelConCategoria, panelConRecisao;

    public FormFuncionario() {

        setTitle("Cadastro de Funcionários"); // título do frame
        setPreferredSize(new Dimension(800, 600)); // ajuste do tamanho e layout
        setLayout(null); // aqui a definicao para utilizacao de layout absoluto

        instanciarGeral(); // instancia componentes (objetos Swing);
        adicionarGeral();
        posicionarGeral();// configura as posices dos componentes;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true); // deixa o frame visível
        pack(); // reorganiza os componentes (objetos) no frame
    }

    public void instanciarGeral() {
        instanciarPrincipal();
        instanciarDocumentacao();
        instanciarContrato();
        instanciarOperacional();
        Border emptyBorder = BorderFactory.createEmptyBorder();
        //Primeira barra
        tbBarra1 = new JToolBar();
        tbBarra1.setBackground(new Color(240, 240, 240));

        lblStt1 = new JLabel("Status:");
        lblAberta = new JLabel("Aberta    ");
        lblAberta.setFont(new Font("Arial", Font.BOLD, 15));
        lblAberta.setForeground(Color.blue);

        btSalvar = new JButton("Salvar");
        btSalvar.setIcon(new ImageIcon(getClass().getResource("/images/floppy-disk_resized.png")));
        btSalvar.setBorder(emptyBorder);
        
       

        btConcluir = new JButton("Concluir");
        btConcluir.setIcon(new ImageIcon(getClass().getResource("/images/check-mark_resized.png")));
        btConcluir.setBorder(emptyBorder);

        btExcluir = new JButton("Excluir");
        btExcluir.setIcon(new ImageIcon(getClass().getResource("/images/close_resized.png")));
        btExcluir.setBorder(emptyBorder);

        btOcorrencia = new JButton("Ocorrencia");
        btOcorrencia.setIcon(new ImageIcon(getClass().getResource("/images/trade_resized.png")));
        btOcorrencia.setBorder(emptyBorder);

        lblSituacao1 = new JLabel("Situação:");
        lblAtivo = new JLabel("Ativo                              ");
        lblAtivo.setFont(new Font("Arial", Font.BOLD, 15));
        lblAtivo.setForeground(new Color(0, 128, 0));
        
        btFechar = new JButton("Fechar");
        btFechar.setIcon(new ImageIcon(getClass().getResource("/images/exit_resized.png")));
        btFechar.setBorder(emptyBorder);

        //Segunda barra 
        tbBarra2 = new JToolBar();
        tbBarra2.setBackground(new Color(240,240,240));
        lblCpf = new JLabel(("CPF "));
        txtCpf = new JTextField("");
        lblNome = new JLabel("Nome ");
        txtNome = new JTextField("");

        tpPainel = new JTabbedPane(); //Aba de painéis 
    }

    public void adicionarGeral() {
        adicionarPrincipal();
        adicionarDocumentacao();
        adicionarContrato();
        adicionarOperacional();

        tbBarra1.add(lblStt1);
        tbBarra1.addSeparator();
        tbBarra1.add(lblAberta);
        tbBarra1.addSeparator();
        tbBarra1.add(btSalvar);
        tbBarra1.addSeparator();
        tbBarra1.add(btConcluir);
        tbBarra1.addSeparator();
        tbBarra1.add(btExcluir);
        tbBarra1.addSeparator();
        tbBarra1.add(btOcorrencia);
        tbBarra1.addSeparator();
        tbBarra1.add(lblSituacao1);
        tbBarra1.addSeparator();
        tbBarra1.add(lblAtivo);
        tbBarra1.addSeparator();
        tbBarra1.add(btFechar);

        add(tbBarra1, BorderLayout.PAGE_START);

        tbBarra2.add(lblCpf);
        tbBarra2.add(txtCpf);
        tbBarra2.addSeparator();
        tbBarra2.add(lblNome);
        tbBarra2.add(txtNome);
        tbBarra2.addSeparator();
        add(tbBarra2, BorderLayout.PAGE_START);
        //Adicionando o Tabbedpanel e as panels na abas 
        add(tpPainel);
        tpPainel.addTab("principal", panelPrincipal);
        tpPainel.addTab("Documentação", panelDocumetacao);
        tpPainel.addTab("Contrato", panelContrato);
        tpPainel.addTab("Operacional", panelOperacional);
    }

    public void posicionarGeral() {
        posicionarPrincipal();
        posicionarDocumentacao();
        posicionarContrato();
        posicionarOperacional();

        // Setbounds( posicao x, posicao y, largura, algura )]
        //Posicionamento das Barras Principais 
        tbBarra1.setBounds(4, 0, 780, 30);
        tbBarra1.setFloatable(false);
        tbBarra2.setBounds(4, 31, 780, 30);
        tbBarra2.setFloatable(false);

        //Posiciontamento da TabbedPane
        tpPainel.setBounds(4, 60, 760, 550);

    }

    public void instanciarPrincipal() {
        panelPrincipal = new JPanel();
        panelPrincipal.setLayout(null);

        panelDadosGerais = new JPanel();
        panelDadosGerais.setLayout(null);
        panelDadosGerais.setBorder(BorderFactory.createTitledBorder("Dados Gerais"));

        lblEmpresa = new JLabel("Empresa");
        boxEmpresa = new JComboBox<>();
        lblDivicaoRh = new JLabel("Divisão Rh");
        boxDivicaoRh = new JComboBox<>();
        lblMatricula = new JLabel("Matrícula");
        txtMatricula = new JTextField(5);
        lblFuncinario = new JLabel("Funcionário");
        txtFuncionario = new JTextField();

        panelEndereco = new JPanel();
        panelEndereco.setLayout(null);
        panelEndereco.setBorder(BorderFactory.createTitledBorder("Endereço"));

        lblCep = new JLabel("Cep");
        txtCep = new JTextField(5);
        lblEndereco1 = new JLabel("Endereço");
        txtEndereco = new JTextField(5);
        lblNumero = new JLabel("Número");
        txtNumero = new JTextField(5);
        lblBairro = new JLabel("Bairro");
        txtBairro = new JTextField(5);
        lblMunicipio = new JLabel("Município");
        boxMuncipio = new JComboBox<>();

        lblTelefone = new JLabel("Telefone");
        txtTelefone = new JTextField(5);
        lblTelefoneCel = new JLabel("Telefone Cel");
        txtTelefoneCel = new JTextField(5);
        lblEmail = new JLabel("Email");
        txtEmail = new JTextField(5);

        panelDadosPessoais = new JPanel();
        panelDadosPessoais.setLayout(null);
        panelDadosPessoais.setBorder(BorderFactory.createTitledBorder("Dados Pessoais"));
        lblDadosPessoais = new JLabel("Dados Pessoais");
        lblSexo = new JLabel("Sexo");
        boxSexo = new JComboBox<>();

        lblDataNasc = new JLabel("Data de Nascimento");
        SpinnerDateModel dateModel = new SpinnerDateModel();
        spinDataNasc = new JSpinner(dateModel);
        Calendar calendar = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataNasc.setValue(calendar.getTime());

        lblEstadoCivil = new JLabel("Estado Civil");
        boxEstadoCivil = new JComboBox<>();

        lblNaturalidade = new JLabel("Naturalidade");
        txtNaturalidade = new JTextField(5);
        lblGrauDeInstrucao = new JLabel("Grau de Instrução");
        boxGrauDeInstrucao = new JComboBox();

        lblNacionalidade = new JLabel("Nacionalidade");
        txtNacionalidade = new JTextField(5);
        lblFormacao = new JLabel("Formação");
        txtFormacao = new JTextField(5);

        panelFiliacao = new JPanel();
        panelFiliacao.setLayout(null);
        panelFiliacao.setBorder(BorderFactory.createTitledBorder("Filiação"));
        lblFiliacao = new JLabel("Filiação");
        lblPai = new JLabel("Pai");
        txtPai = new JTextField(5);
        lblMae = new JLabel("Mãe");
        txtMae = new JTextField(5);
    }

    public void instanciarDocumentacao() {
        panelDocumetacao = new JPanel();
        panelDocumetacao.setLayout(null);

        panelRg = new JPanel();
        panelRg.setLayout(null);
        panelRg.setBorder(BorderFactory.createTitledBorder("RG"));
        lblNumeroRg = new JLabel("Número");
        txtNumeroRg = new JTextField(10);
        lblOrgaoExpeditor = new JLabel("Orgão Expeditor");
        txtOrgaoExpeditorRg = new JTextField(7);
        lblUf = new JLabel("UF");
        boxUf = new JComboBox();
        boxUf.setPreferredSize(new Dimension(55, 20));
        lblDataExpedicaoRg = new JLabel("Data de Expedição");
        SpinnerDateModel dateModel = new SpinnerDateModel();
        spinDataExpedicaoRg = new JSpinner(dateModel);
        Calendar calendar = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataExpedicaoRg.setValue(calendar.getTime());

        panelMilitar = new JPanel();
        panelMilitar.setLayout(null);
        panelMilitar.setBorder(BorderFactory.createTitledBorder("Informação Militar"));

        lblSituacao = new JLabel("Situação");
        txtSituacao = new JTextField(20);
        lblDataBaixa = new JLabel("Data Baixa");
        SpinnerDateModel dateModel2 = new SpinnerDateModel();
        spinDataBaixa = new JSpinner(dateModel2);
        Calendar calendar2 = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataBaixa.setValue(calendar2.getTime());

        lblNumeroMilitar = new JLabel("Número");
        txtNumeroMilitar = new JTextField(16);
        lblCategoria = new JLabel("Categoria");
        boxCategoria = new JComboBox();
        boxCategoria.setPreferredSize(new Dimension(180, 20));

        panelCnh = new JPanel();
        panelCnh.setLayout(null);
        panelCnh.setBorder(BorderFactory.createTitledBorder("CNH"));

        lblNumeroCnh = new JLabel("Número");
        txtNumeroCnh = new JTextField();
        lblCategoriaCnh = new JLabel("Categoria");
        txtCategoriaCnh = new JTextField();
        lblDataCadastro = new JLabel("Data Cadastro");
        SpinnerDateModel dateModel3 = new SpinnerDateModel();
        spinDataCadastroCnh = new JSpinner(dateModel3);
        Calendar calendar3 = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataCadastroCnh.setValue(calendar3.getTime());
        lblDataVencimentos = new JLabel("Data Vencimento");
        SpinnerDateModel dateModel4 = new SpinnerDateModel();
        spinDataVencimentoCnh = new JSpinner(dateModel4);
        Calendar calendar4 = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataVencimentoCnh.setValue(calendar4.getTime());

        panelConselho = new JPanel();
        panelConselho.setLayout(null);
        panelConselho.setBorder(BorderFactory.createTitledBorder("Conselho regional"));

        lblNomeConselho = new JLabel("Nome");
        txtNomeConselho = new JTextField();
        lblSigla = new JLabel("Sigla");
        txtSigla = new JTextField();
        lblRegRegiao = new JLabel("Reg. Região");
        txtRegRegiao = new JTextField();
        lblNumeroConselho = new JLabel("Número");
        txtNumeroConselho = new JTextField();
        lblDataExpedicao = new JLabel("Data Expedição");
        SpinnerDateModel dateModel5 = new SpinnerDateModel();
        spinDataExpedicaoConselho = new JSpinner(dateModel5);
        Calendar calendar5 = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataExpedicaoConselho.setValue(calendar5.getTime());
        lblOrgaoEmissorConselho = new JLabel("Org. Emissor");
        txtOrgaoEmissorConselho = new JTextField();
        lblDataValidadeConselho = new JLabel("Data Validade");
        SpinnerDateModel dateModel6 = new SpinnerDateModel();
        spinDataValidadeConselho = new JSpinner(dateModel6);
        Calendar calendar6 = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataValidadeConselho.setValue(calendar6.getTime());

        panelCtps = new JPanel();
        panelCtps.setLayout(null);
        panelCtps.setBorder(BorderFactory.createTitledBorder("CTPS"));
        lblNumeroCtps = new JLabel("Número");
        txtNumeroCtps = new JTextField();
        lblSerie = new JLabel("Série");
        txtSerie = new JTextField();
        lblOrgao = new JLabel("Orgão");
        txtOrgao = new JTextField();
        lblUfCtps = new JLabel("UF");
        boxUfCtps = new JComboBox();

        panelCpf = new JPanel();
        panelCpf.setLayout(null);
        panelCpf.setBorder(BorderFactory.createTitledBorder("CPF"));
        lblNumeroCpf = new JLabel("Número");
        txtNumeroCpf = new JTextField();

        panelPis = new JPanel();
        panelPis.setLayout(null);
        panelPis.setBorder(BorderFactory.createTitledBorder("PIS"));
        lblNumeroPis = new JLabel("Número");
        txtNumeroPis = new JTextField();
        lblDataCadastroPis = new JLabel("Data Cadastro");
        SpinnerDateModel dateModel7 = new SpinnerDateModel();
        spinDataCadastroPis = new JSpinner(dateModel7);
        Calendar calendar7 = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataCadastroPis.setValue(calendar7.getTime());

        panelTitulo = new JPanel();
        panelTitulo.setLayout(null);
        panelTitulo.setBorder(BorderFactory.createTitledBorder("Título de Eleitor"));
        lblNumTituloEleitor = new JLabel("Número");
        txtNumeroEleitor = new JTextField();
        lblZona = new JLabel("Zona");
        txtZona = new JTextField();
        lblSecao = new JLabel("Seção");
        txtSecao = new JTextField();

        panelRic = new JPanel();
        panelRic.setLayout(null);
        panelRic.setBorder(BorderFactory.createTitledBorder("RIC"));
        lblNumRic = new JLabel("Número");
        txtNumeroRic = new JTextField();
        lblOrgaoExpedidorRic = new JLabel("Orgão Expedidor");
        txtOrgaoExpedidorRic = new JTextField();
        lblDataexpedicaoRic = new JLabel("Data Expedição");
        SpinnerDateModel dateModel8 = new SpinnerDateModel();
        spinDataExpedicaoRic = new JSpinner(dateModel8);
        Calendar calendar8 = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataExpedicaoRic.setValue(calendar8.getTime());
    }

    public void instanciarContrato() {
        panelContrato = new JPanel();
        panelContrato.setLayout(null);

        panelConVinculo = new JPanel();
        panelConVinculo.setLayout(null);
        panelConVinculo.setBorder(
                BorderFactory.createTitledBorder("")
        );

        panelConFgts = new JPanel();
        panelConFgts.setLayout(null);
        panelConFgts.setBorder(
                BorderFactory.createTitledBorder("FGTS")
        );

        panelConAtividade = new JPanel();
        panelConAtividade.setLayout(null);
        panelConAtividade.setBorder(
                BorderFactory.createTitledBorder("Atividade Desenvolvida")
        );

        panelConAdiantamento = new JPanel();
        panelConAdiantamento.setLayout(null);
        panelConAdiantamento.setBorder(
                BorderFactory.createTitledBorder("Adiantamento Quinzenal")
        );

        panelConExperiencia = new JPanel();
        panelConExperiencia.setLayout(null);
        panelConExperiencia.setBorder(
                BorderFactory.createTitledBorder("Experiência")
        );

        panelConSalario = new JPanel();
        panelConSalario.setLayout(null);
        panelConSalario.setBorder(
                BorderFactory.createTitledBorder("")
        );

        panelConCargo = new JPanel();
        panelConCargo.setLayout(null);
        panelConCargo.setBorder(
                BorderFactory.createTitledBorder("")
        );

        panelConCategoria = new JPanel();
        panelConCategoria.setLayout(null);
        panelConCategoria.setBorder(
                BorderFactory.createTitledBorder("")
        );

        panelConRecisao = new JPanel();
        panelConRecisao.setLayout(null);
        panelConRecisao.setBorder(
                BorderFactory.createTitledBorder("Recisão")
        );

        lblVinculo = new JLabel("Vínculo");
        boxVinculo = new JComboBox<>();
        boxVinculo.addItem("Trabalhador Urbano");
        boxVinculo.addItem("Trabalhador Rural");

        lblTipoAdmissao = new JLabel("Tipo de Admissão");
        boxTipoAdmissao = new JComboBox<>();
        boxTipoAdmissao.addItem("Reemprego");
        boxTipoAdmissao.addItem("Emprego");

        lblDataAdmissao = new JLabel("Data Admissão");
        SpinnerDateModel dataAdmissao = new SpinnerDateModel();
        spinDataAdmissao = new JSpinner(dataAdmissao);
        Calendar calendarioAdmissao = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataAdmissao.setValue(calendarioAdmissao.getTime());

        lblTipoSalario = new JLabel("Tipo Salario");
        boxTipoSalario = new JComboBox<>();
        boxTipoSalario.addItem("Mensal");
        boxTipoSalario.addItem("Anual");

        lblHorario = new JLabel("Horario");
        boxHorario = new JComboBox<>();
        boxHorario.addItem("Diurno");
        boxHorario.addItem("Noturno");

        lblHrsSem = new JLabel("Hrs. Sem.");
        txtHrsSem = new JTextField("220");

        lblFgts = new JLabel("FGTS");

        lblOpcao = new JLabel("Opção");
        boxOpcao = new JComboBox<>();
        boxOpcao.addItem("Optante");
        boxOpcao.addItem("N sei oq colocar");
        lblDataOpcao = new JLabel("Data Opção");
        SpinnerDateModel dataOpcao = new SpinnerDateModel();
        spinDataOpcao = new JSpinner(dataOpcao);
        Calendar calendarioOpcao = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataOpcao.setValue(calendarioOpcao.getTime());

        lblAtividadeDesenvolvida = new JLabel("Atividade Desenvolvida");
        rbUrbana = new JRadioButton("Urbana", false);
        rbRural = new JRadioButton("Rural", false);

        lblAdiantamentoQuinzenal = new JLabel("Adiantamento Quinzenal");
        lblAdiantamento = new JLabel("Adiantamento");
        boxAdiantamento = new JComboBox<>();
        boxAdiantamento.addItem("Sim");
        boxAdiantamento.addItem("Não");
        lblPercentual = new JLabel("Percentual");
        txtPercentual = new JTextField("35,00");
        lblValorFixo = new JLabel("Valor Fixo");
        txtValorFixo = new JTextField("0,00");

        lblExperiencia = new JLabel("Experiência");
        lblVencimento = new JLabel("Vencimento");
        SpinnerDateModel dataVencimento = new SpinnerDateModel();
        spinVencimento = new JSpinner(dataVencimento);
        Calendar calendarioVencimento = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinVencimento.setValue(calendarioVencimento.getTime());
        lblProrrogacao = new JLabel("Prorrogação");
        SpinnerDateModel dataProrrogacao = new SpinnerDateModel();
        spinProrrogacao = new JSpinner(dataProrrogacao);
        Calendar calendarioProrrogacao = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinProrrogacao.setValue(calendarioProrrogacao.getTime());

        lblValorSalario = new JLabel("Valor Salário");
        txtValorSalario = new JTextField("2620,00");
        lblTipoReajuste = new JLabel("Tipo de Reajuste");
        boxTipoReajuste = new JComboBox<>();
        boxTipoReajuste.addItem("Variável");
        boxTipoReajuste.addItem("Constante");

        lblCargo = new JLabel("Cargo");
        boxCargo = new JComboBox<>();
        boxCargo.addItem("Gerente");
        boxCargo.addItem("Supervisor");
        boxCargo.addItem("Operador");
        lblDepartamento = new JLabel("Departamento");
        boxDepartamento = new JComboBox<>();
        boxDepartamento.addItem("Operacional");
        boxDepartamento.addItem("Planejamento");
        boxDepartamento.addItem("TI");

        lblCategoriaGfip = new JLabel("Categoria GFIP");
        boxCategoriaGfip = new JComboBox<>();
        boxCategoriaGfip.addItem("Categoria 1");
        boxCategoriaGfip.addItem("Categoria 2");
        lblTipoContrato = new JLabel("Tipo Contrato");
        boxTipoContrato = new JComboBox<>();
        boxTipoContrato.addItem("Tipo 1");
        boxTipoContrato.addItem("Tipo 2");

        lblRecisao = new JLabel("Recisão");
        lblDataDemissao = new JLabel("Data Demissão");
        SpinnerDateModel dataDemissao = new SpinnerDateModel();
        spinDataDemissao = new JSpinner(dataDemissao);
        Calendar calendarioDemissao = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataDemissao.setValue(calendarioDemissao.getTime());
        lblMotivoDemissao = new JLabel("Motivo Demissão");
        boxMotivoDemissao = new JComboBox<>();
        boxMotivoDemissao.addItem("Justa Causa");
        boxMotivoDemissao.addItem("Acordo");
        lblDataAvisoInicio = new JLabel("Data Aviso Início");
        SpinnerDateModel dataAvisoInicio = new SpinnerDateModel();
        spinDataAvisoInicio = new JSpinner(dataAvisoInicio);
        Calendar calendarioAvisoInicio = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataAvisoInicio.setValue(calendarioAvisoInicio.getTime());
        lblDataAvisoFim = new JLabel("Data Aviso Fim");
        SpinnerDateModel dataAvisoFim = new SpinnerDateModel();
        spinDataAvisoFim = new JSpinner(dataAvisoFim);
        Calendar calendarioAvisoFim = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataAvisoFim.setValue(calendarioAvisoFim.getTime());
        lblMotivoRais = new JLabel("Motivo RAIS");
        boxMotivoRais = new JComboBox<>();
        boxMotivoRais.addItem("RAIS 1");
        boxMotivoRais.addItem("RAIS 2");
        cbAvisoPrevio = new JCheckBox("Aviso Prévio");
    }

    public void instanciarOperacional() {
        panelOperacional = new JPanel();
        panelOperacional.setLayout(null);

        panelOpChecks = new JPanel();
        panelOpChecks.setLayout(null);
        panelOpChecks.setBorder(
                BorderFactory.createTitledBorder("Seleções")
        );

        panelOpRaca = new JPanel();
        panelOpRaca.setLayout(null);
        panelOpRaca.setBorder(
                BorderFactory.createTitledBorder("")
        );

        panelOpSindicato = new JPanel();
        panelOpSindicato.setLayout(null);
        panelOpSindicato.setBorder(
                BorderFactory.createTitledBorder("Sindicato")
        );

        panelOpDados = new JPanel();
        panelOpDados.setLayout(null);
        panelOpDados.setBorder(
                BorderFactory.createTitledBorder("Dados do Funcionário")
        );

        panelOpExames = new JPanel();
        panelOpExames.setLayout(null);
        panelOpExames.setBorder(
                BorderFactory.createTitledBorder("Exames Admissionais")
        );

        panelOpFoto = new JPanel();
        panelOpFoto.setLayout(null);
        panelOpFoto.setBorder(
                BorderFactory.createTitledBorder("Foto")
        );

        cbInss = new JCheckBox("INSS");
        cbFgts = new JCheckBox("FGTS");
        cbIrrf = new JCheckBox("IRRF");
        cbReembolsoInss = new JCheckBox("Reembolso INSS/IRRF");
        cbEmpregadoDomestico = new JCheckBox("Empregado Doméstico");
        cbBeneficioPrevidencia = new JCheckBox("Benefício Previdência - Aposentadoria");
        cbValeTransporte = new JCheckBox("Vale Transporte");
        cbValeRefeicao = new JCheckBox("Vale Refeição");
        cbPlanoSaude = new JCheckBox("Plano de Saúde");

        lblRacaCor = new JLabel("Raça/Cor");
        boxRacaCor = new JComboBox<>();
        boxRacaCor.addItem("Branco");
        boxRacaCor.addItem("Pardo");
        boxRacaCor.addItem("Preto");
        boxRacaCor.addItem("Vermelho");
        boxRacaCor.addItem("Amarelo");
        lblTipoDeficiencia = new JLabel("Tipo de Deficiência");
        boxTipoDeficiencia = new JComboBox<>();
        boxTipoDeficiencia.addItem("Física");
        boxTipoDeficiencia.addItem("Mental");
        boxTipoDeficiencia.addItem("Social");

        lblSindicato = new JLabel("Sindicato");
        boxSindicato = new JComboBox<>();
        boxSindicato.addItem("Sindicato Funcional");
        boxSindicato.addItem("Sindicato não Funcional");
        lblMesDissidio = new JLabel("Mês Dissídio");
        boxMesDissidio = new JComboBox<>();
        boxMesDissidio.addItem("Janeiro");
        boxMesDissidio.addItem("Fevereiro");
        boxMesDissidio.addItem("Março");
        boxMesDissidio.addItem("Abril");
        boxMesDissidio.addItem("Maio");
        boxMesDissidio.addItem("Junho");
        boxMesDissidio.addItem("Julho");

        lblDadosFuncionario = new JLabel("Dados do Funcionario");
        lblFormaPagamento = new JLabel("Forma de Pagamento");
        boxFormaPagamento = new JComboBox<>();
        boxFormaPagamento.addItem("Débito em Conta");
        boxFormaPagamento.addItem("Boleto");
        lblBanco = new JLabel("Banco");
        boxBanco = new JComboBox<>();
        boxBanco.addItem("Banco do Brasil");
        boxBanco.addItem("Santander");
        lblAgencia = new JLabel("Agência");
        txtAgencia = new JTextField("2665");
        lblNumeroConta = new JLabel("Número da Conta");
        txtNumeroConta = new JTextField("44668");

        lblExamesAdicionais = new JLabel("Exames Adicionais");
        lblNomeMedico = new JLabel("Nome do Médico");
        txtNomeMedico = new JTextField("");
        lblCrm = new JLabel("CRM");
        txtCrm = new JTextField("");
        lblDataExame = new JLabel("Data do Exame");
        SpinnerDateModel dataExame = new SpinnerDateModel();
        spinDataExame = new JSpinner(dataExame);
        Calendar calendarioExame = new GregorianCalendar(2000, Calendar.JANUARY, 1);
        spinDataExame.setValue(calendarioExame.getTime());

        lblFoto = new JLabel();
        lblFoto.setIcon(new ImageIcon(getClass().getResource("/imagens/form.jpg")));

        btSelecionar = new JButton("Selecionar");
        btSelecionar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                carregarFoto();
            }
        });

        btLimpar = new JButton("Limpar");
        btLimpar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpaFoto();
            }
        });

    }

    private void carregarFoto() {

        JFileChooser jfc = new JFileChooser();
        jfc.setDialogTitle("Selecionar foto");
        jfc.setFileFilter(new FileNameExtensionFilter("Arquivo de imagens (*.PNG, *.JPG, *.JPEG)", "png", "jpg", "jpeg"));
        int resultado = jfc.showOpenDialog(this);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            try {
                fis = new FileInputStream(jfc.getSelectedFile());
                tamanho = (int) jfc.getSelectedFile().length();
                Image foto = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(lblFoto.getWidth(), lblFoto.getHeight(), Image.SCALE_SMOOTH);
                lblFoto.setIcon(new ImageIcon(foto));
                lblFoto.updateUI();

            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    private void limpaFoto() {
        lblFoto.setIcon(new ImageIcon(getClass().getResource("/imagens/form.jpg")));
    }

    public void adicionarPrincipal() {
        panelPrincipal.add(panelDadosGerais);
        panelDadosGerais.add(lblEmpresa);
        panelDadosGerais.add(boxEmpresa);
        panelDadosGerais.add(lblDivicaoRh);
        panelDadosGerais.add(boxDivicaoRh);
        panelDadosGerais.add(lblMatricula);
        panelDadosGerais.add(txtMatricula);
        panelDadosGerais.add(lblFuncinario);
        panelDadosGerais.add(txtFuncionario);

        panelPrincipal.add(panelEndereco);
        panelEndereco.add(lblEndereco1);
        panelEndereco.add(lblCep);
        panelEndereco.add(txtCep);
        panelEndereco.add(lblEndereco1);
        panelEndereco.add(txtEndereco);
        panelEndereco.add(lblNumero);
        panelEndereco.add(txtNumero);
        panelEndereco.add(lblBairro);
        panelEndereco.add(txtBairro);
        panelEndereco.add(lblMunicipio);
        panelEndereco.add(boxMuncipio);
        panelEndereco.add(lblTelefone);
        panelEndereco.add(txtTelefone);
        panelEndereco.add(lblTelefoneCel);
        panelEndereco.add(txtTelefoneCel);
        panelEndereco.add(lblEmail);
        panelEndereco.add(txtEmail);

        panelPrincipal.add(panelDadosPessoais);
        panelDadosPessoais.add(lblSexo);
        panelDadosPessoais.add(boxSexo);
        panelDadosPessoais.add(lblDataNasc);
        panelDadosPessoais.add(spinDataNasc);
        panelDadosPessoais.add(lblEstadoCivil);
        panelDadosPessoais.add(boxEstadoCivil);
        panelDadosPessoais.add(lblNaturalidade);
        panelDadosPessoais.add(txtNaturalidade);
        panelDadosPessoais.add(lblGrauDeInstrucao);
        panelDadosPessoais.add(boxGrauDeInstrucao);
        panelDadosPessoais.add(lblNacionalidade);
        panelDadosPessoais.add(txtNacionalidade);
        panelDadosPessoais.add(lblFormacao);
        panelDadosPessoais.add(txtFormacao);

        panelDadosPessoais.add(panelFiliacao);
        panelFiliacao.add(lblPai);
        panelFiliacao.add(txtPai);
        panelFiliacao.add(lblMae);
        panelFiliacao.add(txtMae);
    }

    public void adicionarDocumentacao() {
        panelDocumetacao.add(panelRg);
        panelRg.add(lblNumeroRg);
        panelRg.add(txtNumeroRg);
        panelRg.add(lblOrgaoExpeditor);
        panelRg.add(txtOrgaoExpeditorRg);
        panelRg.add(lblUf);
        panelRg.add(boxUf);
        panelRg.add(lblDataExpedicaoRg);
        panelRg.add(spinDataExpedicaoRg);

        panelDocumetacao.add(panelMilitar);
        panelMilitar.add(lblSituacao);
        panelMilitar.add(txtSituacao);
        panelMilitar.add(lblDataBaixa);
        panelMilitar.add(spinDataBaixa);
        panelMilitar.add(lblNumeroMilitar);
        panelMilitar.add(txtNumeroMilitar);
        panelMilitar.add(lblCategoria);
        panelMilitar.add(boxCategoria);

        panelDocumetacao.add(panelCnh);
        panelCnh.add(lblNumeroCnh);
        panelCnh.add(txtNumeroCnh);
        panelCnh.add(lblCategoriaCnh);
        panelCnh.add(txtCategoriaCnh);
        panelCnh.add(lblDataCadastro);
        panelCnh.add(spinDataCadastroCnh);
        panelCnh.add(lblDataVencimentos);
        panelCnh.add(spinDataVencimentoCnh);

        panelDocumetacao.add(panelConselho);
        panelConselho.add(lblNomeConselho);
        panelConselho.add(txtNomeConselho);
        panelConselho.add(lblSigla);
        panelConselho.add(txtSigla);
        panelConselho.add(lblRegRegiao);
        panelConselho.add(txtRegRegiao);
        panelConselho.add(lblNumeroConselho);
        panelConselho.add(txtNumeroConselho);
        panelConselho.add(lblDataExpedicao);
        panelConselho.add(spinDataExpedicaoConselho);
        panelConselho.add(lblOrgaoEmissorConselho);
        panelConselho.add(txtOrgaoEmissorConselho);
        panelConselho.add(lblDataValidadeConselho);
        panelConselho.add(spinDataValidadeConselho);

        panelDocumetacao.add(panelCtps);
        panelCtps.add(lblNumeroCtps);
        panelCtps.add(txtNumeroCtps);
        panelCtps.add(lblSerie);
        panelCtps.add(txtSerie);
        panelCtps.add(lblOrgao);
        panelCtps.add(txtOrgao);
        panelCtps.add(lblUfCtps);
        panelCtps.add(boxUfCtps);

        panelDocumetacao.add(panelCpf);
        panelCpf.add(lblNumeroCpf);
        panelCpf.add(txtNumeroCpf);

        panelDocumetacao.add(panelPis);
        panelPis.add(lblNumeroPis);
        panelPis.add(txtNumeroPis);
        panelPis.add(lblDataCadastroPis);
        panelPis.add(spinDataCadastroPis);

        panelDocumetacao.add(panelTitulo);
        panelTitulo.add(lblNumTituloEleitor);
        panelTitulo.add(txtNumeroEleitor);
        panelTitulo.add(lblZona);
        panelTitulo.add(txtZona);
        panelTitulo.add(lblSecao);
        panelTitulo.add(txtSecao);

        panelDadosPessoais.add(panelRic);
        panelRic.add(lblNumRic);
        panelRic.add(txtNumeroRic);
        panelRic.add(lblOrgaoExpedidorRic);
        panelRic.add(txtOrgaoExpedidorRic);
        panelRic.add(lblDataexpedicaoRic);
        panelRic.add(spinDataExpedicaoRic);
    }

    public void adicionarContrato() {

        panelContrato.add(panelConVinculo);
        panelContrato.add(panelConFgts);
        panelContrato.add(panelConAtividade);
        panelContrato.add(panelConAdiantamento);
        panelContrato.add(panelConExperiencia);
        panelContrato.add(panelConSalario);
        panelContrato.add(panelConCargo);
        panelContrato.add(panelConCategoria);
        panelContrato.add(panelConRecisao);

        panelConVinculo.add(lblVinculo);
        panelConVinculo.add(boxVinculo);
        panelConVinculo.add(lblTipoAdmissao);
        panelConVinculo.add(boxTipoAdmissao);
        panelConVinculo.add(lblDataAdmissao);
        panelConVinculo.add(spinDataAdmissao);
        panelConVinculo.add(lblTipoSalario);
        panelConVinculo.add(boxTipoSalario);
        panelConVinculo.add(lblHorario);
        panelConVinculo.add(boxHorario);
        panelConVinculo.add(lblHrsSem);
        panelConVinculo.add(txtHrsSem);
        panelConFgts.add(lblFgts);
        panelConFgts.add(lblOpcao);
        panelConFgts.add(boxOpcao);
        panelConFgts.add(lblDataOpcao);
        panelConFgts.add(spinDataOpcao);
        panelConAtividade.add(lblAtividadeDesenvolvida);
        panelConAtividade.add(rbUrbana);
        panelConAtividade.add(rbRural);
        panelConAdiantamento.add(lblAdiantamentoQuinzenal);
        panelConAdiantamento.add(lblAdiantamento);
        panelConAdiantamento.add(boxAdiantamento);
        panelConAdiantamento.add(lblPercentual);
        panelConAdiantamento.add(txtPercentual);
        panelConAdiantamento.add(lblValorFixo);
        panelConAdiantamento.add(txtValorFixo);
        panelConExperiencia.add(lblExperiencia);
        panelConExperiencia.add(lblVencimento);
        panelConExperiencia.add(spinVencimento);
        panelConExperiencia.add(lblProrrogacao);
        panelConExperiencia.add(spinProrrogacao);
        panelConSalario.add(lblValorSalario);
        panelConSalario.add(txtValorSalario);
        panelConSalario.add(lblTipoReajuste);
        panelConSalario.add(boxTipoReajuste);

        panelConCargo.add(lblCargo);
        panelConCargo.add(boxCargo);
        panelConCargo.add(lblDepartamento);
        panelConCargo.add(boxDepartamento);
        panelConCategoria.add(lblCategoriaGfip);
        panelConCategoria.add(boxCategoriaGfip);
        panelConCategoria.add(lblTipoContrato);
        panelConCategoria.add(boxTipoContrato);
        panelConRecisao.add(lblRecisao);
        panelConRecisao.add(lblDataDemissao);
        panelConRecisao.add(spinDataDemissao);
        panelConRecisao.add(lblMotivoDemissao);
        panelConRecisao.add(boxMotivoDemissao);
        panelConRecisao.add(lblDataAvisoInicio);
        panelConRecisao.add(spinDataAvisoInicio);
        panelConRecisao.add(lblDataAvisoFim);
        panelConRecisao.add(spinDataAvisoFim);
        panelConRecisao.add(lblMotivoRais);
        panelConRecisao.add(boxMotivoRais);
        panelConRecisao.add(cbAvisoPrevio);
    }

    public void adicionarOperacional() {
        panelOperacional.add(panelOpChecks);
        panelOperacional.add(panelOpRaca);
        panelOperacional.add(panelOpSindicato);
        panelOperacional.add(panelOpDados);
        panelOperacional.add(panelOpExames);
        panelOperacional.add(panelOpFoto);
        panelOpChecks.add(cbInss);
        panelOpChecks.add(cbFgts);
        panelOpChecks.add(cbIrrf);
        panelOpChecks.add(cbReembolsoInss);
        panelOpChecks.add(cbEmpregadoDomestico);
        panelOpChecks.add(cbBeneficioPrevidencia);
        panelOpChecks.add(cbValeTransporte);
        panelOpChecks.add(cbValeRefeicao);
        panelOpChecks.add(cbPlanoSaude);

        panelOpRaca.add(lblRacaCor);
        panelOpRaca.add(boxRacaCor);
        panelOpRaca.add(lblTipoDeficiencia);
        panelOpRaca.add(boxTipoDeficiencia);

        panelOpSindicato.add(lblSindicato);
        panelOpSindicato.add(boxSindicato);
        panelOpSindicato.add(lblMesDissidio);
        panelOpSindicato.add(boxMesDissidio);

        panelOpDados.add(lblDadosFuncionario);
        panelOpDados.add(lblFormaPagamento);
        panelOpDados.add(boxFormaPagamento);
        panelOpDados.add(lblBanco);
        panelOpDados.add(boxBanco);
        panelOpDados.add(lblAgencia);
        panelOpDados.add(txtAgencia);
        panelOpDados.add(lblNumeroConta);
        panelOpDados.add(txtNumeroConta);

        panelOpExames.add(lblExamesAdicionais);
        panelOpExames.add(lblNomeMedico);
        panelOpExames.add(txtNomeMedico);
        panelOpExames.add(lblCrm);
        panelOpExames.add(txtCrm);
        panelOpExames.add(lblDataExame);
        panelOpExames.add(spinDataExame);

        panelOpFoto.add(lblFoto);
        panelOpFoto.add(btSelecionar);
        panelOpFoto.add(btLimpar);
    }

    private void posicionarPrincipal() {

        //Posicionando os Dados Gerais 
        panelDadosGerais.setBounds(4, 10, 742, 108);

        lblEmpresa.setBounds(8, -75, 100, 200);
        boxEmpresa.setBounds(8, 35, 300, 20);
        lblDivicaoRh.setBounds(380, -75, 100, 200);
        boxDivicaoRh.setBounds(380, 35, 300, 20);
        lblMatricula.setBounds(8, -30, 100, 200);
        txtMatricula.setBounds(6, 79, 146, 20);
        lblFuncinario.setBounds(180, -30, 100, 200);
        txtFuncionario.setBounds(180, 79, 540, 20);

        //Posicionando o Endereço
        panelEndereco.setBounds(4, 120, 742, 130);
        lblCep.setBounds(8, -70, 100, 200);
        txtCep.setBounds(8, 38, 100, 20);
        lblEndereco1.setBounds(150, -70, 100, 200);
        txtEndereco.setBounds(150, 38, 236, 20);
        lblNumero.setBounds(403, -70, 100, 200);
        txtNumero.setBounds(403, 38, 70, 20);
        lblBairro.setBounds(490, -70, 100, 200);
        txtBairro.setBounds(490, 38, 230, 20);
        lblMunicipio.setBounds(8, -30, 100, 200);
        boxMuncipio.setBounds(8, 80, 240, 20);
        lblTelefone.setBounds(255, -30, 100, 200);
        txtTelefone.setBounds(255, 80, 100, 20);
        lblTelefoneCel.setBounds(360, -30, 100, 200);
        txtTelefoneCel.setBounds(360, 80, 100, 20);
        lblEmail.setBounds(470, -30, 100, 200);
        txtEmail.setBounds(470, 80, 250, 20);

        //Posicionamento os Dados Pessoais
        panelDadosPessoais.setBounds(4, 250, 743, 180);
        lblSexo.setBounds(8, -70, 100, 200);
        boxSexo.setBounds(8, 38, 110, 20);
        lblDataNasc.setBounds(150, -70, 120, 200);
        spinDataNasc.setBounds(150, 38, 120, 20);
        lblEstadoCivil.setBounds(300, -70, 100, 200);
        boxEstadoCivil.setBounds(300, 38, 150, 20);
        lblNaturalidade.setBounds(8, -18, 100, 200);
        txtNaturalidade.setBounds(8, 90, 210, 20);
        lblNacionalidade.setBounds(270, -18, 100, 200);
        txtNacionalidade.setBounds(270, 90, 200, 20);
        lblGrauDeInstrucao.setBounds(8, 30, 170, 200);
        boxGrauDeInstrucao.setBounds(8, 140, 170, 22);
        lblFormacao.setBounds(270, 30, 100, 200);
        txtFormacao.setBounds(270, 140, 200, 20);

        //Posicionando Filiação 
        panelFiliacao.setBounds(476, 15, 260, 160);
        lblPai.setBounds(15, -70, 100, 200);
        txtPai.setBounds(15, 42, 220, 20);
        lblMae.setBounds(15, -25, 100, 200);
        txtMae.setBounds(15, 85, 220, 20);
    }

    private void posicionarDocumentacao() {
        panelRg.setBounds(4, 10, 420, 80);
        lblNumeroRg.setBounds(7, -80, 100, 200);
        txtNumeroRg.setBounds(7, 28, 100, 20);
        lblOrgaoExpeditor.setBounds(118, -80, 100, 200);
        txtOrgaoExpeditorRg.setBounds(118, 28, 96, 20);
        lblUf.setBounds(230, -80, 100, 200);
        boxUf.setBounds(230, 28, 53, 20);
        lblDataExpedicaoRg.setBounds(290, -80, 130, 200);
        spinDataExpedicaoRg.setBounds(290, 28, 120, 20);

        panelMilitar.setBounds(4, 90, 420, 160);
        lblSituacao.setBounds(7, -70, 100, 200);
        txtSituacao.setBounds(7, 38, 260, 20);
        lblDataBaixa.setBounds(290, -70, 100, 200);
        spinDataBaixa.setBounds(290, 38, 120, 20);
        lblNumeroMilitar.setBounds(7, -24, 100, 200);
        txtNumeroMilitar.setBounds(7, 86, 190, 20);
        lblCategoria.setBounds(215, -24, 100, 200);
        boxCategoria.setBounds(215, 86, 190, 20);

        panelCnh.setBounds(4, 249, 420, 80);
        lblNumeroCnh.setBounds(7, -70, 100, 200);
        txtNumeroCnh.setBounds(7, 38, 120, 20);
        lblCategoriaCnh.setBounds(136, -70, 100, 200);
        txtCategoriaCnh.setBounds(136, 38, 60, 20);
        lblDataCadastro.setBounds(205, -70, 100, 200);
        spinDataCadastroCnh.setBounds(205, 38, 100, 20);
        lblDataVencimentos.setBounds(316, -70, 100, 200);
        spinDataVencimentoCnh.setBounds(316, 38, 100, 20);

        panelConselho.setBounds(4, 332, 420, 138);
        lblNomeConselho.setBounds(7, -70, 100, 200);
        txtNomeConselho.setBounds(7, 38, 200, 20);
        lblSigla.setBounds(220, -70, 100, 200);
        txtSigla.setBounds(220, 38, 80, 20);
        lblRegRegiao.setBounds(305, -70, 100, 200);
        txtRegRegiao.setBounds(305, 38, 100, 20);
        lblNumeroConselho.setBounds(7, -20, 100, 200);
        txtNumeroConselho.setBounds(7, 88, 103, 20);
        lblDataExpedicao.setBounds(115, -20, 100, 200);
        spinDataExpedicaoConselho.setBounds(115, 88, 100, 20);
        lblOrgaoEmissorConselho.setBounds(225, -20, 100, 200);
        txtOrgaoEmissorConselho.setBounds(225, 88, 62, 20);
        lblDataValidadeConselho.setBounds(310, -20, 100, 200);
        spinDataValidadeConselho.setBounds(310, 88, 100, 20);

        panelCtps.setBounds(425, 10, 330, 80);
        lblNumeroCtps.setBounds(7, -70, 100, 200);
        txtNumeroCtps.setBounds(7, 38, 115, 20);
        lblSerie.setBounds(130, -70, 100, 200);
        txtSerie.setBounds(130, 38, 72, 20);
        lblOrgao.setBounds(210, -70, 100, 200);
        txtOrgao.setBounds(210, 38, 68, 20);
        lblUfCtps.setBounds(285, -70, 100, 200);
        boxUfCtps.setBounds(285, 38, 41, 20);

        panelCpf.setBounds(425, 94, 330, 80);
        lblNumeroCpf.setBounds(7, -70, 100, 200);
        txtNumeroCpf.setBounds(7, 38, 180, 20);

        panelPis.setBounds(425, 179, 330, 80);
        lblNumeroPis.setBounds(7, -70, 100, 200);
        txtNumeroPis.setBounds(7, 38, 190, 20);
        lblDataCadastroPis.setBounds(210, -70, 100, 200);
        spinDataCadastroPis.setBounds(210, 38, 115, 20);

        panelTitulo.setBounds(425, 262, 330, 80);
        lblNumTituloEleitor.setBounds(7, -70, 100, 200);
        txtNumeroEleitor.setBounds(7, 38, 147, 20);
        lblZona.setBounds(170, -70, 100, 200);
        txtZona.setBounds(170, 38, 70, 20);
        lblSecao.setBounds(250, -70, 100, 200);
        txtSecao.setBounds(250, 38, 70, 20);

        panelRic.setBounds(425, 342, 330, 80);
        lblNumRic.setBounds(7, -70, 100, 200);
        txtNumeroRic.setBounds(7, 38, 107, 20);
        lblOrgaoExpedidorRic.setBounds(125, -70, 100, 200);
        txtOrgaoExpedidorRic.setBounds(125, 38, 95, 20);
        lblDataexpedicaoRic.setBounds(230, -70, 100, 200);
        spinDataExpedicaoRic.setBounds(230, 38, 90, 20);
    }

    private void posicionarContrato() {
        panelConVinculo.setBounds(4, 4, 388, 144);
        lblVinculo.setBounds(4, 0, 380, 20);
        boxVinculo.setBounds(4, 20, 380, 20);
        lblTipoAdmissao.setBounds(4, 50, 380, 20);
        boxTipoAdmissao.setBounds(4, 70, 380, 20);
        lblDataAdmissao.setBounds(4, 100, 100, 20);
        spinDataAdmissao.setBounds(4, 120, 100, 20);
        lblTipoSalario.setBounds(108, 100, 88, 20);
        boxTipoSalario.setBounds(108, 120, 88, 20);
        lblHorario.setBounds(200, 100, 88, 20);
        boxHorario.setBounds(200, 120, 88, 20);
        lblHrsSem.setBounds(292, 100, 94, 20);
        txtHrsSem.setBounds(292, 120, 94, 20);

        panelConFgts.setBounds(4, 150, 226, 84);
        lblOpcao.setBounds(4, 20, 107, 20);
        boxOpcao.setBounds(4, 40, 107, 20);
        lblDataOpcao.setBounds(115, 20, 107, 20);
        spinDataOpcao.setBounds(115, 40, 107, 20);

        panelConAtividade.setBounds(230, 150, 164, 84);
        rbUrbana.setBounds(4, 30, 80, 20);
        rbRural.setBounds(84, 30, 60, 20);

        panelConAdiantamento.setBounds(4, 238, 264, 70);
        lblAdiantamento.setBounds(4, 20, 86, 20);
        boxAdiantamento.setBounds(4, 40, 86, 20);
        lblPercentual.setBounds(94, 20, 82, 20);
        txtPercentual.setBounds(94, 40, 82, 20);
        lblValorFixo.setBounds(180, 20, 80, 20);
        txtValorFixo.setBounds(180, 40, 80, 20);

        panelConExperiencia.setBounds(268, 238, 124, 140);
        lblVencimento.setBounds(6, 20, 110, 20);
        spinVencimento.setBounds(6, 40, 110, 20);
        lblProrrogacao.setBounds(6, 70, 110, 20);
        spinProrrogacao.setBounds(6, 90, 110, 20);

        panelConSalario.setBounds(4, 312, 264, 62);
        lblValorSalario.setBounds(4, 10, 128, 20);
        txtValorSalario.setBounds(4, 30, 130, 20);
        lblTipoReajuste.setBounds(136, 10, 124, 20);
        boxTipoReajuste.setBounds(136, 30, 124, 20);

        panelConCargo.setBounds(394, 4, 358, 98);
        lblCargo.setBounds(4, 4, 342, 20);
        boxCargo.setBounds(4, 24, 342, 20);
        lblDepartamento.setBounds(4, 54, 342, 20);
        boxDepartamento.setBounds(4, 74, 342, 20);

        panelConCategoria.setBounds(394, 106, 358, 98);
        lblCategoriaGfip.setBounds(4, 4, 342, 20);
        boxCategoriaGfip.setBounds(4, 24, 342, 20);
        lblTipoContrato.setBounds(4, 54, 342, 20);
        boxTipoContrato.setBounds(4, 74, 342, 20);

        panelConRecisao.setBounds(394, 208, 358, 168);
        lblDataDemissao.setBounds(4, 20, 100, 20);
        spinDataDemissao.setBounds(4, 40, 100, 20);
        lblMotivoDemissao.setBounds(104, 20, 246, 20);
        boxMotivoDemissao.setBounds(104, 40, 246, 20);
        lblDataAvisoInicio.setBounds(104, 70, 123, 20);
        spinDataAvisoInicio.setBounds(104, 90, 123, 20);
        lblDataAvisoFim.setBounds(231, 70, 119, 20);
        spinDataAvisoFim.setBounds(231, 90, 119, 20);
        cbAvisoPrevio.setBounds(4, 90, 100, 20);
        lblMotivoRais.setBounds(4, 120, 348, 20);
        boxMotivoRais.setBounds(4, 140, 348, 20);
    }

    private void posicionarOperacional() {
        //PAINEL CHECKS
        panelOpChecks.setBounds(4, 4, 304, 145);
        cbInss.setBounds(4, 20, 146, 20);
        cbFgts.setBounds(4, 45, 146, 20);
        cbIrrf.setBounds(4, 70, 146, 20);
        cbReembolsoInss.setBounds(4, 95, 296, 20);
        cbEmpregadoDomestico.setBounds(4, 120, 296, 20);
        cbBeneficioPrevidencia.setBounds(4, 145, 296, 20);
        cbValeTransporte.setBounds(154, 20, 146, 20);
        cbValeRefeicao.setBounds(154, 45, 146, 20);
        cbPlanoSaude.setBounds(154, 70, 146, 20);

        //PAINEL RAÇA/COR
        panelOpRaca.setBounds(4, 160, 304, 86);
        lblRacaCor.setBounds(4, 0, 296, 20);
        boxRacaCor.setBounds(4, 20, 296, 20);
        lblTipoDeficiencia.setBounds(4, 40, 296, 20);
        boxTipoDeficiencia.setBounds(4, 60, 296, 20);

        //PAINEL SINDICATO
        panelOpSindicato.setBounds(310, 4, 442, 68);
        lblSindicato.setBounds(4, 20, 282, 20);
        boxSindicato.setBounds(4, 40, 282, 20);
        lblMesDissidio.setBounds(288, 20, 150, 20);
        boxMesDissidio.setBounds(288, 40, 150, 20);

        //PAINEL DADOS DO FUNCIONÁRIO
        panelOpDados.setBounds(310, 70, 442, 68);
        lblFormaPagamento.setBounds(4, 20, 140, 20);
        boxFormaPagamento.setBounds(4, 40, 140, 20);
        lblBanco.setBounds(146, 20, 110, 20);
        boxBanco.setBounds(146, 40, 110, 20);
        lblAgencia.setBounds(258, 20, 78, 20);
        txtAgencia.setBounds(258, 40, 78, 20);
        lblNumeroConta.setBounds(338, 20, 100, 20);
        txtNumeroConta.setBounds(338, 40, 100, 20);

        //PAINEL EXAMES ADICIONAIS
        panelOpExames.setBounds(310, 140, 250, 118);
        lblNomeMedico.setBounds(4, 20, 242, 20);
        txtNomeMedico.setBounds(4, 40, 242, 20);
        lblCrm.setBounds(4, 70, 90, 20);
        txtCrm.setBounds(4, 90, 90, 20);
        lblDataExame.setBounds(98, 70, 148, 20);
        spinDataExame.setBounds(98, 90, 148, 20);

        //PANEL FOTO
        panelOpFoto.setBounds(562, 140, 190, 230);
        lblFoto.setBounds(6, 15, 178, 184);
        btSelecionar.setBounds(6, 203, 87, 20);
        btLimpar.setBounds(95, 203, 89, 20);
    }

    public static void main(String[] args) {
        FormFuncionario obj = new FormFuncionario();

    }
}
